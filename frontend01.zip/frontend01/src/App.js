import { useState, useEffect } from "react";
import { Routes, Route, Link } from "react-router-dom";
import AuthService from "./services/auth.service";
import Login from "./components/Login";
import Signup from "./components/Signup";
import Home from "./components/Home";
import Profile from "./components/Profile";
import UserCart from "./components/UserCart";
import ForgorPassword from "./components/ForgotPassword";
import "bootstrap/dist/css/bootstrap.min.css";
import ProductDetails from "./components/ProductDetails";
import PaymentProcess from "./components/PaymenyProcess";
import PostService from "./services/post.service";
import AdminServices from "./components/AdminServices";
import AddStaff from "./components/AdminCompoments/AddStaff";
import UpdateProduct from "./components/AdminCompoments/UpdateProduct";
import AddProduct from "./components/AdminCompoments/AddProduct";
import OrderDetails from "./components/AdminCompoments/OrderDetails";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import UserOrderDetails from "./components/UserComponents/UserOrderDetails";
import FooterDiv from "./components/FooterDiv";
import TopBar from "./components/TopBar";
import MainNavBar from "./components/MainNavBar";
import SearchResult from "./components/UserComponents/SearchResult";
import PDf from "./components/UserComponents/PDF";
import UpdateAddress from "./components/UserComponents/UpdateAddress";
function App() {
 
useEffect(() => {

const user = AuthService.getCurrentUser();

if (user) {
  
  let userdata=PostService.getLoggedUser();
    console.log(userdata);
    

    const userloged = PostService.getLoggedUserInfo();
    console.log(userloged)
    
    if(!userloged){
      console.log("IN IFFFFFF")
      PostService.getUserInfo(userdata[1]).then((resp)=>{
        console.log(resp.data);
        localStorage.setItem("loggedUser", JSON.stringify(resp.data));
        
      });
     
    }//if (!userloged) End


}//if (user)

},[] ); 

  return (
<div className="page-container">
    <div className="content-wrap">

    <div className="App">
      <div className="beforeNav">
        <TopBar/>
      </div>
    <MainNavBar/>
      

      <Container fluid  >
         
          <Row>
      <div className="container m-0 p-0">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/userprofile" element={<Profile />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/forgotpassword" element={<ForgorPassword />} />
          <Route path="/usercart" element={<UserCart />} />
          <Route path="/paymentprocess/:total" element={<PaymentProcess />} />
          <Route exact path="/productdetails/:id" element={<ProductDetails />} />
          <Route path="/userorderdetails/:id" element={<UserOrderDetails />} />
          <Route path="/invoice/:id" element={<PDf />} />
          <Route path="/searchproduct/:category/:searchtext" element={<SearchResult />} /> 
          <Route path="/updateuseraddress/:adrid" element={<UpdateAddress />} />
         
          <Route path="/adminservices" element={<AdminServices />} />
          <Route path="/addproduct" element={<AddProduct />} />
          <Route path="/addstaff" element={<AddStaff />} />
          <Route path="/updateproduct/:id" element={<UpdateProduct />} />
          <Route path="/orderdeatils/:id" element={<OrderDetails />} />

      
        </Routes>
      </div>

      </Row>

      {/* <Row>

      <FooterDiv/>
      </Row> */}
      </Container>

          
      
  
    </div>
    </div>
    <FooterDiv/>
    </div>
  );
}

export default App;
