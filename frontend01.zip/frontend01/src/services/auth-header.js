export default function authHeader() {
  const user = JSON.parse(localStorage.getItem("user"));
  //console.log(user);
  if (user) {
    console.log("In authHeader if (user) ");
       //axios.get(api, { headers: {"Authorization" : `Bearer ${token}`} })
     return { Authorization: 'Bearer ' + user };
    //return { "Bearer": user.accessToken };
  } else {
    console.log("In authHeader if (user) ELSE PArt ");
    return {};
  }
}
