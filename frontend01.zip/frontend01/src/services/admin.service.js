import axios from "axios";
import authHeader from "./auth-header";

const API_URL = process.env.REACT_APP_BACKEND_URL+"/admin";

const getAllCategories = () => {
  console.log("In  getAllCategories")
  return axios.get(API_URL + "/category",{ headers: authHeader() });
};

const updateProduct = (prodId,product) => {
  console.log("In  updateProduct")
  
  
  //axios.get(api, { headers: {"Authorization" : `Bearer ${token}`} })
  return axios.put(API_URL + "/product/"+prodId, product,{ headers: authHeader() });
};

const deleteProduct = (prodId) => {
  console.log("In  deleteProduct")
  
  //axios.get(api, { headers: {"Authorization" : `Bearer ${token}`} })
  return axios.delete(API_URL + "/product/"+prodId, { headers: authHeader() });
};
const addProduct = (product) => {
  console.log("In  addProduct")
 
  return axios.post(API_URL + "/product",product, { headers: authHeader() });
 // return axios.get("https://randomuser.me/api/?nat=us&results=18&page=1");
  

};

const getProductById = (id) => {
  console.log("In  getAllProducts")
 
  return axios.get(API_URL + "/user/product/"+id, { headers: authHeader() });
 // return axios.get("https://randomuser.me/api/?nat=us&results=18&page=1");
  

};




const  getAllOrders=() =>{
  console.log("In getAllOrders ");
  
  return axios.get(API_URL + "/getallorders", { headers: authHeader() });
  

}
const  getOrderDetails=(orderId) =>{
  console.log("In getOrderDetails ");
  console.log(orderId);
  return axios.get(API_URL + "/getorderdetails/"+orderId, { headers: authHeader() });
  

}

const  setorderdeliverystatus=(orderId,status) =>{
  console.log("In setorderdeliverystatus ");
  
  return axios.get(API_URL + "/setorderdeliverystatus/"+orderId+"/"+status, { headers: authHeader() });
  

}
const  getAllStaff=() =>{
  console.log("In getAllStaff ");
  
  return axios.get(API_URL + "/getallstaff", { headers: authHeader() });
  

}

const addNewStaff = (staff) => {
  console.log("In  addNewStaff")
 
  return axios.post(API_URL + "/addnewstaff",staff, { headers: authHeader() });
 // return axios.get("https://randomuser.me/api/?nat=us&results=18&page=1");
  

};

const AdminService = {
  addNewStaff,
  getAllStaff,
  setorderdeliverystatus,
  getAllCategories,
  updateProduct,
  deleteProduct,
addProduct,
getAllOrders,
getOrderDetails

};

export default AdminService;
