import axios from "axios";
import authHeader from "./auth-header";

const API_URL = process.env.REACT_APP_BACKEND_URL;

const getAllPublicPosts = () => {
  console.log("In  getAllPublicPosts")
  return axios.get(API_URL + "/home");
};

const getAllPrivatePosts = () => {
  console.log("In  getAllPrivatePosts")
  console.log(authHeader());
  console.log("-----------------------------");
  //axios.get(api, { headers: {"Authorization" : `Bearer ${token}`} })
  return axios.get(API_URL + "/user", { headers: authHeader() });
};

const getAllProducts = () => {
  console.log("In  getAllProducts")
 
  return axios.get(API_URL + "/user/products", { headers: authHeader() });
 // return axios.get("https://randomuser.me/api/?nat=us&results=18&page=1");
  

};

const getProductById = (id) => {
  console.log("In  getAllProducts")
 
  return axios.get(API_URL + "/user/product/"+id, { headers: authHeader() });
 // return axios.get("https://randomuser.me/api/?nat=us&results=18&page=1");
  

};


const  parseJwt=(token) =>{
  if (!token) { return; }
  console.log("In privatePosts parseJwt");
  const base64Url = token.split('.')[1];
  const base64 = base64Url.replace('-', '+').replace('_', '/');
  return JSON.parse(window.atob(base64)).sub;
}
const  getLoggedUser=() =>{

  const userloged = JSON.parse(localStorage.getItem("user"));
  if(userloged){
  let user=parseJwt(userloged).split('-');
  return user;
  }
  return false;
  

}
const  getLoggedUserInfo=() =>{

  const userloged = JSON.parse(localStorage.getItem("loggedUser"));
  if(userloged){
  
  return userloged;
  }
  return false;
  

}
const updateUserProfile = (userId,user) => {
  console.log("In  updateUserProfile")
  
  
  //axios.get(api, { headers: {"Authorization" : `Bearer ${token}`} })
  return axios.put(API_URL + "/user/updateuser/"+userId, user,{ headers: authHeader() });
};

const  addProductToCart=(userId,id,quantity) =>{
  console.log("In addProductToCart ");
  console.log(userId,id,quantity);
  return axios.get(API_URL + "/user/cart/"+userId+"/"+id+"/"+quantity, { headers: authHeader() });
  

}
const  getUserCart=(userId) =>{
  console.log("In getUserCart ");
  console.log(userId);
  return axios.get(API_URL + "/user/cart/"+userId, { headers: authHeader() });
  

}
const  updateUserCartProduct=(userId,prodId,quantity) =>{
  console.log("In getUserCart ");
  console.log(userId);
  return axios.get(API_URL + "/user/updatecart/"+userId+"/"+prodId+"/"+quantity, { headers: authHeader() });
  

}
const  deleteProductFromcart=(userId,prodId) =>{
  console.log("In deleteProductFromcart ");
  
  return axios.get(API_URL + "/user/deleteproductcart/"+userId+"/"+prodId, { headers: authHeader() });
  

}

const  createPaymentOrder=(userId,total) =>{
  console.log("In createPaymentOrder ");
  
  return axios.get(API_URL + "/user/createpaymentorder/"+userId+"/"+total, { headers: authHeader() });
  

}

const  setUserProfileImage=(userId,image) =>{
  console.log("In setUserProfileImage ");
  
  return axios.get(API_URL + "/user/userprofileimage/"+userId+"/"+image, { headers: authHeader() });
  

}



const  postPaymentOrder=(orderid,paymentid) =>{
  console.log("In createPaymentOrder ");
  
  return axios.get(API_URL + "/user/postorderprocess/"+orderid+"/"+paymentid, { headers: authHeader() });
 }

 const  getUserInfo=(userid) =>{
  console.log("In getUserInfo ");
  
  return axios.get(API_URL + "/user/userinfo/"+userid, { headers: authHeader() });
 }

 const getAllCategories = () => {
  console.log("In  getAllCategories")
  return axios.get(API_URL + "/user/category",{ headers: authHeader() });
};

const getUserAddress = (userId) => {
  console.log("In  getUserAddress")
  return axios.get(API_URL + "/user/address/"+userId,{ headers: authHeader() });
};

const getAllUserOrders = (userId) => {
  console.log("In  getAllUserOrders")
  return axios.get(API_URL + "/user/getalluserorders/"+userId,{ headers: authHeader() });
};

const  getUserOrderDetails=(orderId) =>{
  console.log("In getOrderDetails ");
  //console.log(orderId);
  return axios.get(API_URL + "/user/getorderdetails/"+orderId, { headers: authHeader() });
  

}
const  searchProducts=(category,searchtext) =>{
  console.log("In searchProducts ");
 
  return axios.get(API_URL + "/user/products/"+category+"/"+searchtext, { headers: authHeader() });
  

}

const  saveUserAddress=(userid,address) =>{
  console.log("In saveUserAddress ");
  console.log(address);
  return axios.post(API_URL + "/user/address/"+userid,address, { headers: authHeader() });
  

}
const updateUserAddress =(addrId,addr) => {
  console.log("In  updateUserAddress")
    return axios.put(API_URL + "/user/updateuseraddress/"+addrId,addr,{ headers: authHeader() });
}
const cancelUserOrder =(orderId) => {
  console.log("In  cancelUserOrder")
    return axios.get(API_URL + "/user/canceluserorder/"+orderId,{ headers: authHeader() });
}
const  getProductPage=async (category,pname,count,pageNo) =>{
  console.log("In getProductPage ");
  
  return await axios.get(API_URL + "/user/getproductPage/"+category+"/"+pname+"/"+count+"/"+pageNo, { headers: authHeader() });
  

}
const postService = {
  cancelUserOrder,
  updateUserAddress,
  updateUserProfile,
  getLoggedUserInfo,
  getProductPage,
  saveUserAddress,
  searchProducts,
  getUserOrderDetails,
  getAllUserOrders,
  getUserAddress,
  getAllCategories,
  getAllPublicPosts,
  getAllPrivatePosts,
  getAllProducts,
  getProductById,
  getLoggedUser,
  addProductToCart,
  getUserCart,
  updateUserCartProduct,
  deleteProductFromcart,
  createPaymentOrder,
  postPaymentOrder,
  getUserInfo,
  setUserProfileImage
};

export default postService;
