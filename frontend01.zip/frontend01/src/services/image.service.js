import axios from "axios";


const API_URL = process.env.REACT_APP_IMAGE_UPLOAD_URL;

const uploadImage = (data) => {
  console.log("In  uploadImage")
 
  return  axios.post(API_URL, data, {  //receive two parameter endpoint url ,form data 
  })
  
};


const ImageService = {
  uploadImage
};

export default ImageService;
