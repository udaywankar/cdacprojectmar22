import axios from "axios";
import postService from "./post.service";

const API_URL = process.env.REACT_APP_BACKEND_URL+ "/api/auth";

const signup = (userName,email, password) => {
  return axios
    .post(API_URL + "/signup", {
      
   
      "userName": userName,
      "email": email,
      "password": password,
      "role": "ROLE_USER"
    })
    .then((response) => {
      console.log(response);
      if (response.data.accessToken) {
        console.log("In signup Function");
        //console.log("In Login Function");
        console.log(response.data.accessToken);
       localStorage.setItem("user", JSON.stringify(response.data));
      }

      return response.data;
    });
};

const login = (email, password) => {
  return axios
    .post(API_URL + "/signin", {
      email,
      password,
    })
    .then((response) => {
      console.log("In signin Function");
      console.log(response);
      console.log(response.data);
      console.log(response.data.jwt);
      console.log(JSON.stringify(response.data));
      if (response.data.jwt) {
               localStorage.setItem("user", JSON.stringify(response.data.jwt));
             
        
      
        }
        let user=postService.getLoggedUser();
        console.log(user);
        
        postService.getUserInfo(user[1]).then((resp)=>{
          console.log(resp.data);
          localStorage.setItem("loggedUser", JSON.stringify(resp.data));
          
        });
      return response.data;
    });
};

const forgotCheckEmail = (email) => {
  return axios
    .get(API_URL + "/forgotpassword/"+email)
    .then((response) => {
      console.log("In forgotCheckEmail Function");
      console.log(response);
      console.log(response.data);
      console.log(response.data.message);
      if (response.data.message==="email Found") {
        console.log("email Found");
        return true;
        }else
           return false;
    });
};

const changePassword = (email,pass,otp) => {
  return axios
    .get(API_URL + "/changepassword/"+email+"/"+pass+"/"+otp)
    .then((response) => {
      console.log("In changePassword Function");
      console.log(response);
      console.log(response.data);
      console.log(response.data.message);
      if (response.data.message==="email Found") {
        console.log("email Found");
        return true;
        }else
           return false;
    });
};


const changeUserPassword = (userid,oldpass,newpass) => {
  return axios
    .get(API_URL + "/changeuserpassword/"+userid+"/"+oldpass+"/"+newpass);
    // .then((response) => {
    //   console.log("In changePassword Function");
    //   console.log(response);
    //   console.log(response.data);
    //   console.log(response.data.message);
    //   if (response.data.message==="Success") {
    //     console.log("Pass Changed");
    //     return "Success";
    //     }else
    //        return "Failed";
    // });
}
const logout = () => {
  localStorage.removeItem("user");
  localStorage.removeItem("loggedUser");
};

const getCurrentUser = () => {
  return JSON.parse(localStorage.getItem("user"));
};

const authService = {
  signup,
  login,
  logout,
  getCurrentUser,
  forgotCheckEmail,
  changePassword,
  changeUserPassword
};

export default authService;
