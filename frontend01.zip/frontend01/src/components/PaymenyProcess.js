import { dialogActionsClasses } from "@mui/material";
import React, { useState,useEffect } from "react";
import { useParams } from 'react-router';
import { useNavigate ,useLocation } from "react-router-dom";
import postService from '../services/post.service';
import CheckOutOrderDetails from "./UserComponents/CheckOutOrderDetail";
import Swal from 'sweetalert2';
const PaymentProcess = () => {
  const location = useLocation();
  const navigate=useNavigate();
    const { total } = useParams();
    const [userId,setUserId]= useState(location.state.id);
    const [userCart,setUserCart] = useState(location.state.cart);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [shippingAddr,setShippingAddr] = useState(location.state.ship);
  console.log(location.state.id);
  console.log(location.state.cart);
  console.log(location.state.ship);

  var finalamt=0;
      if(total<1000 && total!=0){
        
        finalamt=Number(total)+Number(50);
      }else{
        finalamt=Number(total);
      }
      console.log(finalamt);
  useEffect(()=>{
    console.log("IN useEffect of PaymentProcess");
    console.log(userCart);
     if(total===0){
      navigate("/usercart");
     
     }
    console.log(userCart);
    console.log(userId);
  },[]);


  const createpayment=()=>{
    console.log("In Create Paymeny Functiom");
    let userid=postService.getLoggedUser();
      setUserId(userid[1]);
      console.log(userId);
      console.log(userid[1]);
      
     
      postService.createPaymentOrder(userid[1],finalamt).then(
        (response)=>{
          console.log(response.data);
          console.log(response);
          console.log(process.env.REACT_APP_RAZO_RAPAY_KEY_ID);
          console.log(response.data.razorId);
          let orderid=response.data.status;
          if(response.data.status=="created"){
          
          let totalamount=response.data.totalPrice*100;
          var options={
            "key":process.env.REACT_APP_RAZO_RAPAY_KEY_ID,
            "amount":totalamount,
            "currency":"INR",
            "name":"AmigoTech.in",
            "description":"test tranxs",
            "image":"",
            "order_id":response.data.razorId,
            "handler":function (response){
              console.log(response);
              console.log(response.razorpay_payment_id);
              console.log(response.razorpay_order_id);
              console.log(response.razorpay_signature);
              postPaymentProcess(response);

              },
              "prefill": {
              "name": userid[0],
              "email": userid[0],
              "contact": shippingAddr.phone
              },
              "notes": {
              "address": "Razorpay Corporate Office"
              
              },
              "theme": {
              "color": "#3399cc"
              }
              };
              var rzp1 = new window.Razorpay(options);
              rzp1.on('payment.failed', function (response){
              console.log(response.error.code);
              console.log(response.error.description);
              console.log(response.error.source);
              console.log(response.error.step);
              console.log(response.error.reason);
              console.log(response.error.metadata.order_id);
              console.log(response.error.metadata.payment_id);
              });
              rzp1.open();
              console.log("IN creatpaymentheader");
            }
        },(error) => {
          console.log(error);
        });


  }
const postPaymentProcess=(data)=>{
  console.log("IN postPaymentProcess");
postService.postPaymentOrder(data.razorpay_order_id,data.razorpay_payment_id).then(
  (data)=>{
    console.log(data);
    Swal.fire({
      icon: 'success',
      title: 'Payment Successfull',
      
    })
    navigate("/home");
  },(error) => {
    console.log(error);
    Swal.fire({
      icon: 'error',
      title: 'Payment Failed'
      
    })
  }
)


}
  
  
const backtoAddAddress=()=>{
  navigate("/userprofile");
}
 

  return (
    <div>
        {/* <h3>Payment process: {total}   </h3>
        <button className="btn btn-outline-dark flex-shrink-0 justify-content-center" onClick={()=>createpayment()} type="button">
                            Pay
         </button> */}
         <div class="container mt-5 mb-5">
<div class="row d-flex justify-content-center">
<div class="col-md-12 col-lg-12 ">
<div class="card">

        <CheckOutOrderDetails state={ {userid : userId,
                                        cart: userCart,
                                        total:total,
                                        ship:shippingAddr
                              
                                }}/>
{shippingAddr===undefined ? (
  <button className="btn btn btn-secondary flex-shrink-0 m-5"  onClick={()=>backtoAddAddress()} type="button">
                          Add Address 
                          
         </button>

):(
<button className="btn btn btn-secondary flex-shrink-0 m-5"  onClick={()=>createpayment()} type="button">
                           Make Payment
         </button>
         )}
</div>
</div>
</div>
</div> 
 
    </div>
  );
};

export default PaymentProcess;
