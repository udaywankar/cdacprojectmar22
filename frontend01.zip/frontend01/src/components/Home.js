import React, { useState, useEffect ,CSSProperties} from "react";
import postService from "../services/post.service";
import ProductCard from "./ProductCard";
import Slideshow from './ProductImageSlider';
import ProductCardSlider from "./ProductCardSlider";
import BannerSlider from "./BannerSlider";
import ClipLoader from "react-spinners/ClipLoader";

const Home = () => {

  const [bannerArry,setBannerArry]=useState([]);
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  const [product,setProduct] = useState([]);
  const [posts, setPosts] = useState();
   const [products, setProducts] = useState(false);
  const[comments,setComments]=useState();
  const [productsList, setProductsList] = useState([]);
  const [isLoading, setisLoading] = useState(true);

  const bannerData =()=>{
    let bannerimgNo=4;
    let imageName=[];
    for(var i=1;i<=bannerimgNo;i++){
      imageName.push(`banner0${i}.jpg`);
    }
    setBannerArry(imageName);
}
const fetchData =()=>{
   
 
  postService.getAllProducts().then(
    (val)=>{
      console.log(val.data);
      setProduct(val.data);
      setisLoading(false);
    },
  
            (error) => {
              console.log(error);
            }
  )
}
useEffect(()=>{
  bannerData();
  fetchData();
   
    var currentDate = new Date()
var day = currentDate.getDate()
var month = currentDate.getMonth() + 1
var year = currentDate.getFullYear()
console.log(day,"/",month,"/",year);



},[])
useEffect(()=>{
},[isLoading])

 
  return (
    <div>

        {/* <ClipLoader color={"#123abc"} loading={isLoading}  size={150} /> */}
   

     
      <BannerSlider name={bannerArry}/>


      {/* <ProductCardSlider product={product} /> */}
          <div >
          
          {/* { !isLoading ?? ( <ProductCard product={product}/>  ) } */}
          <ProductCard product={product}/> 
         </div>
         {/* <div >{products.map(w=>{
          return <> <h2>{w.productName}</h2></>
         })}
         </div> */}
      
    </div>
  );
};

export default Home;




//   const product={ 
//     id,
//   productName,
//   "description": "ARDUINO MICROCONTROLLER",
//   "categoryName": "MICROCONTROLLER",
//   "price": 550,
//   "stock": 120,
//   "sku": "ARDU01"
// }