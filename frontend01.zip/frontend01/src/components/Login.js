import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import AuthService from "../services/auth.service";
import postService from "../services/post.service";
import lockImg from "./lock logo.jpg";
import "./LoginCSS.css";
import Swal from 'sweetalert2';
import Signup from "./Signup";
const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loginerror, setloginerror] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      await AuthService.login(email, password).then(
        (resp) => {
          console.log(resp);
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 2000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
          })
          
          Toast.fire({
            icon: 'success',
            title: 'Signed in successfully'
          });
          let user=postService.getLoggedUser();
          if(user[2]==="ADMIN"){
            navigate("/home");
            //navigate("/adminservices");
          }
          navigate("/home");
          window.location.reload();
        },
        (error) => {
         
          console.log(error.response.data);
          console.log(error.response.status);
          if(error.response.status=="401"){
            setloginerror(true);
          }
          
        }
      );
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className="backgroundImage" >
      <Container fluid  >
      
      <Row>
      <Col   lg={12} md={6}>

      <div className="wrapper">
        <div className="logo">
            <img src={lockImg} alt=""/>
        </div>
        <div className="text-center mt-4 name">
            AmigoTech Login
        </div>
        <form className="p-3 mt-3" onSubmit={handleLogin} >
            <div className="form-field d-flex align-items-center">
                <span className="far fa-user"></span>
                <input type="text" name="userName" id="userName" placeholder="Username" onChange={(e) => setEmail(e.target.value)}/>
            </div>
            <div className="form-field d-flex align-items-center">
                <span className="fas fa-key"></span>
                <input type="password" name="password" id="pwd" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
            </div>
            {loginerror ? (<h3 style={{ color:"red"}}>Invalid Credential</h3>):(null)}
            <button type="submit" className="btn mt-3">Login</button>
        </form>
        <div className="text-center fs-6">
            <a href="/forgotpassword">Forget password?</a> or <a href="/signup">Sign up</a>
        </div>
    </div>
       

      </Col>
      
      
      </Row>  
       
     
    
        
       




    </Container  >
     
    </div>
  );
};

export default Login;
