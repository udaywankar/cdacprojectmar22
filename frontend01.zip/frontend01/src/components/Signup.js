import React, { useState } from "react";
import AuthService from "../services/auth.service";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import lockImg from "./lock logo.jpg";
import { useNavigate } from "react-router-dom";
import "./LoginCSS.css";
import Swal from 'sweetalert2';

const Signup = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [userName, setUserName] = useState("");
  const navigate = useNavigate();

  const handleSignup = async (e) => {
    e.preventDefault();
    try {
      await AuthService.signup(userName,email, password).then(
        (response) => {
          // check for token and user already exists with 200
          console.log("Sign up successfully", response);
          //alert("Sign Up SuccessFull");
          Swal.fire({
            icon: 'success',
            title: 'Sign Up SuccessFull',
            text: 'Going To Login Page',
          })
          navigate("/login");
          //window.location.reload();
        },
        (error) => {
          console.log(error.message);
          Swal.fire({
            icon: 'error',
            title: 'Email Already Exist in our system',
            text: 'Please use another email or Recover your account using forgot password',
          })
        }
      );
    } catch (err) {
      console.log(err);
    }
  };

  return (

    <div className="backgroundImage pt-5">

<Container fluid  >
      
      <Row>
      <Col   lg={12} md={6}>
      <div className="wrapper mt-0 ">
        <div className="logo">
            <img src={lockImg} alt=""/>
        </div>
        <div className="text-center mt-4 name">
           Signup
        </div>
        <form className="p-3 mt-3" onSubmit={handleSignup} >
            <div className="form-field d-flex align-items-center">
                <span className="far fa-user"></span>
                <input type="text" name="userName" id="userName" placeholder="Username"  onChange={(e) => setUserName(e.target.value)}/>
            </div>
            <div className="form-field d-flex align-items-center">
                <span className="far fa-user"></span>
                <input type="text" name="userEmail" id="userEmail" placeholder="User Email" onChange={(e) => setEmail(e.target.value)}/>
            </div>

            <div className="form-field d-flex align-items-center">
                <span className="fas fa-key"></span>
                <input type="password" name="password" id="pwd" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
            </div>
           
            <button type="submit" className="btn mt-3">SignUp</button>
        </form>
        {/* <div className="text-center fs-6">
            <a href="/forgotpassword">Forget password?</a> or <a href="#">Sign up</a>
        </div> */}
    </div>




      {/* <form onSubmit={handleSignup}>
        <h3>Sign up</h3>
        <input
          type="text"
          placeholder="UserName"
          value={userName}
          onChange={(e) => setUserName(e.target.value)}
        />
        <br/><br/><br/>
        <input
          type="text"
          placeholder="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        /><br/><br/><br/>
        <input
          type="password"
          placeholder="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        /><br/><br/><br/>
        <button type="submit">Sign up</button>
      </form> */}

</Col>
      
      
      </Row>  
       
     
    
        
       




    </Container  >
    </div>
  );
};

export default Signup;
