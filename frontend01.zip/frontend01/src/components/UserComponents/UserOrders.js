import React, { useState ,useEffect} from "react";
import { useNavigate } from "react-router-dom";
import postService from "../../services/post.service";
import "./../UserProfileCSS.css";
import { NavLink } from 'react-router-dom';
import Table from 'react-bootstrap/Table';

const UserOrders = ({user}) => {
  const [billingAddr, setBillingAddr] = useState({});
  const [shippingAddr, setshippingAddr] = useState({});
  const [orders, setOrders] = useState([]);
  const navigate = useNavigate();
  console.log(user)
  
  
  const fetchData =()=>{

    let user=postService.getLoggedUser();
        console.log(user);
        console.log(user[2]);


    postService.getAllUserOrders(user[1]).then(
      (val)=>{
        console.log(val.data);
       setOrders(val.data);
       
      },
    
              (error) => {
                console.log(error);
              }
    )
}

useEffect(()=>{
    fetchData();
    //console.log(user);
},[])

  return (
   
    <div >
        <h3 className="d-flex justify-content-center mt-5 mb-5" style={{color:"green"}}>User Orders</h3>
{orders.length >0 ? (

<Table striped bordered hover size="sm" variant="light">
      <thead>
        <tr>
          <th>#Id</th>
          <th>Order Date</th>
          <th>Payment Id</th>
          <th>Total Price</th>
          <th>status</th>
          <th>Delivery Status</th>
          <th>Operations</th>
        </tr>
      </thead>
      <tbody>
        {orders.map((order)=>(
          <tr key={order.id}>
          <td>{order.id}</td>
          <td>{order.orderDate}</td>
          <td>{order.paymentId}</td>
          <td>{order.totalPrice}</td>
          <td>{order.status}</td>
          <td>{order.delivery_status}</td>
          <td>
          &emsp; <NavLink to={`/userorderdetails/${order.id}`}><button type="button" className="btn btn-primary mb-2" >Details</button></NavLink> 
          </td>
        </tr>

        ))}
        
        
      </tbody>
    </Table>

):(  
  <h4 className="btn d-flex justify-content-center"> You Haven't Placed Any Orders yet</h4>
)}


    </div>


 
  );
};

export default UserOrders;
