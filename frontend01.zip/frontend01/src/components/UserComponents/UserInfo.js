import React, { useState ,useEffect} from "react";
import { useNavigate } from "react-router-dom";
import postService from "../../services/post.service";
import "./../UserProfileCSS.css";
import { NavLink } from 'react-router-dom';
import $ from 'jquery';
import EmailIcon from '@material-ui/icons/Email';
import PhoneAndroidIcon from '@material-ui/icons/PhoneAndroid';
import PaymentIcon from '@material-ui/icons/Payment';
import Swal from 'sweetalert2';
const UserInfo = ({user}) => {
  const [showAddrFlag, setShowAddrFlag] = useState(false);
  const [billAddrFlag, setbillAddrFlag] = useState(false);
  const [shipAddrFlag, setshipAddrFlag] = useState(false);
  const [commonAddrFlag, setCommonAddrFlag] = useState(false);
  const [userId, setUserId] = useState();
  const [billingAddr, setBillingAddr] = useState({});
  const [shippingAddr, setShippingAddr] = useState({});
  const [commonAddress, setcommonAddress] = useState({});
  const [sameAddr, setsameAddr] = useState(false);
  const navigate = useNavigate();
  //console.log(user)
  
  useEffect(() => {
    
    let user=postService.getLoggedUser();
        //console.log(user);
        
        console.log(user[2]);
        setUserId(user[1]);
    postService.getUserAddress(user[1]).then(
      (response) => {
        
        console.log(response.data);
        let adrArray =response.data;
        var same=adrArray.filter((p)=> p.type==="BOTH");
       
        var bill=adrArray.filter((p)=> p.type==="BILL");
        console.log(adrArray);
        if(same.length>0){
        setbillAddrFlag(false);
        setshipAddrFlag(false);
        setCommonAddrFlag(true);
        setcommonAddress(same[0]);
      }
      var ship=adrArray.filter((p)=> p.type==="SHIP");
      if(ship.length>0){
        
        setshipAddrFlag(true);
        setCommonAddrFlag(false);
        setShippingAddr(ship[0]);
      }
      var bill=adrArray.filter((p)=> p.type==="BILL");
      if(bill.length>0){
        setbillAddrFlag(true);
        
        setCommonAddrFlag(false);
        setBillingAddr(bill[0]);
      }

               
      },
      (error) => {
        console.log("Private page", error.response);
        // Invalid token
        if (error.response && error.response.status === 403) {
          console.log("In getAllPrivatePosts ERROR");
          // AuthService.logout();
          // navigate("/login");
          // window.location.reload();
        }
      }
    );
  }, []);

const addShipAddress=()=>{
      setShowAddrFlag(true);
}
const saveAddressToBackEnd=(Address)=>{
    postService.saveUserAddress(userId,Address).then((resp)=>{
        console.log(resp);
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        
        Toast.fire({
          icon: 'success',
          title: 'Address Saved'
        });



        navigate("/userprofile");
    });

}
const arrayToAddreessObject=(sameAddress,type)=>{
  var data = sameAddress.reduce(function(obj, item) {
    obj[item.name] = item.value;
    obj["type"] = type;
    return obj;
}, {});
    return data;
}

const saveAddress=(e)=>{
  e.preventDefault();
  console.log(e.target);
  if(sameAddr){
    var sameAddress=$('#main').serializeArray();
    console.log(sameAddress);
    console.log(arrayToAddreessObject(sameAddress,"BOTH"));
    let commonAddress=arrayToAddreessObject(sameAddress,"BOTH");
    setcommonAddress(commonAddress);
    saveAddressToBackEnd(commonAddress);
  }else{
    console.log("In Save Address Else Part");
    var billAdr=$('#bill').serializeArray();
    setBillingAddr(arrayToAddreessObject(billAdr))
    let bilAddress=arrayToAddreessObject(billAdr,"BILL");
    saveAddressToBackEnd(bilAddress);
    var shipAdr=$('#ship').serializeArray();
    setShippingAddr(arrayToAddreessObject(shipAdr));
    let shipAddress=arrayToAddreessObject(shipAdr,"SHIP");
    saveAddressToBackEnd(shipAddress);
  }
  
 

}
const addressForm=(value)=>{
  return(<div class="container">


  <div class="row mx-0 justify-content-center">
    {/* <div class="col-md-8 col-lg-12 px-lg-2 col-xl-4 px-xl-0 px-xxl-3"> */}
    <div class="col-md-8 col-lg-12">
      <form id={value}
         class="w-100 rounded-1 p-4 border bg-white"
         onSubmit={saveAddress}
        >
        <label class="d-block mb-4">
          <span class="form-label d-block">Your Full Name</span>
          <input
            name="fullName"
            type="text"
            class="form-control"
            />
        </label>

        <label class="d-block mb-4">
          <span class="form-label d-block">Street Address</span>
          <textarea class="form-control" name="streetAddress" id="exampleFormControlTextarea1" maxLength="100" rows="3"></textarea>
        </label>
        <label class="d-block mb-4">
          <span class="form-label d-block">City</span>
          <input name="city" type="text" class="form-control" placeholder="" />
        </label>

        <label class="d-block mb-4">
          <span class="form-label d-block">State</span>
          <input name="state" type="text" class="form-control" placeholder="" />
        </label>

        <label class="d-block mb-4">
          <span class="form-label d-block">Zip/Postal code</span>
          <input name="pincode" type="text" class="form-control" placeholder="" />
        </label>

        <label class="d-block mb-4">
          <span class="form-label d-block">Country</span>
          <input
            name="country"
            type="text"
            class="form-control"
            placeholder=""
          />
        </label>

        <label class="d-block mb-4">
          <span class="form-label d-block">Mobile No.</span>
          <input
            name="phone"
            type="text"
            class="form-control"
            placeholder=""
          />
        </label>
          <div class="mb-3">
            {value!="ship" ? (

          <button type="submit" class="btn btn-primary px-3 rounded-3">
            Save
          </button>
            ) :(<p></p>)}
          
        </div>

     
      </form>
    </div>
  </div>
</div>);
}

const sameaddr=(e)=>{
  //console.log(e);
//console.log(e.target.value);
//console.log(e.target.checked);
if(e.target.checked){
setsameAddr(true);
}else{setsameAddr(false);}
}

  return (
   
    <div >


 <div  className="container rounded bg-white mt-5 mb-5">
    <div  className="row">
        
       <div  className="col-md-12 border-right">
            <div  className="p-3 py-5">
                <div  className="d-flex justify-content-center  mb-3">
                    <h4  className="text-center" style={{color:"green"}} >Welcome, {user.userName}</h4>
                </div>
                <div  className="row mt-1">
                      <h5><EmailIcon/>  {user.email}</h5>
                      {user.mobileNo ? (<h5><PhoneAndroidIcon/>  {user.mobileNo}</h5>) : (<p></p>)}
                      
                      {user.panNo ? (<h5><PaymentIcon/>  {user.panNo}</h5>) : (<p></p>)}
                      
                      

                  
                    </div>
                <div  className="row mt-3">
                
                   
                   {/* <div className="border border-dark"> */}
                   {!billAddrFlag && !shipAddrFlag && !commonAddrFlag ? (<>
                    
                    <div className="row">

                          <h4 className="justify-content-center">Add Address</h4>
                          <div class="custom-control custom-checkbox">
                               <input type="checkbox" class="custom-control-input" id="customCheck1" value="same" onClick={(e)=>sameaddr(e)}/>
                               <label class="custom-control-label" for="customCheck1">check box if billing and shipping address is Same</label>
                          </div>
                   </div>

                    {sameAddr  ? addressForm("main"):  ( <>

                    <div className="col-md-6">
                    <h6 className="justify-content-center">Billing Address</h6>
                      {addressForm("bill")}
                      </div>
                      <div className="col-md-6">
                      <h6 className="justify-content-center">Shipping Address</h6>
                      {addressForm("ship")}
                      </div>
                      </>

                    )} 
                    

                   </>) : (null)}

                   {commonAddrFlag ?  (

                <fieldset class="border border-dark">

                       <p class="fw-semibold">Billing & Shipping Address:</p>

                       <h5><strong>{commonAddress.fullName}  &nbsp;&nbsp; {commonAddress.phone}</strong> </h5>
                       <h6> {commonAddress.streetAddress} </h6>
                       <h6> {commonAddress.city} ,  {commonAddress.state} -  {commonAddress.pincode}</h6>
                       <NavLink to={`/updateuseraddress/${commonAddress.id}`} state={ { addr: commonAddress } }>  
                      <button type="button" class="btn btn-dark">Edit</button></NavLink> 
                </fieldset> 
                   ) :(
                    null
                   )}

                   {billAddrFlag ?  (

                    <fieldset class="border border-dark">

                            <p class="fw-semibold">Billing Address:</p>
                            
                            <h5><strong>{billingAddr.fullName}  &nbsp;&nbsp; {billingAddr.phone}</strong> </h5>
                            <h6> {billingAddr.streetAddress} </h6>
                            <h6> {billingAddr.city} ,  {billingAddr.state} -  {billingAddr.pincode}</h6>
                            
                            <NavLink to={`/updateuseraddress/${billingAddr.id}`} state={ { addr: billingAddr } }>
                            <button type="button" class="btn btn-dark">Edit</button> </NavLink>
                    </fieldset> 
                   ) :(
                    null
                   )}

                                          <br/>  <br/>  <br/>

                  { shipAddrFlag ? (

                    <fieldset class="border border-dark mt-3">
                        <p class="fw-semibold">Shipping Address:</p>
                                          
                        <h5><strong>{shippingAddr.fullName}  &nbsp;&nbsp; {shippingAddr.phone}</strong> </h5>
                        <h6> {shippingAddr.streetAddress} </h6>
                        <h6> {shippingAddr.city} ,  {shippingAddr.state} -  {shippingAddr.pincode}</h6>
                        
                        <NavLink to={`/updateuseraddress/${shippingAddr.id}`} state={ { addr: shippingAddr } }> 
                        <button type="button" class="btn btn-dark" >Edit</button></NavLink>
                    </fieldset> 

                  ):(
                   <>
                    {/* <p class="fw-semibold">Add Shipping Address:</p>
                    <button type="button" class="btn btn-light" onClick={()=>addShipAddress()}>Add Shipping Address</button>
                    {showAddrFlag ? addressForm() : (null)} */}
                    </>
                  )}                        
                  
                   {/* </div> */}
                   
                     </div>
                <div  className="row mt-3">
                </div>
        </div>
        
    </div>
</div>
  </div>
</div>



  );
};

export default UserInfo;
