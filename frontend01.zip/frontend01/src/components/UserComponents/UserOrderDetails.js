import React, { useState,useEffect } from "react";
import { useNavigate,useParams } from "react-router-dom";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import AdminService from "../../services/admin.service";
import { NavLink } from 'react-router-dom';
import postService from "../../services/post.service";
import "./UserOrderDetailsCSS.css";
import Swal from 'sweetalert2';
const OrderDetails = () => {
  const {id}=useParams();
  const navigate = useNavigate();
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
    const [name, setName] = useState();
    const [address, setAddress] = useState({});
    const [orderedProducts, setOrderedProducts] = useState([]);
    const [ordersDTO, setOrderDTO] = useState({});
    const [total,setTotal] = useState(0);
    const [finaltotal,setFinaltotal] = useState(0);
    const [shipCharge,setShipCharge] = useState(0);
    const [deliveryStatus,setdeliveryStatus] = useState(0);
  const [ordercancel, setOrdercancel] = useState(0);

  const [password, setPassword] = useState("");

  

  const fetchData =()=>{
    console.log("in OrderDetails fetch data");
    postService.getUserOrderDetails(id).then(
      (val)=>{
        console.log(val.data);
        setAddress(val.data.address);
        setName(val.data.name);
        setOrderedProducts(val.data.orderedProducts.list);
        setOrderDTO(val.data.userOrderDTO);
        let total=0;
        let plist=val.data.orderedProducts.list;
        plist.map((p)=>{
            total+=p.product.price*p.quantity;
        })
        setTotal( total);

        if(total<1000 && total!=0){
          setShipCharge( shipCharge=>50);
          setFinaltotal(finaltotal => total+50);
        }else{
          setFinaltotal(total);
        }
        console.log(val.data.userOrderDTO.delivery_status)
        switch (val.data.userOrderDTO.delivery_status)
          {
            case "processing":
              setdeliveryStatus(0);
              //console.log("in Switch processing")
                break;
            case "Picked by courier":
              setdeliveryStatus(1);
              //console.log("in Switch Picked by courier")
                break;
            case "In Transit":
              setdeliveryStatus(2);//console.log("in Switch Transit")
                break;
            case "Delivered":
              setdeliveryStatus(3);//console.log("in Switch Delivered")
                break;
             default:
              setdeliveryStatus(0);
                 break;
          }


      },
    
              (error) => {
                console.log(error);
              }
    )
}

  useEffect(()=>{
      fetchData();
      //console.log(user);
  },[])
  const generatePdf=()=>{
    console.log("Invoice TOOOOO");
    navigate(`/invoice/${id}`);
  }
  const cancelOrder=()=>{
    postService.cancelUserOrder(ordersDTO.id).then((resp)=>{
      console.log(resp.data);
      if(resp.data==="Cancelled"){
        Swal.fire({
          icon: 'success',
          title: 'Ordered Cancelled',
          
        })
        setOrdercancel(1);
      }
    })
    
  }
  useEffect(()=>{
    fetchData();
    console.log("In OrderCancel State CHange");
},[ordercancel])

  return (
    <div>
   

      <div class="container mt-5 mb-5">
      <div class="d-flex justify-content-end"> <button type="button" class="btn btn-secondary" onClick={()=>generatePdf()}>Download Invoice</button>
 </div>
          
<div class="row d-flex justify-content-center">
<div class="col-md-12 col-lg-12 ">
<div class="card">
<div class="invoice p-5">

 <h5>  Your order Details</h5>{/* <span class="font-weight-bold d-block mt-4">Hello, Chris</span> <span>You order has been confirmed and will be shipped in next two days!</span> */}
 
 

<div class="payment border-top mt-3 mb-3 border-bottom table-responsive">
<table class="table table-borderless">
<tbody>
<tr>

<td>
<div class="py-2"> <span class="d-block text-muted">Billing Address</span> 
<span> {address.fullName} &nbsp; &nbsp; &nbsp;{address.phone} <br/> {address.streetAddress} <br/>{address.city}, {address.state}-{address.pincode}</span> </div>
</td>
<td> 
<div class="py-2"> <span class="d-block text-muted">Order Id: # {ordersDTO.id}</span> 
<span> {ordersDTO.orderDate}<br/> 
Payment Id: {ordersDTO.paymentId} <br/>
Status: {ordersDTO.status}</span> </div>
 
</td>
</tr>
</tbody>
</table>
</div>
<div class="payment mt-3 mb-3 border-bottom table-responsive">

{ordersDTO.status!=="Cancelled" ? (
<div class="track">
                <div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order confirmed</span> </div>
                <div class={"step "+ (deliveryStatus > 0 ? "active":"") }> <span class="icon"> <i class="fa fa-user"></i> </span> <span class="text"> Picked by courier</span> </div>
                <div class={"step "+ (deliveryStatus > 1 ? "active":"") }> <span class="icon"> <i class="fa fa-truck"></i> </span> <span class="text"> On the way </span> </div>
                <div class={"step "+ (deliveryStatus > 2 ? "active":"") }> <span class="icon"> <i class="fa fa-home"></i> </span> <span class="text">Delivered</span> </div>
            </div>
):(<div class="track">
<div class="step active"> <span class="icon"> <i class="fa fa-check"></i> </span> <span class="text">Order Cancelled</span> </div>
<div class={"step " }> <span class="icon"> <i class="fa fa-money"></i> </span> <span class="text"> Refund Initiated</span> </div>
<div class={"step " }> <span class="icon"> <i class="fa fa-money"></i> </span> <span class="text">Amount Refunded </span> </div>
{/* <div class={"step "+ (deliveryStatus > 2 ? "active":"") }> <span class="icon"> <i class="fa fa-box"></i> </span> <span class="text">Delivered</span> </div> */}
</div>)}
            <br/><br/><br/>
            </div>
<div class="product border-bottom table-responsive">
<table class="table table-borderless">
<tbody>
  {orderedProducts.map((p)=>(
    <tr key={p.product.id}>
<td width="20%"> <img src={API_URL+p.product.image.split('#')[0]}width="90"/> </td>
<td width="40%"> <span class="font-weight-bold">{p.product.productName}</span>
<div class="product-qty"> <span class="d-block">Quantity:&nbsp; {p.quantity}</span> <span>Category:&nbsp; {p.product.categoryName}</span> </div>
</td>
<td width="27%"><span class="font-weight-bold"> {p.product.price}</span></td>
<td width="20%">
<div class="text-right"> <span class="font-weight-bold">₹ { p.product.price* p.quantity }</span> </div>
</td>
</tr>
  ))}


</tbody>
</table>
</div>
<div class="row d-flex justify-content-end">
<div class="col-md-5">
<table class="table table-borderless">
<tbody class="totals">
<tr>
<td>
<div class="text-left"> <span class="text-muted">Subtotal</span> </div>
</td>
<td>
<div class="text-right"> <span>₹ { total}</span> </div>
</td>
</tr>


<tr>
<td>
<div class="text-left"> <span class="text-muted">Shipping Fee</span> </div>
</td>
<td>
<div class="text-right"> <span>₹ { shipCharge}</span> </div>
</td>
</tr>

{/* <tr>
<td>
<div class="text-left"> <span class="text-muted">Tax Fee</span> </div>
</td>
<td>
<div class="text-right"> <span>$7.65</span> </div>
</td>
</tr> */}
{/* <tr>
<td>
<div class="text-left"> <span class="text-muted">Discount</span> </div>
</td>
<td>
<div class="text-right"> <span class="text-success">$168.50</span> </div>
</td>
</tr> */}
<tr class="border-top border-bottom">
<td>
<div class="text-left"> <span class="font-weight-bold">Total</span> </div>
</td>
<td>
<div class="text-right"> <span class="font-weight-bold">₹ { finaltotal}</span> </div>
</td>
</tr>
</tbody>
</table>
</div>
</div>
{/* <p>We will be sending shipping confirmation email when the item shipped successfully!</p>
<p class="font-weight-bold mb-0">Thanks for shopping with us!</p> <span>Nike Team</span> */}



</div>
{/* <div class="d-flex justify-content-between footer p-3"> <span>Need Help? visit our <a href="#"> help center</a></span> <span>12 June, 2020</span> </div>
 */}
 {ordersDTO.status!=="Cancelled" ? (<div class="d-flex justify-content-end footer p-3"> <span><button type="button" class="btn btn-secondary" onClick={()=>cancelOrder()}>Cancel Order</button></span>  </div>
 ):(null)}
 
 </div>
</div>
</div>
</div> 



    </div>
      
  );
};

export default OrderDetails;
