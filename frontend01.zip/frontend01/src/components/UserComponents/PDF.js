import React, { useState,useEffect } from "react";
import { useNavigate,useParams } from "react-router-dom";
//import img1 from "./../../images/logo.jpg";
import sign from "./../../images/Signature.jpg";
import 'bootstrap/dist/css/bootstrap.min.css';
import './pdfCSS.css';
import jsPDF from 'jspdf';
import pdfMake from 'pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
import htmlToPdfmake from 'html-to-pdfmake';
import postService from "../../services/post.service";
function PDF() {
    const {id}=useParams();
    const [name, setName] = useState();
    const [address, setAddress] = useState({});
    const [total, settotal] = useState();
    const [gst, setGST] = useState();
    const [subtotal, setSubtotal] = useState();
    const [orderedProducts, setOrderedProducts] = useState([]);
    const [ordersDTO, setOrderDTO] = useState({});
    
   const printDocument=()=> {
         const doc = new jsPDF();
         
          //get html
          const pdfTable = document.getElementById('divToPrint');
          //html to pdf format
          var html = htmlToPdfmake(pdfTable.innerHTML);
        
          const documentDefinition = { content: html };
          pdfMake.vfs = pdfFonts.pdfMake.vfs;
          pdfMake.createPdf(documentDefinition).open();
        
    }
    const fetchData =()=>{
        console.log("in OrderDetails fetch data");
        postService.getUserOrderDetails(id).then(
          (val)=>{
            console.log(val.data);
            setAddress(val.data.address);
            setName(val.data.name);
            setOrderedProducts(val.data.orderedProducts.list);
            setOrderDTO(val.data.userOrderDTO);
            let total=0;
            let products=val.data.orderedProducts.list;
            products.map((p)=>{
                    total+=p.product.price*p.quantity;
            });
            let GST=total-(total*100/(118));
            setSubtotal(total-GST.toFixed(2));
            setGST(GST.toFixed(2));
            settotal(total);
          },
        
                  (error) => {
                    console.log(error);
                  }
        )
    }
    
      useEffect(()=>{
          fetchData();
          //console.log(user);
      },[])

   
    return (
    <div className="App container mt-5">
         <div class="d-flex justify-content-end">
        <button class="btn btn-primary " onClick={()=>printDocument()}>Export To PDF</button>
    
        </div>
     <div id="divToPrint" className="m-3">
    <div class="row d-flex justify-content-center">
      <div class="col-md-8">
          <div class="card">
              <div class="d-flex flex-row p-2">
                  <div class="d-flex flex-column"> <span class="font-weight-bold">Tax Invoice</span> <small>INV-#00{id}</small> </div>
                  {/* <div class="d-flex align-items-end"> <span class="font-weight-bold">Tax Invoice</span> <small>INV-#00{id}</small> </div> */}
                  
        </div>
              
              <hr />
              <div class="table-responsive p-2">
                  <table class="table table-borderless">
                      <tbody>
                          <tr class="add">
                              <td>To</td>
                              <td>From</td>
                          </tr>
                          <tr class="content">
                              <td class="font-weight-bold">{address.fullName}  <br />{address.city} <br />{address.state} -{address.pincode} </td>
                              <td class="font-weight-bold">Amigotech.in <br />Techno-parts provider<br /> India</td>
                          </tr>
                      </tbody>
                  </table>
              </div>
              <hr />
              <div class="products p-2">
                  <table class="table table-borderless">
                      <tbody>
                          <tr class="add">
                              <td>Description</td>
                              <td>Quantity</td>
                              <td>Price</td>
                              <td class="text-center">Total</td>
                          </tr>

                          {orderedProducts.map((data)=>(
                             <tr class="content">
                             <td>{data.product.productName}</td>
                             <td>{data.quantity}</td>
                             <td>₹{data.product.price}</td>
                             <td class="text-center">₹{data.product.price * data.quantity}</td>
                         </tr>


                          ))}
                         
                         
                      </tbody>
                  </table>
              </div>
              <hr />
              <div class="products p-2">
                  <table class="table table-borderless">
                      <tbody>
                          <tr class="add">
                              <td></td>
                              <td>Subtotal</td>
                              <td>GST(18%)</td>
                              <td class="text-center">Total</td>
                          </tr>
                          <tr class="content">
                              <td></td>
                              <td>₹{subtotal}</td>
                              <td>₹{gst}</td>
                              <td class="text-center">₹{total}</td>
                          </tr>
                      </tbody>
                  </table>
              </div>
              <hr />
              <div class="address p-2">
                  <table class="table table-borderless">
                      <tbody>
                          <tr class="add">
                          {/* <td> </td><td></td><td className="py-0"><img src={sign} style={{ width:'100px', height:'30px' }} /></td> */}
                            
                          </tr>
                                                
                          <td> </td><td>Thank You For Shopping,<br/>Visit Again.</td><td></td>
                          
                          <tr class="content">
                          {/* <td> <img src={img1} style={{ width:'100px', height:'30px' }} /></td><td></td><td></td> */}
                              
                               </tr>
                      </tbody>
                  </table>
              </div>
          </div>
      </div>
  </div>
      </div>
      
      
    </div>
 );
}

export default PDF;