import React, { useState ,useEffect} from "react";
import { useNavigate } from "react-router-dom";
import postService from "../../services/post.service";
import { NavLink } from 'react-router-dom';
import $ from 'jquery';
import Swal from 'sweetalert2';
import authService from "../../services/auth.service";

const ChangePassword = () => {
  
  const [currentUserInfo, setCurrentUserInfo] = useState({});
  const [currentUserName, setCurrentUserName] = useState([]);
  const [oldpass, setOldPass] = useState();
  const [newpass1, setNewPass1] = useState();
  const [newpass2, setNewPass2] = useState();
  const [userEmail, setUserEmail] = useState();
  const [userId, setUserId] = useState();
  const navigate = useNavigate();
  useEffect(() => {
    
     
        let user=postService.getLoggedUser();
        console.log(user);
        setUserEmail(user[0]);
        setUserId(user[1]);
        console.log(user[2]);
      
    
  }, []);
  
const changepassword= (e)=>{
  e.preventDefault();

    console.log(oldpass);
    if(newpass1===newpass2){
      console.log("pass Matched");
      authService.changeUserPassword(userId,oldpass,newpass1).then((resp)=>{
         
      let pass=resp.data.message;
      console.log(pass); 
        if(pass==="Success"){
              Swal.fire({
                    icon: 'success',
                title: 'password Changed'
              
                   });
        }else{
          Swal.fire({
              icon: 'error',
              title: 'Incorrect old password'
                 
            })
        }

      })

    }else{
      Swal.fire({
        icon: 'error',
        title: 'enter same password'
           
      })
    }
    
      
    
    
    
    
    // alert("Mobile No is Not Valid");
      // Swal.fire({
      //   icon: 'error',
      //   title: 'Mobile No is Not Valid'
           
      // })
 
  
  
  
    
    
}


  return (
   
    <div >

 
 <div className="container rounded bg-white mt-5 mb-5">
    <div className="row">
        
            
      <form id="userprofile" onSubmit={changepassword}>

        <div class="col-md-12 border-right">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-center align-items-center mb-3">
                    <h4 class="text-right" style={{color:"green"}} >Change Password</h4>
                </div>
               
                

                <div class="row mt-3">
                    <div class="col-md-12"><label class="labels">Enter Old Password</label><input type="text" name="oldPass" class="form-control" onChange={(e)=>setOldPass(e.target.value)} /></div>
                    <div class="col-md-12"><label class="labels">Enter New Password</label><input type="text" name="newPass1" class="form-control" onChange={(e)=>setNewPass1(e.target.value)}/></div>
                    <div class="col-md-12"><label class="labels">Enter New Password Again</label><input type="text" name="newPass2" class="form-control" onChange={(e)=>setNewPass2(e.target.value)} /></div>
            
                   
                 </div>
                
                <div class="mt-5 text-center"><button class="btn btn-primary profile-button" type="submit">Save Profile</button></div>


            </div>
        </div>
        </form>
    </div>


    


</div>




</div>



  );
};

export default ChangePassword;
