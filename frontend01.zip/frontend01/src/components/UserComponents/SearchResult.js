import React, { useState, useEffect } from "react";
import { useParams } from 'react-router';

import ProductCard from "../ProductCard";
import { useNavigate,useLocation } from "react-router-dom";
import postService from "../../services/post.service";

const SearchResult = () => {
    const location=useLocation();
    const { category,searchtext } = useParams();
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  const[search,setSearch]=useState(searchtext);
  //const[search,setSearch]=useState(location.state.search);
  const [count, setCount] = useState(3);  
  const [pageNo, setPageNo] = useState(0); 
  const [totalPages, setTotalPages] = useState(2); 
  const [products, setProducts] = useState([]);
  const[filteredlist,setFilteredlist]=useState([]);
  const [productsList, setProductsList] = useState([]);
  const [isLoading, setisLoading] = useState(true);
  const [sort, setSort] = useState("popular");
  const page =[] ;
  for(let i=1;i<=totalPages;i++){
    page.push(
        <li className={`page-item ${ pageNo === i-1 ? "active":""} `} key={"li-"+i}> <a class="page-link" key={"lia-"+i} onClick={()=>changePage(i-1)}>{i}</a></li> 
                    

    );
    
    }
  const fetchData =()=>{
    console.log(category,searchtext);
    setSearch(searchtext);
    //setPageNo(p);
   console.log(pageNo);
    postService.getProductPage(category,searchtext,count,pageNo).then((resp)=>{
        //console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
        console.log(resp.data);
        //console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
        setFilteredlist(resp.data.list)
        setProducts(resp.data.list);
        setTotalPages(resp.data.totalPages);
        //console.log(resp.data.totalPages);
    
    })

    
}


const changePage=(p)=>{
    console.log(p);
    setPageNo(p);
    fetchData(p);
}
//fetch Data for the first time
useEffect(()=>{
    fetchData();
    console.log("in default fetchdata useEffect");
},[])
  
useEffect(()=>{
    fetchData();
    console.log("in Page No fetchdata useEffect");
},[pageNo])

    useEffect(()=>{
        fetchData();
        console.log("in Searchtext state change useEffect");
           
    },[searchtext])

///UseEffect To Render Filtered List    
useEffect(()=>{
      
        console.log("in filteredlist state change useEffect");
    
          
},[filteredlist])
useEffect(()=>{
    fetchData();
    console.log("in Count state change useEffect");
},[count])

// Sorting     
useEffect(()=>{
    //console.log(sort);
    var tobesorted=products;
  
    if(sort==="popular"){
        console.log("in popular");
        var sorted=tobesorted.sort((b,a)=> a.visits-b.visits);  
        setFilteredlist(sorted);
        //setProducts(sorted);
    }else if(sort==="low price"){
        console.log("in Low Price");
        // var sorted1=tobesorted2.sort((a,b)=> a.price-b.price);  
        setFilteredlist((tobesorted) => tobesorted.slice().sort((a,b)=> a.price-b.price));
        //setProducts(sorted);
    }else if(sort==="high price"){
        console.log("in high Price");
        //var sorted2=tobesorted3.sort((b,a)=> a.price-b.price);  
        setFilteredlist((tobesorted) => tobesorted.slice().sort((b,a)=> a.price-b.price));
        //setProducts(sorted);
    }
    // console.log("in sort");
      
    },[sort])

  


 
  return (

    <div>

            {products.length>0 &&(<>
               
                 <div className="row mt-2">
                 <div className="col-md-2 d-flex">
                  
                  <div class="btn-group">
<button type="button" class="btn btn-outline-dark btn-sm dropdown-toggle"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
 Sort
</button>
<div class="dropdown-menu">
 
 <a class="dropdown-item" href="#" onClick={(e)=>setSort("low price")}>Sort by Price: Low to High</a>
 <a class="dropdown-item" href="#" onClick={(e)=>setSort("high price")}>Sort by Price: High to Low</a>
 
 <a class="dropdown-item" href="#" onClick={(e)=>setSort("popular")}>Sort by Popularity</a>
</div>
</div>
                  {/* <select className="form-select justify-content-right"  aria-label="Default select example" onChange={(e)=>setSort(e.target.value)}>
                          <option defaultValue>Sort By</option>
                          <option value="low price">Sort by Price: Low to High</option>
                          <option value="high price">Sort by Price: High to Low</option>
                          <option value="popular">Sort by Popularity</option>
                 </select> */}

                  </div>
                        <div className="col-md-10 d-flex">
                        
                        </div>
                        
            </div>
               
             </>
            )}




                {filteredlist.length > 0 ? (

                    <ProductCard product={filteredlist}/>
                ): (
                    <h1 className="justify-content-center"> No products found </h1>
                )}
          
            <nav aria-label="Page navigation example">
            
                <ul className="pagination justify-content-end">
                    <div></div>
                <select className="form-select  justify-content-right" style={{width:"18%"}} aria-label="Default select example" onChange={(e)=>setCount(e.target.value)}>
                             <option value="3">3 Products Per Page</option>
                             <option value="4">4 Products Per Page</option>
                             <option value="5">5 Products Per Page</option>
                             <option value="6">6 Products Per Page</option>
                    </select>  &nbsp; &nbsp;
                     <li className="page-item disabled">
                        <a className="page-link" href="#" tabIndex="-1">Previous</a>
                    </li>
                                       
                        {page}
                      <li className="page-item"> <a className="page-link" href="#">Next</a></li>
                    
                </ul>
            </nav>
    
    
    </div>
        
      
  
  );
};

export default SearchResult;




//   const product={ 
//     id,
//   productName,
//   "description": "ARDUINO MICROCONTROLLER",
//   "categoryName": "MICROCONTROLLER",
//   "price": 550,
//   "stock": 120,
//   "sku": "ARDU01"
// }