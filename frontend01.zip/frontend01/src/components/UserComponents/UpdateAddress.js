import React, { useState, useEffect } from "react";
import { useNavigate, useParams,useLocation } from "react-router-dom";
import postService from "../../services/post.service";
import AdminService from "../../services/admin.service";
import { NavLink } from 'react-router-dom';
import ImageService from "../../services/image.service";
import $ from 'jquery';
import Swal from 'sweetalert2';
const UpdateAddress = (props) => {
  const location = useLocation();
  const navigate = useNavigate();
  const {adrid}=useParams();
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  const [address, setAddress] = useState(location.state.addr);
  const [showPic, setPic] = useState({});
  const [imgFlag, setImgflag] = useState(false);
  const [product, setProduct] = useState();
  const [categories, setCategories] = useState([]);
  const [productName, setProductName] = useState();
  const [description, setDescription] = useState();
  const [categoryName, setCategoryName] = useState("WIFI Controller");
  console.log(location.state.addr);
  

  useEffect(() => {
   
  }, []);


  


const arrayToAddreessObject=(sameAddress,adrtype)=>{
  var data = sameAddress.reduce(function(obj, item) {
    obj[item.name] = item.value;
    obj["type"] = adrtype;
    return obj;
    }, {});
    return data;
}

const saveAddress=(e)=>{
  e.preventDefault();
  
  var sameAddress=$('#addr').serializeArray();
  console.log(sameAddress);
  console.log(arrayToAddreessObject(sameAddress));
  let commonAddress=arrayToAddreessObject(sameAddress,address.type);
  postService.updateUserAddress(adrid,commonAddress).then((resp)=>{

    console.log(resp);
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 2000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    })
    
    Toast.fire({
      icon: 'success',
      title: 'Address Saved'
    });



    navigate("/userprofile");


  })
}

  return (
    <div class="container">


  <div class="row mx-0 justify-content-center">
    {/* <div class="col-md-8 col-lg-12 px-lg-2 col-xl-4 px-xl-0 px-xxl-3"> */}
    <div class="col-md-8 col-lg-12">
      <form id="addr"
         class="w-100 rounded-1 p-4 border bg-white"
         onSubmit={saveAddress}
        >
        <label class="d-block mb-4">
          <span class="form-label d-block">Your Full Name</span>
          <input
            name="fullName"
            type="text"
            class="form-control"
            placeholder={address.fullName}
            required
            />
        </label>

        <label class="d-block mb-4">
          <span class="form-label d-block">Street Address</span>
          <textarea class="form-control" name="streetAddress" 
               placeholder={address.streetAddress}
              id="exampleFormControlTextarea1" maxLength="100" rows="3"   required></textarea>
        </label>
        <label class="d-block mb-4">
          <span class="form-label d-block">City</span>
          <input name="city" type="text" class="form-control"   required placeholder={address.city} />
        </label>

        <label class="d-block mb-4">
          <span class="form-label d-block">State</span>
          <input name="state" type="text" class="form-control"   required placeholder={address.state} />
        </label>

        <label class="d-block mb-4">
          <span class="form-label d-block">Zip/Postal code</span>
          <input name="pincode" type="text" class="form-control"   required placeholder={address.pincode} />
        </label>

        <label class="d-block mb-4">
          <span class="form-label d-block">Country</span>
          <input
            name="country"
            type="text"
            class="form-control"   required
            placeholder={address.country}
          />
        </label>

        <label class="d-block mb-4">
          <span class="form-label d-block">Mobile No.</span>
          <input
            name="phone"
            type="text"
            class="form-control"   required
            placeholder={address.phone}
          />
        </label>
          <div class="mb-3">
          <button type="submit" class="btn btn-outline-primary px-3 rounded-3">
            Save
          </button>
          <div className="d-flex justify-content-end">

  
<NavLink to={`/userprofile`}> <button  className="btn btn-outline-primary mb-2 mx-5" >Back</button></NavLink>
</div>
        </div>
        
     
      </form>

      
    </div>
  </div>
</div>
    
  );
}

export default UpdateAddress;
