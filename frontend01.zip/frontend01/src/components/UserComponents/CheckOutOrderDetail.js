import React, { useState ,useEffect} from "react";
import { useNavigate,useLocation} from "react-router-dom";
import postService from "../../services/post.service";
import "./../UserProfileCSS.css";
import { NavLink } from 'react-router-dom';
import Table from 'react-bootstrap/Table';

const CheckOutOrderDetails = () => {
  const location = useLocation();
  const navigate = useNavigate();
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  const [userId,setUserId]= useState(location.state.id);
    const [userCart,setUserCart] = useState(location.state.cart);
    const [total,setTotal] = useState(location.state.total);
    const [finaltotal,setFinaltotal] = useState(0);
    const [shipCharge,setShipCharge] = useState(0);
    const [shippingAddr,setShippingAddr] = useState(location.state.ship);
    console.log(location.state.ship);
    // if(location.state.ship){
    //   console.log("In CheckOutOrderDetails IFFFF first ")
    //   navigate("/userprofile");
    // }
  const fetchData =()=>{

    // let user=postService.getLoggedUser();
    //     console.log(user);
    //     console.log(user[2]);
    //     console.log(userCart);
    // postService.getUserAddress(userId).then((resp)=>{
    //   console.log(resp.data);
    //   let adrArry=resp.data;
    //   var art=adrArry.filter((p)=> p.type==="BOTH" || p.type=="SHIP");
    //   console.log(art);
    //   setShippingAddr(art[0]);
    // })    
    
    if(total<1000 && total!=0){
      setShipCharge( shipCharge=>50);
      setFinaltotal(finaltotal => total+50);
    }else{
      setFinaltotal(total);
    }
   
}

useEffect(()=>{
    fetchData();
    
},[])
const backtoAddAddress=()=>{
  navigate("/userprofile");
}

  return (
   
    <div >

{/* <div class="container mt-5 mb-5">
<div class="row d-flex justify-content-center">
<div class="col-md-12 col-lg-12 ">
<div class="card"> */}
{/* <div class="text-left logo p-2 px-5"> <img src="https://i.imgur.com/2zDU056.png" width="50"/> </div> */}
<div class="invoice p-5">
 <h5>  Your order Details</h5>
<div class="payment border-top mt-3 mb-3 border-bottom table-responsive">
<table class="table table-borderless">
<tbody>
<tr>

<td>
<div class="py-2"> <span class="d-block text-muted">Billing Address</span> 
{shippingAddr ? (<span> {shippingAddr.fullName} &nbsp; &nbsp; &nbsp;{shippingAddr.phone} <br/> {shippingAddr.streetAddress} <br/>{shippingAddr.city}, {shippingAddr.state}-{shippingAddr.pincode}</span> 
):(<span> Please add address information to make order first 
</span>)}
</div>

</td>
</tr>
</tbody>
</table>
</div>
<div class="product border-bottom table-responsive">
<table class="table table-borderless">
<tbody>
  {userCart.map((p)=>(
    <tr key={p.product.id}>
<td width="20%"> <img src={API_URL+p.product.image.split('#')[0]}width="90"/> </td>
<td width="40%"> <span class="font-weight-bold">{p.product.productName}</span>
<div class="product-qty"> <span class="d-block">Quantity:&nbsp; {p.quantity}</span> <span>Category:&nbsp; {p.product.categoryName}</span> </div>
</td>
<td width="27%"><span class="font-weight-bold"> {p.product.price}</span></td>
<td width="20%">
<div class="text-right"> <span class="font-weight-bold">₹ { p.product.price* p.quantity }</span> </div>
</td>
</tr>
  ))}


</tbody>
</table>
</div>
<div class="row d-flex justify-content-end">
<div class="col-md-5">
<table class="table table-borderless">
<tbody class="totals">
<tr>
<td>
<div class="text-left"> <span class="text-muted">Subtotal</span> </div>
</td>
<td>
<div class="text-right"> <span>₹ { total}</span> </div>
</td>
</tr>


<tr>
<td>
<div class="text-left"> <span class="text-muted">Shipping Fee</span> </div>
</td>
<td>
<div class="text-right"> <span>₹ { shipCharge}</span> </div>
</td>
</tr>

{/* <tr>
<td>
<div class="text-left"> <span class="text-muted">Tax Fee</span> </div>
</td>
<td>
<div class="text-right"> <span>$7.65</span> </div>
</td>
</tr> */}
{/* <tr>
<td>
<div class="text-left"> <span class="text-muted">Discount</span> </div>
</td>
<td>
<div class="text-right"> <span class="text-success">$168.50</span> </div>
</td>
</tr> */}
<tr class="border-top border-bottom">
<td>
<div class="text-left"> <span class="font-weight-bold">Total</span> </div>
</td>
<td>
<div class="text-right"> <span class="font-weight-bold">₹ { finaltotal}</span> </div>
</td>
</tr>
</tbody>
</table>
</div>
</div>


{/* <p>We will be sending shipping confirmation email when the item shipped successfully!</p>
<p class="font-weight-bold mb-0">Thanks for shopping with us!</p> <span>Nike Team</span> */}



</div>

 
 {/* </div>
</div>
</div>
</div>  */}

    </div>


 
  );
};

export default CheckOutOrderDetails;
