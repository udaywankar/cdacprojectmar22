import React from 'react';
import { useState,useEffect } from 'react';
import { Zoom } from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'


function BannerSlider({name}) {
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  //const [imageArray,setImageArray]=useState(props.name)
 console.log(name);
 console.log(name.length);

  useEffect(()=>{
    //console.log(props.name);
    
},[])
    return (
      // <div className="slide-container">
      //   <Zoom scale={0.4}>
      //     {
      //       name.map((each, index) => <img key={index} style={{width: "100%"}} src={API_URL +each} />)
      //     }
      //   </Zoom>
      // </div>
 
             
          
          <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            
          <div className="carousel-item active" >
                       <img src={API_URL +"banner01.jpg"} className="d-block w-100" alt="..."/>
                  </div>
                  <div className="carousel-item " >
                       <img src={API_URL +"banner02.jpg"} className="d-block w-100" alt="..."/>
                  </div>
                  <div className="carousel-item " >
                       <img src={API_URL +"banner03.jpg"} className="d-block w-100" alt="..."/>
                  </div>
                  <div className="carousel-item " >
                       <img src={API_URL +"banner04.jpg"} className="d-block w-100" alt="..."/>
                  </div>
                  



          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>     
    
    
 




    )
}

export default BannerSlider;