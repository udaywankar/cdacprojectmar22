import React, { useState , useEffect} from "react";
import { useNavigate, useParams } from "react-router-dom";
import Table from 'react-bootstrap/Table';
import postService from "../../services/post.service";
import DeleteIcon from '@material-ui/icons/Delete';
import { NavLink } from 'react-router-dom';
import AdminService from "../../services/admin.service";
import ClipLoader from "react-spinners/ClipLoader";
const ProductManagement = () => {
 
    const [post, setPost] = useState([]);
  const [email, setEmail] = useState("");

  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const fetchData =()=>{
    postService.getAllProducts().then(
      (val)=>{
        console.log(val.data);
        setPost(val.data);
      },
    
              (error) => {
                console.log(error);
              }
    )
}

  useEffect(()=>{
      fetchData();
      //console.log(user);
  },[])
  
const deleteProduct=(id)=>{
  console.log(id);
  AdminService.deleteProduct(id).then((resp)=>{
    console.log(resp);
    console.log(resp.data);
    if(resp.data.message==="Product is Used in Othe tables"){
      alert("Unable to Delete as Product is in Use")
    }
    window.location.reload(false);
  },(error)=>{
    console.log('Error', error.message);
    console.log(error.config);
  });
}


  return (
    <div>
       <div  className="d-flex justify-content-center  mb-3">
                    <h4  className="text-center" style={{color:"green"}} >Product Management</h4>
                </div>
                <div  className="d-flex justify-content-end  mb-3">
                <NavLink to={`/addproduct`}> <button type="submit" className="btn btn-primary mb-2" >Add New Product</button></NavLink>
          </div>
        
        {post.length >0 ? (

        <Table striped bordered hover size="sm" variant="light">
      <thead>

        
        <tr>

          <th>#id</th>
          <th>product Name</th>
          <th>category Name</th>
          <th>price</th>
          <th>stock</th>
          <th>Operation</th>
          
        </tr>
      </thead>
      <tbody>


      {post.map((product)=>(
        <tr key={product.id}>
          <td>{product.id}</td>
          <td>{product.productName}</td>
          <td>{product.categoryName}</td>
          <td>{product.price}</td>
          <td>{product.stock}</td>
          <td> &emsp; <NavLink to={`/updateproduct/${product.id}`}><i className="bi bi-pen"/></NavLink>   
             &emsp;
            <span onClick={()=>deleteProduct(product.id)}><DeleteIcon/></span>
                </td>
        </tr>
            
        ))}
        
        
      </tbody>
    </Table>
    ):( <>
      <div className=" d-flex justify-content-center"> <ClipLoader color={"#123abc"} loading={true}  size={250} /></div></>
     )}


    </div>
      
  );
};

export default ProductManagement;
//   const product={ 
//     id,
//   productName,
//   "description": "ARDUINO MICROCONTROLLER",
//   "categoryName": "MICROCONTROLLER",
//   "price": 550,
//   "stock": 120,
//   "sku": "ARDU01"
// }