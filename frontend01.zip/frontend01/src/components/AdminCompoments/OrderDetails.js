import React, { useState,useEffect } from "react";
import { useNavigate,useParams } from "react-router-dom";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import AdminService from "../../services/admin.service";
import { NavLink } from 'react-router-dom';

const OrderDetails = () => {
  const {id}=useParams();
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
    const [name, setName] = useState();
    const [address, setAddress] = useState({});
    const [orderedProducts, setOrderedProducts] = useState([]);
    const [ordersDTO, setOrderDTO] = useState({});
  const [email, setEmail] = useState("");

  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const fetchData =()=>{
    console.log("in OrderDetails fetch data");
    AdminService.getOrderDetails(id).then(
      (val)=>{
        console.log(val.data);
        setAddress(val.data.address);
        setName(val.data.name);
        setOrderedProducts(val.data.orderedProducts.list);
        setOrderDTO(val.data.userOrderDTO);
      },
    
              (error) => {
                console.log(error);
              }
    )
}

  useEffect(()=>{
      fetchData();
      //console.log(user);
  },[])
  

  return (
    <div 
    // style={{ height: '100%', position: 'absolute', left: '0px', width: '100%', overflow: 'hidden'}}
    >
   

      <Container fluid>
        <Row><h1>   Order Details    </h1></Row>
        <Row>
          <Col lg={3}>
          <div >
                <h5>Shipping Address:</h5>
                <address> <p><font size="5">{address.fullName}</font><br/><font size="4">{address.streetAddress}<br/>
{address.city}<br/>{address.state} - {address.pincode}<br/>Mob. No:{address.phone}
</font></p></address>
          </div></Col>
          <Col md={{ span: 4, offset: 4 }}>
          <h4> Order #{ordersDTO.id}</h4> 
          <h5> {ordersDTO.orderDate}</h5> 
          <h5>Payment Id: {ordersDTO.paymentId}</h5> 
          <h5>Total Amount: ₹ {ordersDTO.totalPrice}</h5> 
          <h4>Status: {ordersDTO.status}</h4>  
            </Col>
        </Row>
        
        <hr/>
        {orderedProducts.map((data)=>(<>
          <Row  xs={2} md={4} lg={8} key={data.product.id}>
        
        <Col  key={`col1 ${data.product.id}`} >
         <h4> {data.product.productName}</h4>
         <h5>SKU: {data.product.sku}</h5> 
        </Col>
          <Col key={`col2 ${data.product.id}`}>
          <img src={API_URL+data.product.image.split('#')[0]} style={{'height':'150px','width':'200px'}}></img> 
          </Col>
          <Col key={`col3 ${data.product.id}`}>
          <h3>Quantity: {data.quantity}</h3>
          </Col>
      
    </Row>
    <hr/>
    </>
         ))}
     
        <Row><NavLink to={`/adminservices`}> <button  className="btn btn-primary mb-2" >Back</button></NavLink>
</Row>


          
      </Container>
        


        
        
        
    



    </div>
      
  );
};

export default OrderDetails;
