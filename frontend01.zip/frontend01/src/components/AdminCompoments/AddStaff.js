import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import postService from "../../services/post.service";
import AdminService from "../../services/admin.service";
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import ImageService from "../../services/image.service";

const AddStaff = (props) => {
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  const [imageFile, setImageFile] = useState();
    const [showPic, setPic] = useState({});
    const [imgFlag, setImgflag] = useState(false);
  const [product, setProduct] = useState();
  
  const [email, setEmail] = useState();
  const [mobileNo, setMobileNo] = useState();
  const [department, setDepartment] = useState();
  const [staffName, setStaffName] = useState();
  const [panNo, setPanNo] = useState();
  const [password, setPassword] = useState();
  const [profileImage, setProfileImage] = useState();
  
  const [image, setImage] = useState();
  const [imageArray, setImageArray] = useState([]);
  const navigate = useNavigate();
  
  

  useEffect(() => {
    
    
    
   
  }, []);



const handleSubmit=(e)=>{
  e.preventDefault();
 
  
  var updatedStaff={
    
    "staffName": staffName,
    "department": department,
    "mobileNo": mobileNo,
    "panNo": panNo,
    "profileImage": profileImage,
    "password":password,
    "email":email
  }
  console.log(updatedStaff);

  
  AdminService.addNewStaff(updatedStaff).then((resp)=>{
    console.log(resp.data);
   
    console.log("  @@@@@@@  Navigation Tooo ");
    navigate("/adminservices");
  },
  (error)=>{
    console.log(error);
  });

}


useEffect(()=>{},[showPic])
    const handleChange=(event)=>{
            setImageFile(event.target.files[0]);
            setImgflag(true);
            console.log(imageFile);
    }
   
  const upload=(e)=>{
    e.preventDefault();


      const data = new FormData() 
      data.append('profile', imageFile);
      
      console.log(imageFile);
      ImageService.uploadImage(data).then((res) => { 
        console.log(res);
        
        
        setProfileImage(res.data.imageName);
        
      })

  }

//   const product={ 
//     id,
//   productName,
//   "description": "ARDUINO MICROCONTROLLER",
//   "categoryName": "MICROCONTROLLER",
//   "price": 550,
//   "stock": 120,
//   "sku": "ARDU01"
// }
  
  return (
    <div style={{margin:'auto'}}>
    
     <div className="container rounded bg-white mt-5 mb-5">
    <div className="row">
    <h3  className="d-flex justify-content-center" style={{color:"green"}} >Enrole New Staff Member</h3>
    
    
     <form>
  <div className="form-group">
    <label htmlFor="exampleFormControlInput1">Staff Name</label>
    <input type="text" className="form-control" id="exampleFormControlInput1"
     placeholder="staff Name"
     onChange={(e)=>setStaffName(e.target.value)}  />
  </div>
  <div className="form-group">
    <label htmlFor="exampleFormControlInput2">Staff Email</label>
    <input type="email" className="form-control" id="exampleFormControlInput2"
     placeholder="staff Email"
     onChange={(e)=>setEmail(e.target.value)}  />
  </div>
  
  
  <div className="form-group">
    <label htmlFor="exampleFormControlInput3">Contact No
    <input type="text" className="form-control" id="exampleFormControlInput3" 
    placeholder="Contact No"
    onChange={(e)=>setMobileNo(e.target.value)} /></label>
  </div>

  <div className="form-group">
    <label htmlFor="exampleFormControlInput4">Password
    <input type="password" className="form-control" id="exampleFormControlInput4" placeholder="password"
    onChange={(e)=>setPassword(e.target.value)} /></label>
  </div>
  <div className="form-group">
    <label htmlFor="exampleFormControlInput5">PAN No
    <input type="text" className="form-control" id="exampleFormControlInput5" placeholder="PAN No"
    onChange={(e)=>setPanNo(e.target.value)} /></label>
  </div>
  
  <div className="form-group">
    <label htmlFor="exampleFormControlInput6">Department
    <input type="text" className="form-control" id="exampleFormControlInput6" placeholder="Department"
    onChange={(e)=>setDepartment(e.target.value)} /></label>
  </div>
  <br />
  <div className="form-group">
    <label htmlFor="exampleFormControlFile7">Profile Image<br />
    <input type="file" className="form-control-file" id="exampleFormControlFile7" onChange={handleChange} name="file" /></label>
    <div>
        {
          profileImage ? (<img src={ API_URL+profileImage } key={profileImage} style={{'height':'150px','width':'150px'}}></img>) : (<></>)
      

        }
    </div>
    {imgFlag ?  <img src={URL.createObjectURL(imageFile)} style={{'height':'250px','width':'250px'}}></img> : <></>}
            <br></br>
  
            <button onClick={upload} className="btn btn-outline-primary mb-2" >Upload Image</button>
  </div>

 </form>
 <div className="d-flex justify-content-center">
 <button type="submit" className="btn btn-outline-primary mb-2" onClick={(e)=>handleSubmit(e)}>Add Staff</button>

<NavLink to={`/adminservices`}> <button  className="btn  btn-outline-primary mb-2 mx-5" >Back</button></NavLink>
</div></div></div></div>
  );
};

export default AddStaff;
