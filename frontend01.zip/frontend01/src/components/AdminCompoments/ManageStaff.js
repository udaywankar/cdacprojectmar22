import React, { useState,useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Table from 'react-bootstrap/Table';
import ClipLoader from "react-spinners/ClipLoader";


import AdminService from "../../services/admin.service";
import { NavLink } from 'react-router-dom';

const ManageStaff = () => {
    
  const [staff, setStaff] = useState([]);
  const [sStatus, setsStatus] = useState("Processing");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const fetchData =()=>{
    AdminService.getAllStaff().then(
      (resp)=>{
        console.log(resp.data);
       setStaff(resp.data);
      },
    
              (error) => {
                console.log(error);
              }
   
    );
  }

const ChangeStatus=(e,id)=>{
  let sstatus=e.target.value
  console.log(e.target.value);
  console.log(id);
 
}
  useEffect(()=>{
      fetchData();
     
      //console.log(user);
  },[])
  

  return (
    <div>


      <div  className="d-flex justify-content-center  mb-3">
                    <h4  className="text-center" style={{color:"green"}} >Staff Management </h4>
                </div>
                <div  className="d-flex justify-content-end  mb-3">
                <NavLink to={`/addstaff`}> <button type="submit" className="btn btn-primary mb-2" >Add staff</button></NavLink>
      
                  </div>
        
         {staff.length >0 ? (
        <Table striped bsed hover size="sm" variant="light">
      <thead>
        <tr>
          <th>#StaffId</th>
          <th>Name</th>
          <th>Email</th>
          <th>Contact No</th>
          <th>Department</th>
          <th>Operations</th>
        </tr>
      </thead>
      <tbody>
        {staff.map((s)=>(
          <tr key={s.staffId}>
          <td>{s.staffId}</td>
          <td>{s.staffName}</td>
          <td>{s.email}</td>
          <td>{s.mobileNo}</td>
          <td>{s.department}</td>
                  
          <td>
          &emsp; <NavLink to={`#`}><button type="button" className="btn btn-primary mb-2" >Remove</button></NavLink> 
          </td>
        </tr>

        ))}
        
        
      </tbody>
    </Table> 

):( <>
  <div className=" d-flex justify-content-center"> <ClipLoader color={"#123abc"} loading={true}  size={250} /></div></>

)}

    </div>
      
  );
};

export default ManageStaff;
