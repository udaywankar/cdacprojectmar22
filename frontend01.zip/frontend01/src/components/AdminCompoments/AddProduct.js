import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import postService from "../../services/post.service";
import AdminService from "../../services/admin.service";
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import ImageService from "../../services/image.service";

const AddProduct = (props) => {
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  const [imageFile, setImageFile] = useState();
    const [showPic, setPic] = useState({});
    const [imgFlag, setImgflag] = useState(false);
  const [product, setProduct] = useState();
  const [categories, setCategories] = useState([]);
  const [productName, setProductName] = useState();
  const [description, setDescription] = useState();
  const [categoryName, setCategoryName] = useState();
  const [price, setPrice] = useState();
  const [stock, setStock] = useState();
  const [sku, setSku] = useState();
  const [image, setImage] = useState("empty");
  const [imageArray, setImageArray] = useState([]);
  const navigate = useNavigate();
  
  

  useEffect(() => {
    
    
    postService.getAllCategories().then((resp)=>{
      console.log(resp.data);
      let array=[];
      resp.data.map((val)=>{
        console.log(val.categoryName);
        array.push(val.categoryName);
      });
      console.log(array);
      setCategories(array);
    },
    (error)=>{
      console.log(error);
    });
   
  }, []);



const handleSubmit=(e)=>{
  e.preventDefault();
 
  
  var updatedproduct={
    
    "productName": productName,
    "description": description,
    "categoryName": categoryName,
    "price": price,
    "stock": stock,
    "sku":sku,
    "image":image
  }
  console.log(updatedproduct);

  
  AdminService.addProduct(updatedproduct).then((resp)=>{
    console.log(resp.data);
    console.log(categoryName);
    console.log("  @@@@@@@  Navigation Tooo ");
    navigate("/adminservices");
  },
  (error)=>{
    console.log(error);
  });

}


useEffect(()=>{},[showPic])
    const handleChange=(event)=>{
            setImageFile(event.target.files[0]);
            setImgflag(true);
            console.log(imageFile);
    }
   
  const upload=(e)=>{
    e.preventDefault();


      const data = new FormData() 
      data.append('profile', imageFile);
      
      console.log(imageFile);
      ImageService.uploadImage(data).then((res) => { 
        console.log(res);
        console.log(res.data.imageName);
        imageArray.push(res.data.imageName);
          // let str=image+"#"+res.data.imageName;
          // setImage(str);
          let str="";
          if(image=='empty'){
            console.log("image ubsent");
            str=res.data.imageName;
          }else{
            str=image+"#"+res.data.imageName;
          }
          console.log(str);
          setImage(str);
        
      })

  }

//   const product={ 
//     id,
//   productName,
//   "description": "ARDUINO MICROCONTROLLER",
//   "categoryName": "MICROCONTROLLER",
//   "price": 550,
//   "stock": 120,
//   "sku": "ARDU01"
// }
  
  return (
    <div style={{margin:'auto'}}>
       <div className="container rounded bg-white mt-5 mb-5">
    <div className="row">
    <h3  className="d-flex justify-content-center"  style={{color:"green"}} >Add New Product</h3>
    
    
     <form>
  <div className="form-group">
    <label htmlFor="exampleFormControlInput1">Product Name</label>
    <input type="text" className="form-control" id="exampleFormControlInput1"
     placeholder={productName}
     onChange={(e)=>setProductName(e.target.value)}  />
  </div>
  <div className="form-group">
    <label htmlFor="exampleFormControlTextarea1">Product Description</label>
    <textarea className="form-control" id="exampleFormControlTextarea1" rows="3" 
    placeholder={description}
    onChange={(e)=>setDescription(e.target.value)} />
  </div>
  
  <div className="form-group">
    <label htmlFor="exampleFormControlSelect1">Product Category</label>
    <select className="form-control" id="exampleFormControlSelect1" required onChange={(e)=>setCategoryName(e.target.value)} >
      <option key="Select">Select Category</option> 
      {categories.map((data)=>{ return(
              <option key={data} value={data}>{data}</option>)}

      )}
                 
    </select>
  </div>
  <div className="form-group">
    <label htmlFor="exampleFormControlInput1">Product Price
    <input type="number" className="form-control" id="exampleFormControlInput1" 
    placeholder={price}
    onChange={(e)=>setPrice(e.target.value)} /></label>
  </div>

  <div className="form-group">
    <label htmlFor="exampleFormControlInput1">Product Stock Avalable
    <input type="number" className="form-control" id="exampleFormControlInput1" placeholder={stock}
    onChange={(e)=>setStock(e.target.value)} /></label>
  </div>
  <div className="form-group">
    <label htmlFor="exampleFormControlInput1">Product SKU Number
    <input type="text" className="form-control" id="exampleFormControlInput1" placeholder={sku}
    onChange={(e)=>setSku(e.target.value)} /></label>
  </div>

  <br />
  <div className="form-group">
    <label htmlFor="exampleFormControlFile1">Product images<br />
    <input type="file" className="custom-file-input" id="exampleFormControlFile1" onChange={handleChange} name="file" /></label>
    <div>
        {imageArray.map((imgdata)=>(
          imgdata ? (<img src={ API_URL+imgdata } key={imgdata} style={{'height':'150px','width':'150px'}}></img>) : (<></>)
      

        ))}
    </div>
    {imgFlag ?  <img src={URL.createObjectURL(imageFile)} style={{'height':'250px','width':'250px'}}></img> : <></>}
            <br></br>
  
            <button onClick={upload} className="btn btn-outline-primary mb-2" >Upload Image</button>
  </div>

  </form>

  <div className="d-flex justify-content-center">

  <button type="submit" className="btn btn-outline-primary mb-2" onClick={(e)=>handleSubmit(e)}>Add Product</button>

<NavLink to={`/adminservices`}> <button  className="btn btn-outline-primary mb-2 mx-5" >Back</button></NavLink>
</div>
</div>
</div>
</div>
  );
};

export default AddProduct;
