import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import postService from "../../services/post.service";
import AdminService from "../../services/admin.service";
import { NavLink } from 'react-router-dom';
import ImageService from "../../services/image.service";


const UpdateProduct = (props) => {
  const {id}=useParams();
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  const [imageFile, setImageFile] = useState();
  const [showPic, setPic] = useState({});
  const [imgFlag, setImgflag] = useState(false);
  const [product, setProduct] = useState();
  const [categories, setCategories] = useState([]);
  const [productName, setProductName] = useState();
  const [description, setDescription] = useState();
  const [categoryName, setCategoryName] = useState("WIFI Controller");
  const [price, setPrice] = useState();
  const [stock, setStock] = useState();
  const [sku, setsku] = useState();
  const [image, setImage] = useState("empty");
  const [imageArray, setImageArray] = useState([]);
  const navigate = useNavigate();
  const [switchTo, setSwitchTo] = useState("prodManage");
  

  useEffect(() => {
    
    postService.getProductById(id).then(
      (resp)=>{
        console.log(resp.data);
        setProduct(resp.data);
        setProductName(resp.data.productName);
        setDescription(resp.data.description);
        setCategoryName(resp.data.categoryName);
        setPrice(resp.data.price);
        setStock(resp.data.stock);
        let img=resp.data.image;
        if(img==""){
          setImage('empty');
        }else{
          setImage(resp.data.image);
        }
        
        let imgAry=img.split('#');
        console.log(imgAry);
        setImageArray(imgAry);
      },
    
              (error) => {
                console.log(error);
              }
    )

    postService.getAllCategories().then((resp)=>{
      console.log(resp.data);
      console.log(categoryName);
      setCategories(resp.data);
    },
    (error)=>{
      console.log(error);
    });
  }, []);



const handleSubmit=(e)=>{
  e.preventDefault();
  console.log(image);
  var updatedproduct={
    "id":id,
    "productName": productName,
    "description": description,
    "categoryName": categoryName,
    "price": price,
    "stock": stock,
    "image":image
   
  }
  console.log(updatedproduct);
  AdminService.updateProduct(id,updatedproduct).then((resp)=>{
    console.log(resp.data);
    navigate("/adminservices");
  },
  (error)=>{
    console.log(error);
  });

}

useEffect(()=>{},[showPic])
    const handleChange=(event)=>{
            setImageFile(event.target.files[0]);
            setImgflag(true);
            
    }
     
    const upload=(e)=>{
      e.preventDefault();
  
  
        const data = new FormData() 
        data.append('profile', imageFile);
        var appdata={
          prodid:23,
          imageNo:1
        }
        
        
        ImageService.uploadImage(data).then((res) => { 
          console.log(res);
          console.log(res.data.imageName);
          imageArray.push(res.data.imageName);
          console.log("Imahe Status in update 112");
          console.log(image);
          let str="";
          if(image=='empty'){
            console.log("image ubsent");
            str=res.data.imageName;
          }else{
            str=image+"#"+res.data.imageName;
          }
          console.log(str);
          setImage(str);
          
        })
  
    }

//   const product={ 
//     id,
//   productName,
//   "description": "ARDUINO MICROCONTROLLER",
//   "categoryName": "MICROCONTROLLER",
//   "price": 550,
//   "stock": 120,
//   "sku": "ARDU01"
// }
  
  return (
    <div style={{margin:'auto'}}>
      
     
     <div className="container rounded bg-white mt-5 mb-5">
    <div className="row">
    <h3  className="d-flex justify-content-center"  style={{color:"green"}} >Update Product</h3>
     <form>
  <div className="form-group">
    <label for="exampleFormControlInput1">Product Name</label>
    <input type="text" className="form-control" id="exampleFormControlInput1"
     placeholder={productName}
     onChange={(e)=>setProductName(e.target.value)}  />
  </div>
  <div className="form-group">
    <label for="exampleFormControlTextarea1">Product Description</label>
    <textarea className="form-control" id="exampleFormControlTextarea1" rows="3" 
    placeholder={description}
    onChange={(e)=>setDescription(e.target.value)} />
  </div>
  
  <div className="form-group">
    <label for="exampleFormControlSelect1">Product Category</label>
    <select className="form-control" id="exampleFormControlSelect1" onChange={(e)=>setCategoryName(e.target.value)} >
          <option key="Select">Select Category</option>
      {categories.map((data)=>(
              <option key={data.categoryName} value={data.categoryName} >{data.categoryName}</option>)

      )}
                 
    </select>
  </div>
  <div className="form-group">
    <label for="exampleFormControlInput1">Product Price</label>
    <input type="number" className="form-control" id="exampleFormControlInput1" 
    placeholder={price}
    onChange={(e)=>setPrice(e.target.value)} />
  </div>

  <div className="form-group">
    <label for="exampleFormControlInput1">Product Stock Avalable</label>
    <input type="number" className="form-control" id="exampleFormControlInput1" placeholder={stock}
    onChange={(e)=>setStock(e.target.value)} />
  </div>

  <br />

  <div className="form-group">
    <label for="exampleFormControlFile1">Product images</label><br />
    <div>
        {imageArray.map((imgdata)=>(
          imgdata ? (<img src={ API_URL+imgdata } key={imgdata} style={{'height':'150px','width':'150px'}}></img>) : (<></>)
      

        ))}
    </div>

    <div class="input-group mb-0">
  <div class="custom-file">
    <input type="file" class="custom-file-input" onChange={handleChange} id="inputGroupFile02"/>
    {/* <label class="custom-file-label" for="inputGroupFile02">Choose file</label> */}
  </div>
  
</div>
    {/* <input type="file" className="form-control-file" id="exampleFormControlFile1" onChange={handleChange} name="file" /> */}
    {imgFlag ?  <img src={URL.createObjectURL(imageFile)} style={{'height':'150px','width':'150px'}}></img> : <></>}
            <br></br>
  
            <button onClick={upload} className="btn btn-outline-primary mb-2 mt-0 " >Upload Image</button>
 
            

  </div>

 </form>
{/* <NavLink to={`/adminservices`}> <button  className="btn btn-info mb-2" >Back</button></NavLink> */}

</div>
<div className="d-flex justify-content-center">
<button type="submit" className="btn btn-outline-primary mb-2 mr-5" onClick={(e)=>handleSubmit(e)}>Update Product</button>
           
            <NavLink to={`/adminservices`} > <button  className="btn btn-outline-primary mb-2 mx-5" >Back</button></NavLink>

</div>
</div>
</div>
  );
};

export default UpdateProduct;
