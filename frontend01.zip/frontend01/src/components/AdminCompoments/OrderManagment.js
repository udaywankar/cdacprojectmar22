import React, { useState,useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Table from 'react-bootstrap/Table';
import Swal from 'sweetalert2';
import ClipLoader from "react-spinners/ClipLoader";

import AdminService from "../../services/admin.service";
import { NavLink } from 'react-router-dom';

const OrderManagement = () => {
    const [orders, setOrders] = useState([]);
  const [email, setEmail] = useState("");
  const [orderStatus, setOrderStatus] = useState("Processing");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const fetchData =()=>{
    AdminService.getAllOrders().then(
      (val)=>{
        console.log(val.data);
       setOrders(val.data);
      },
    
              (error) => {
                console.log(error);
              }
    )
}

const ChangeStatus=(e,id)=>{
  let orderstatus=e.target.value
  console.log(e.target.value);
  console.log(id);
  AdminService.setorderdeliverystatus(id,orderstatus).then((resp)=>{
    console.log(resp);
    setPassword(resp.data);
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 2000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    })
    
    Toast.fire({
      icon: 'success',
      title: 'Delivery Status Updated'
    });
  })
}
  useEffect(()=>{
      fetchData();
     
      //console.log(user);
  },[password])
  

  return (
    <div>

<div  className="d-flex justify-content-center  mb-3">
                    <h4  className="text-center" style={{color:"green"}} > Order Management</h4>
                </div>
        

        {orders.length >0 ? (
        <Table striped bordered hover size="sm" variant="light">
      <thead>
        <tr>
          <th>#Id</th>
          <th>Order Date</th>
          <th>Payment Id</th>
          <th>Total Price</th>
          <th>status</th>
          <th>Update Delivery Status</th>
          <th>Operations</th>
        </tr>
      </thead>
      <tbody>
        {orders.map((order)=>(
          <tr key={order.id}>
          <td>{order.id}</td>
          <td>{order.orderDate}</td>
          <td>{order.paymentId}</td>
          <td>{order.totalPrice}</td>
          <td>{order.status}</td>
          <td>
           
          <select id="select1" onChange={(e)=>ChangeStatus(e,order.id)} value={order.delivery_status}>
            <option value="Processing">Processing</option>
            <option value="Picked by courier">Picked by courier</option>
            <option value="In Transit">In Transit</option>
            <option value="Delivered">Delivered</option>
        </select>

        
         
          
          </td>
          {/* {order.delivery_status} */}
          <td>
          &emsp; <NavLink to={`/userorderdetails/${order.id}`}><button type="button" className="btn btn-primary mb-2" >Details</button></NavLink> 
          </td>
        </tr>

        ))}
        
        
      </tbody>
    </Table>

):( <>
  <div className=" d-flex justify-content-center"> <ClipLoader color={"#123abc"} loading={true}  size={250} /></div></>

)}

    </div>
      
  );
};

export default OrderManagement;
