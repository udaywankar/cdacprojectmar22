import {  Link } from "react-router-dom";
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import InstagramIcon from '@mui/icons-material/Instagram';
import YouTubeIcon from '@mui/icons-material/YouTube';
import "./Topbar.css"

function TopBar(){
    return(
        <>  

<nav className="navbar navbar-expand py-0 navbar-light bg-light">
        <div className="navbar-nav mr-auto">
          <li className="nav-item">
            <Link to={"/home"} className="nav-link py-0">
            
            <span class=" py-0 " >
            <i className="fa fa-phone" style={{margin:'0px 4px'}}></i> 1888 888 8888 
            </span>
            </Link>
          </li>
         
            <li className="nav-item">
              <Link to={"#"} className="nav-link navbar-text py-0">
              <span class="fa fa-envelope "></span>  &nbsp; info@amigotech.in 
           
              </Link>
            </li>
         
        </div>

        
          {/* <div className="navbar-nav ms-auto">
            <li className="nav-item">
              <a href="/login" className="nav-link py-0" >
                Logout
              </a>
            </li>
            <li className="nav-item">
            <Link to={"/adminservices"} className="nav-link py-0">
                 Admin Services
              </Link>
            </li>
           
          
          </div> */}
       
          <div className="navbar-nav ms-auto">
            <li className="nav-item">

              <Link to={"/login"} className="nav-link py-0">
             <FacebookIcon fontSize="inherit"/>
              </Link>
            </li>
            <li className="nav-item">

              <Link to={"/login"} className="nav-link py-0">
             <TwitterIcon fontSize="inherit"/>
              </Link>
            </li>
            <li className="nav-item lastitem">

            <Link to={"/login"} className="nav-link py-0">
             <LinkedInIcon fontSize="inherit"/>
             </Link>
</li>
<li className="nav-item">

<Link to={"/login"} className="nav-link py-0">
 <InstagramIcon fontSize="inherit"/>
 </Link>
</li>
<li className="nav-item">

<Link to={"/login"} className="nav-link py-0">
 <YouTubeIcon fontSize="inherit"/>
 </Link>
</li>




          </div>
       
      </nav>
            {/* <div className='container clearfix' style={{display:'inline-block', flexDirection: "row" }}>
            <p className="topbarfont">
            <i className="fa fa-phone" style={{margin:'0px 4px'}}></i> 1888 888 8888  | &nbsp;&nbsp;
            <a title="info@amigotech.in" href="mailto:info@amigotech.in"><span class="fa fa-envelope"></span>&nbsp;info@amigotech.in</a>
           
           <div style={{justifySelf:"flex-end"}}>
           <a title="My Account" href="#"  style={{ alignContent:"flex-end"}}>My Account</a>
           
           </div>
           
            </p>
            </div> */}
        </>
        

    )
}

export default TopBar;