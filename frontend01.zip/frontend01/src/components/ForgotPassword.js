import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthService from "../services/auth.service";
import ReCAPTCHA from "react-google-recaptcha";
import validator from "validator";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import "./chckmark.css";
import lockImg from "./lock logo.jpg";
import "./LoginCSS.css"
import CheckCircleOutlineOutlinedIcon from '@mui/icons-material/CheckCircleOutlineOutlined';
import Swal from 'sweetalert2';





const ForgorPassword = () => {
  const [email, setEmail] = useState("");
  const [isVerified, setVerified] = useState(false);
  const [otp, setOtp] = useState("");
  const [newpassword, setnewPassword] = useState("");
  const [newpassword2, setnewPassword2] = useState("");
  const [passResetForm, setResetForm] = useState(false);
  const [passResetField, setResetField] = useState(true);
  const [emailError, setEmailError] = useState(false);
  const navigate = useNavigate();

  const validateEmail = (e) => {
    var email = e.target.value;

    if (validator.isEmail(email)) {
      console.log("Valid Email");
      setEmailError(true);
      setEmail(email);
    } else {
      setEmailError(false);
    }
  };

  const passWordResetForm = () => {
    return (
      <div>

<div className="wrapper">
        <div className="logo">
            <img src={lockImg} alt=""/>
        </div>
        <div className="text-center mt-4 name">
            Change Password
        </div>
        <form className="p-3 mt-3" onSubmit={handleChangePassword}>
            <div className="form-field d-flex align-items-center">
                <span className="far fa-user"></span>
                <input type="text" name="otp"  id="userOTP" placeholder="User OTP" onChange={(e) => setOtp(e.target.value)}
            required/>

            </div>
            <div className="form-field d-flex align-items-center">
                <span className="fas fa-key"></span>
                <input type="text" name="password1" id="pwd1" placeholder="Enter password"  onChange={(e) => setnewPassword(e.target.value)}
            required />
            </div>
            <div className="form-field d-flex align-items-center">
                <span className="fas fa-key"></span>
                <input type="text" name="password2" id="pwd2" placeholder="Enter Password Again"  onChange={(e) => setnewPassword2(e.target.value)}
            required />
            </div>
            
            <button type="submit" class="btn mt-3"  >Change Password</button>
                        
        </form>
        
    </div>
       
   </div>
    );
  };
  const handleCheckEmail = async (e) => {
    e.preventDefault();
    if(email.length===0){
      //alert("Enter email")
      Swal.fire({
        icon: 'success',
        title: 'Enter email',
        
      });
    }else{
    try {
      await AuthService.forgotCheckEmail(email).then(
        (flag) => {
          console.log(flag);
          if (flag) {
            setResetForm(true);
            setResetField(true);
            //alert("Otp Has been sent to your Email Id");
            Swal.fire({
              icon: 'success',
              title: 'Otp Has been sent to your Email Id',
              
            });
          } else setResetField(false);
          // navigate("/home");
          // window.location.reload();
        },
        (error) => {
          console.log("Email React Not Exist");
          console.log(error);
        }
      );
    } catch (err) {
      console.log(err);
    }}
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (newpassword === newpassword2) {
      console.log("PaSSword Same");
      try {
        await AuthService.changePassword(email, newpassword, otp).then(
          (flag) => {
            console.log(flag);
            if (flag) {
              console.log("password change successfullllll");
              setResetForm(true);
            } else setResetForm(false);
            // navigate("/home");
            // window.location.reload();
          },
          (error) => {
            console.log("Email React Not Exist");
            console.log(error);
          }
        );
      } catch (err) {
        console.log(err);
      }
    } else console.log("PaSSword different");
  };
  const onChangeCapcha = () => {
    console.log("in Capcha");
    setVerified(true);
  };
  const emaiError = () => {
    return (
      <div>
        <h5 style={{color:"red"}}>Email not Exist</h5>
      </div>
    );
  };
  const emailOtp = () => {
    console.log("Otp sent to your Email");
    return (
      <div>
        <h5>Otp sent to your Email</h5>
      </div>
    );
  };

  return (
    <div className="backgroundImage">
       <Container fluid  >
      
      <Row>
      <Col   lg={passResetForm? 6:12} >
      
    

        <div className="wrapper">
        <div className="logo">
            <img src={lockImg} alt=""/>
        </div>
        <div className="text-center mt-4 name">
            Reset Password
        </div>
        <form className="p-3 mt-3">
            <div className="form-field d-flex align-items-center">
                <span className="far fa-user"></span>
                <input type="email" name="userEmail" id="userName" placeholder="User Email" onChange={(e) => validateEmail(e)}
                        required/>
                   <div className="CheckStyle">
                      {emailError ? <CheckCircleOutlineOutlinedIcon  /> : null}
                    </div>
            </div>

            <div className=" d-flex align-items-center">
           
             
              <ReCAPTCHA 
                 sitekey={process.env.REACT_APP_SITE_KEY}
                 onChange={onChangeCapcha} />
      <br/>
     
               
            </div>
            {passResetField ? null : emaiError()}
            <button type="button" class="btn mt-3" disabled={!isVerified} onClick={handleCheckEmail}>Submit</button>
                         
        </form>
        <div className="text-center fs-6">
            <a href="/forgotpassword">Forget password?</a> or <a href="/signup">Sign up</a>
        </div>
    </div>
       


     
         </Col>
      <Col   lg={passResetForm ? 6:12} >
      {passResetForm ? passWordResetForm() : null}
      </Col>
      </Row>
      </Container >
    </div>
  );
};

export default ForgorPassword;
