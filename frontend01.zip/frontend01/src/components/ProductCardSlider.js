import React from 'react';
import { useState,useEffect } from 'react';
import { Zoom } from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'
import { NavLink } from 'react-router-dom';
import './ProductCardSliderCSS.css';

function ProductCardSlider({product}) {
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  //const [imageArray,setImageArray]=useState(props.name)
 console.log(product);
 console.log(product.length);

  useEffect(()=>{
    //console.log(props.name);
    
},[])
    return (
      // <div classNameNameName="slide-container">
      //   <Zoom scale={0.4}>
      //     {
      //       name.map((each, index) => <img key={index} style={{width: "100%"}} src={API_URL +each} />)
      //     }
      //   </Zoom>
      // </div>




  {/* {product.map((data) => (
              
                 
                  <NavLink to={`/productdetails/${data.id}`}>
                <div className="card cardp " style={{width :"100%"}} >
                  <div className="card-body">
  
                    <div className="avatar">
                    <p  className="font-weight-light" style={{fontSize:'x-small'}}>{data.categoryName}</p>
                      <img
                        src={API_URL+data.image.split('#')[0]}
                        className="card-img-top"
                        alt=""
  
                      />
                    </div>
                    <p className="card-title pName " >
                      {data.productName}
                    </p>
                    <p style={{fontSize:'Small'}}>{data.categoryName}</p>

                     
                      <br />
  
                      <span className="phone">₹ {data.price}</span>
                      <span className="phone" style={{fontSize:'medium', color:'black'}}>(Inc. GST) </span>
                    </p> 
                  </div>
                </div>
                
                </NavLink>
              
             
              
            ))} */}

             
          
 
        


         


    )
}

export default ProductCardSlider;