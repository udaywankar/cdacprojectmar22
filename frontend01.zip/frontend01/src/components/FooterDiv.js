import {
  Facebook,
  Instagram,
  MailOutline,
  Phone,
  Pinterest,
  Room,
  Twitter,
} from "@material-ui/icons";
import styled from "styled-components";
import { mobile } from "./responsive";
//import img1 from "./../images/logo.jpg";
import img1 from "./../images/logo.png";
import "./FooterDiv.css";

import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
const Container = styled.div`
  display: flex;
  ${mobile({ flexDirection: "column" })}
  
`;

const Left = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 20px;
`;

const Logo = styled.h1``;

const Desc = styled.p`
  margin: 20px 0px;
`;

const SocialContainer = styled.div`
  display: flex;
`;

const SocialIcon = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  color: white;
  background-color: #${(props) => props.color};
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 20px;
`;

const Center = styled.div`
  flex: 1;
  padding: 20px;
  ${mobile({ display: "none" })}
`;

const Title = styled.h3`
  margin-bottom: 30px;
`;

const List = styled.ul`
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-wrap: wrap;
`;

const ListItem = styled.li`
  width: 50%;
  margin-bottom: 10px;
`;

const Right = styled.div`
  flex: 1;
  padding: 20px;
  ${mobile({ backgroundColor: "#fff8f8" })}

`;

const ContactItem = styled.div`
  margin-bottom: 20px;
  display: flex;
  align-items: center;
`;

const Payment = styled.img`
    width: 50%;
`;

const FooterDiv = () => {
  return (
    <div> 
   

    <hr />
    
    <Container >
      <Row> <Col lg={4} md={6} sm={12}>
      <Left>
        <Logo><img src={img1} style={{ width:'230px', height:'90px' }} /></Logo>
        <Desc className="text-justify">
        
      Today, India is taking giant strides forward. Innovation is at the forefront & the people who are making this revolution happen are makers and innovators. AmigoTech.in exists to support and accelerate this Maker’s Revolution and play a part in taking India ahead.
 
        </Desc>
        <SocialContainer>
          <SocialIcon color="3B5999">
            <Facebook />
          </SocialIcon>
          <SocialIcon color="E4405F">
            <Instagram />
          </SocialIcon>
          <SocialIcon color="55ACEE">
            <Twitter />
          </SocialIcon>
          <SocialIcon color="E60023">
            <Pinterest />
          </SocialIcon>
        </SocialContainer>
      </Left>
      </Col>
      <Col lg={4} md={6} sm={12}>
      <Center>
        <Title>Useful Links</Title>
        <List>
          <ListItem>Home</ListItem>
          <ListItem>Cart</ListItem>
          <ListItem>Latest Modules</ListItem>
          <ListItem>3D Printing</ListItem>
          <ListItem>Accessories</ListItem>
          <ListItem>My Account</ListItem>
          <ListItem>Order Tracking</ListItem>
          <ListItem>Wishlist</ListItem>
          <ListItem>AmigoTech B2B Services</ListItem>
          <ListItem>Terms</ListItem>
          
        </List>
        
       
      </Center>
      </Col>
      <Col lg={4} md={6} sm={12}>
      <Right>
        <Title>Contact</Title>
        <ContactItem>
          <Room style={{marginRight:"10px"}}/> 622 Tech Park, Pune, Maharashtra 442402
        </ContactItem>
        <ContactItem>
          <Phone style={{marginRight:"10px"}}/> +91-9998882424
        </ContactItem>
        <ContactItem>
          <MailOutline style={{marginRight:"10px"}} /> contactus@amigotech.in
        </ContactItem>
        <Payment src="https://i.ibb.co/Qfvn4z6/payment.png" />
      </Right>
      </Col>
      </Row>
    </Container></div>
  );
};

export default FooterDiv;
