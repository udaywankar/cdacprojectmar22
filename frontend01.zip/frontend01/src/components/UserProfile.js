import React, { useState ,useEffect} from "react";
import { useNavigate } from "react-router-dom";
import AuthService from "../services/auth.service";
import PostService from "../services/post.service";
import "../App.css";
import { NavLink } from 'react-router-dom';
import $ from 'jquery';
import Swal from 'sweetalert2';

const UserProfile = () => {
  
  const [currentUserInfo, setCurrentUserInfo] = useState({});
  const [currentUserName, setCurrentUserName] = useState([]);
  const [privatePosts, setPrivatePosts] = useState();
  const [userEmail, setUserEmail] = useState();
  const [userId, setUserId] = useState();
  const navigate = useNavigate();
  useEffect(() => {
    
      const userloged = PostService.getLoggedUserInfo();
      console.log(userloged)
      setCurrentUserInfo(userloged);
        let user=PostService.getLoggedUser();
        console.log(user);
        setUserEmail(user[0]);
        setUserId(user[1]);
        console.log(user[2]);
       let ar= userloged.userName.split(' ');
       setCurrentUserName(ar);
    
  }, []);
  const arrayToProfileObject=(formdata)=>{
    var data = formdata.reduce(function(obj, item) {
      obj[item.name] = item.value;
      obj["userName"]=item.firstName+item.lastName;
      return obj;
  }, {});
      return data;
  }
const updateProfile=(e)=>{
  e.preventDefault();
  console.log(e.target);
  var sameAddress=$('#userprofile').serializeArray();
  console.log(sameAddress);
  var updateduserArry=arrayToProfileObject(sameAddress);
  if(updateduserArry.mobileNo.length!==10){
      // alert("Mobile No is Not Valid");
      Swal.fire({
        icon: 'error',
        title: 'Mobile No is Not Valid'
           
      })
  }else{
  var updateduser={
        userId: userId,
        email:currentUserInfo.email,
        mobileNo:updateduserArry.mobileNo,
        panNo: updateduserArry.panNo,
           
        userName: updateduserArry.firstName+" "+updateduserArry.lastName
  }
  console.log(updateduser);
  PostService.updateUserProfile(userId,updateduser).then((resp)=>{
    console.log(resp.data);
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 2000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    })
    
    Toast.fire({
      icon: 'success',
      title: 'Profile Data Updated successfully'
    });
  })
}
}

  return (
   
    <div >

 
 <div className="container rounded bg-white mt-5 mb-5">
    <div className="row">
        
            
      <form id="userprofile" onSubmit={updateProfile}>

        <div class="col-md-12 border-right">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-center align-items-center mb-3">
                    <h4 class="text-right" style={{color:"green"}} >Personal Information</h4>
                </div>
                <div class="row mt-1">
                    <div class="col-md-6"><label class="labels">Name</label><input name="firstName" type="text" class="form-control" placeholder={currentUserName[0]} /></div>
                    <div class="col-md-6"><label class="labels">Surname</label><input name="lastName" type="text" class="form-control"   placeholder={currentUserName[1]}/></div>
                </div>
                <div class="btn-group btn-group-toggle" >
  <label class="btn btn-light active">
    <input type="radio" name="Gender" id="male"  checked/> Male
  </label>
  <label class="btn btn-light">
    <input type="radio" name="Gender" id="female" /> Female
  </label>
 
</div>

                <div class="row mt-3">
                    <div class="col-md-12"><label class="labels">Mobile Number</label><input type="text" name="mobileNo" class="form-control" placeholder={currentUserInfo.mobileNo} /></div>
                    <div class="col-md-12"><label class="labels">PAN No</label><input type="text" name="panNo" class="form-control" placeholder={currentUserInfo.panNo}  /></div>
            
                   
                 </div>
                
                <div class="mt-5 text-center"><button class="btn btn-primary profile-button" type="submit">Save Profile</button></div>


            </div>
        </div>
        </form>
    </div>


    


</div>




</div>



  );
};

export default UserProfile;
