import React, { useState, useEffect } from "react";
import postService from "../services/post.service";
import AdminService from "../services/admin.service";
import { useNavigate } from "react-router-dom";
import UserProfile from "./UserProfile";
import "./UserProfileCSS.css"
import ProductManagement from "./AdminCompoments/ProductManagement";
import OrderManagement from "./AdminCompoments/OrderManagment";
import CameraAltIcon from '@mui/icons-material/CameraAlt';
import UserInfo from "./UserComponents/UserInfo";
import ImageService from "../services/image.service";
import { WindowSharp } from "@mui/icons-material";
import UserOrders from "./UserComponents/UserOrders";
import ChangePassword from "./UserComponents/ChangePassword";
const Profile = () => {
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  const [image, setImage] = useState();
  const [user, setUser] = useState({});
  const [userEmail, setUserEmail] = useState();
  const [userId, setUserId] = useState();
  const navigate = useNavigate();
  const [switchTo, setSwitchTo] = useState("userInfo");
  useEffect(() => {
    let user=postService.getLoggedUser();
        console.log(user);
        setUserEmail(user[0]);
        setUserId(user[1]);
        console.log(user[2]);

    postService.getUserInfo(user[1]).then(
      (response) => {
        console.log(response.data);
        setUser(response.data)
        
        
      },
      (error) => {
        console.log("Private page", error.response);
        // Invalid token
        if (error.response && error.response.status === 403) {
          console.log("In getAllPrivatePosts ERROR");
          // AuthService.logout();
          // navigate("/login");
          // window.location.reload();
        }
      }
    );
  }, []);
  const navigateTo=(to)=>{
    console.log("In navigateTo ");
    setSwitchTo(to);
}
  
  const changeprofileImage=(e)=>{
    
    console.log(e.target.files[0]);
    var newimage=e.target.files[0];
    const data = new FormData() 
    data.append('profile', newimage);

    ImageService.uploadImage(data).then((res) => { 
      console.log(res);
      console.log(res.data.imageName);
      
      postService.setUserProfileImage(userId,res.data.imageName).then((resp)=>{
        console.log(resp);
        
      });
      setImage(res.data.imageName);
      window.location.reload();
    });
   

  }

  
  return (

    <>
    <div 
    //</>style={{ height: '100%', position: 'absolute', left: '0px', width: '100%', overflow: 'hidden'}}
    >

<div  className="container rounded bg-white mt-5 mb-5 py-8">
    <div  className="row">
        <div  className="col-md-3 border-right">
            <div  className="d-flex flex-column align-items-center text-center p-03 py-0">
            {/* <img  className="rounded-circle mt-5" width="150px" src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"/> */}
    
            
            <div className="img-holder">
            <img  className="rounded-circle mt-5" width="150px" src={API_URL+user.profileImage}   alt=" Profile image Unavailable. please upload"/>
            <label for="file-input" className="link">
            <CameraAltIcon/>
            </label>
              <input type="file" id="file-input" className="link" name="myImage" accept="image/*"  onChange={(e)=>changeprofileImage(e)}/>
              
             
            </div>

            <span  className="font-weight-bold">{user.userName}</span>
            <span  className="text-black-50">{user.email}</span><span> </span>
            </div>
            <br/>
            <span className="btn btn-danger d-flex justify-content-center" onClick={()=>navigateTo("userInfo")}>User Info</span><br/>
            <span className="btn btn-danger d-flex justify-content-center" onClick={()=>navigateTo("userAccount")}>Update Profile</span><br/>
            <span className="btn btn-danger d-flex justify-content-center" onClick={()=>navigateTo("userOrders")}>Orders</span><br/>
            <span className="btn btn-danger d-flex justify-content-center" onClick={()=>navigateTo("changePassword")}>Change Password</span><br/>
 
           
       
        
        
       
        </div>

        <div  className="col-md-9 border-right">

        {
        {
          'userOrders': <UserOrders user={user} />,
          'userInfo': <UserInfo user={user} />,
          
          'userAccount':   <UserProfile/>,
          'changePassword':   <ChangePassword/>
          
        }[switchTo]
      }

        

          </div>

        </div>  </div>
        
      
   

</div>


</>
  );
};

export default Profile;
