import React ,{useState,useEffect} from 'react'
import postService from '../services/post.service';
import {  Link,useNavigate } from "react-router-dom";
import Swal from 'sweetalert2';
import { NavLink } from 'react-router-dom';
import './ProductCardCSS.css';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import ClipLoader from "react-spinners/ClipLoader";
function ProductCard({product}) {
  const navigate = useNavigate();
   // const [product,setProduct] = useState([]);
    const [imageArray,setImageArray] = useState([]);
    //const API_URL ="http://localhost:4000/image/";
    const API_URL =process.env.REACT_APP_IMAGE_URL;
    //console.log(product);
  
    useEffect(()=>{
        //fetchData();
        //console.log(user);
        
    },[])
   
   const addtocart=(id)=>{
    console.log("In addToCart");
    let user=postService.getLoggedUser();
     if(user){
         console.log("logged");
         postService.addProductToCart(user[1],id,1).then((res)=>{
             console.log(res);
             const Toast = Swal.mixin({
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
              timer: 2000,
              timerProgressBar: true,
              didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
              }
            })
            
            Toast.fire({
              icon: 'success',
              title: 'Product Added to Cart'
            });
         

         },(error)=>{
         console.log(error);
         }
         );
 
     }else{
         navigate("/login");
     }
 

   } 
    return (

        <div className="clearfix" >
           {product.length >0 ? ( 
        <div className="row">
      
          {product.map((data) => (
              
            <div className="col-lg-2 col-md-4 col-sm-6 col-xs-12 animated fadeIn" key={data.id}>
              
               
              <div className="card cardp " style={{width :"100%"}} >
              <div className='row'>
                    <div className='col '>
                    <p  className="font-weight-light" style={{fontSize:'x-small'}}>{data.categoryName}</p>
                  
                    </div>
                    <div className='col m-0 p-0 ' align="right">
                 
                    <p  className="text-right m-0 mr-3" ><AddShoppingCartIcon onClick={()=>addtocart(data.id)}/></p>
                 
                    </div>

                   </div>
                   <NavLink to={`/productdetails/${data.id}`}>
                <div className="card-body">

                  <div className="avatar ">
                 

                   <img
                      src={API_URL+data.image.split('#')[0]}
                      className="card-img-top"
                      alt=""

                    />
                  </div>
                  <p className="card-title pName " >
                    {data.productName}
                  </p>
                  {/* <p style={{fontSize:'Small'}}>{data.categoryName}</p> */}
                  <p className="card-text" style={{fontSize:'x-large', color:'purple'}}>
                    {/* {data.description} */}
                    <br />

                    <span className="phone">₹ {data.price}</span>
                    <span className="phone" style={{fontSize:'medium', color:'black'}}>(Inc. GST) </span>
                  </p> 
                </div>
                </NavLink>
              </div>
              
             
            
            </div>
            
          ))}

         
        </div>
         ):(  <>
          <div className=" d-flex justify-content-center"> <ClipLoader color={"#123abc"} loading={true}  size={450} /></div></>
        )}
      </div>
    )
}

export default ProductCard

//   const product={ 
//     id,
//   productName,
//   "description": "ARDUINO MICROCONTROLLER",
//   "categoryName": "MICROCONTROLLER",
//   "price": 550,
//   "stock": 120,
//   "sku": "ARDU01"
// }