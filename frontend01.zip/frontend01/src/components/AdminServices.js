import React, { useState, useEffect } from "react";
import PostService from "../services/post.service";
import AdminService from "../services/admin.service";
import { useNavigate } from "react-router-dom";
import UserProfile from "./UserProfile";
import { ProSidebar, Menu, MenuItem, SubMenu} from 'react-pro-sidebar';
//import './react-pro-sidebarcss.scss';
import 'react-pro-sidebar/dist/css/styles.css';
import { FaBeer } from 'react-icons/fa';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import postService from "../services/post.service";
import ProductManagement from "./AdminCompoments/ProductManagement";
import OrderManagement from "./AdminCompoments/OrderManagment";
import ManageStaff from "./AdminCompoments/ManageStaff";



const AdminServices = () => {
  const [privatePosts, setPrivatePosts] = useState();
  const [userEmail, setUserEmail] = useState();
  const [userId, setUserId] = useState();
  const navigate = useNavigate();
  const [switchTo, setSwitchTo] = useState("prodManage");
  

  useEffect(() => {
    
    PostService.getAllPrivatePosts().then(
      (response) => {
        console.log(response.data);
        setPrivatePosts(response.data);
        let user=PostService.getLoggedUser();
        console.log(user);
        
        console.log(user[2]);
      },
      (error) => {
        console.log("Private page", error.response);
        // Invalid token
        if (error.response && error.response.status === 403) {
          console.log("In getAllPrivatePosts ERROR");
          // AuthService.logout();
          // navigate("/login");
          // window.location.reload();
        }
      }
    );
  }, []);

const navigateTo=(to)=>{
    console.log("In navigateTo ");
    setSwitchTo(to);
}
  
  return (
    // <div style={{margin:'auto' }}>
    

       <div //style={{ height: 'auto', position: 'absolute', left: '0px', width: '100%', overflow: 'hidden'}}
       >
   

    
      <Container fluid  >
      
      <Row>
      <Col   lg={true} >
        {/* <h3 style={{color:"red"}}>Welcome, Admin</h3> */}
        
        </Col>
      
      </Row>
      
      <Row>
        <Col lg={3} >
          
       
          
          <ProSidebar style={{ display: 'flex', height: '100vh', overflow: 'scroll initial' }}>
  <Menu iconShape="square">
    <MenuItem icon={<FaBeer />}>
      
      <span onClick={()=>navigateTo("prodManage")}>Product Managment</span>
      
      </MenuItem>
    <MenuItem icon={<FaBeer />}>
    <span onClick={()=>navigateTo("orderManage")}>Orders Managment</span>
      </MenuItem>
  
    <MenuItem icon={<FaBeer />}><span onClick={()=>navigateTo("manageStaff")}> Manage Staff </span>
     </MenuItem>
  </Menu>
</ProSidebar>






</Col>
  <Col lg={9} >
      {
        {
          'prodManage': <ProductManagement/>,
          'orderManage': <OrderManagement/>,
          'manageStaff': <ManageStaff/>
        }[switchTo]
      }

</Col>
      </Row>

      {/* <Row>
        <FooterDiv/>
      </Row> */}
    </Container>
      
   


</div>

  );
};

export default AdminServices;
