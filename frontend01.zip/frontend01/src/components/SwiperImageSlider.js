import React, { useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Navigation, Pagination, Controller, Thumbs } from 'swiper';
import 'swiper/swiper-bundle.css';
import './swiperImageSliderStyles.css';

SwiperCore.use([Navigation, Pagination, Controller, Thumbs]);

function SwiperImageSlider({name}) {
  const [thumbsSwiper, setThumbsSwiper] = useState(null);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  console.log(name);
  console.log(name.length);
  const slides = [];
  for (let i = 0; i < name.length; i += 1) {
    slides.push(
      <SwiperSlide key={`slide-${i}`} tag="li">
        <img 
          src={API_URL+name[i]}
          style={{ listStyle: 'none', width:'350px', height:'350px' }}
          alt={`Slide ${i}`}
        />
      </SwiperSlide>
    );
  }

  const thumbs = [];
  for (let i = 0; i < name.length; i += 1) {
    thumbs.push(
      <SwiperSlide key={`thumb-${i}`} tag="li" style={{ listStyle: 'none' }}>
        <img style={{width : '100%'}}
          src={API_URL+name[i]}
          alt={`Thumbnail ${i}`}
        ></img>
      </SwiperSlide>
    );
  }

  

  return (
    <>
      <Swiper
        id="main"
        thumbs={{ swiper: thumbsSwiper }}
       // controller={{ control: controlledSwiper }}
        tag="section"
        wrapperTag="ul"
        navigation
        pagination
        spaceBetween={0}
        slidesPerView={1}
        onInit={(swiper) => console.log('Swiper initialized!', swiper)}
        onSlideChange={(swiper) => {
          console.log('Slide index changed to: ', swiper.activeIndex);
        }}
        onReachEnd={() => console.log('Swiper end reached')}
      >
        {slides}
      </Swiper>

      <Swiper
        id="thumbs"
        spaceBetween={58}
        slidesPerView={5}
        onSwiper={setThumbsSwiper}
      >
        {thumbs}
      </Swiper>

      
      </>
  );
}

export default SwiperImageSlider;
