import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthService from "../services/auth.service";

const ResetPassword = () => {
  const [email, setEmail] = useState("");
  const [newpassword, setnewPassword] = useState("");
  const [newpassword2, setnewPassword2] = useState("");
  const navigate = useNavigate();

  const handleChangePassword = async (e) => {
    e.preventDefault();
    try {
      await AuthService.forgotCheckEmail(email).then(
        (flag) => {
          console.log(flag);
          // navigate("/home");
          // window.location.reload();
        },
        (error) => {
          console.log("Email React Not Exist")
          console.log(error);
        }
      );
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div>
      <form onSubmit={handleChangePassword}>
        <h3>ForGot PassWord</h3>
        <input
          type="text"
          placeholder="email"
          value={newpassword}
          onChange={(e) => setnewPassword(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="new Password"
          value={newpassword2}
          onChange={(e) => setnewPassword2(e.target.value)}
          required
        />
        
        
        <button type="submit">Change Password</button>
      </form>
     
    </div>
  );
};

export default ResetPassword;
