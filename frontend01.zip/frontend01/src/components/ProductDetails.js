import React ,{useState,useEffect} from 'react'
import { useParams } from 'react-router';
import postService from '../services/post.service';
import { useNavigate } from "react-router-dom";
import "./productDetails.css";
import ProductImageSlider from './ProductImageSlider';
import SwiperImageSlider from './SwiperImageSlider';
function ProductDetails() {
    //const API_URL ="http://localhost:7777/thumbimage/";
    const API_URL =process.env.REACT_APP_IMAGE_URL;
    const { id } = useParams();
    const navigate = useNavigate();
    const [quantity,setquantity] = useState(1);
    const [product,setProduct] = useState([]);
    const [productData,setProductData] = useState([]);
    const [imageArray, setImageArray] = useState([]);
    const fetchData =()=>{
      postService.getProductById(id).then(
        (val)=>{
          console.log(val.data);
          setProduct(val.data);
          console.log(id);
          let img=val.data.image;
        
        let imgAry=img.split('#');
        setImageArray(imgAry);
        console.log(imgAry);
        },
      
                (error) => {
                  console.log(error);
                }
      )
  }
  const incrementValue=()=>
{
    console.log("incrementValue");
    var value = parseInt(document.getElementById('number').value, 10);
    value = isNaN(value) ? 0 : value;
    
    console.log(value);

    if(value<10 && product.stock> value){
        value++;
            document.getElementById('number').value = value;
    }
    setquantity(value);
}
const decrementValue=()=>
{
    console.log("-----decrementValue");
    var value = parseInt(document.getElementById('number').value, 10);
    value = isNaN(value) ? 0 : value;
    console.log(value);
    if(value>1){
        value--;
            document.getElementById('number').value = value;
    }
    
    setquantity(value);
}

const addToCart=()=>{
    console.log("In addToCart");
   let user=postService.getLoggedUser();
    if(user){
        console.log("logged");
        postService.addProductToCart(user[1],id,quantity).then((res)=>{
            console.log(res);
        },(error)=>{
        console.log(error);
        }
        );

    }else{
        navigate("/login");
    }


}
    useEffect(()=>{
        fetchData();
        
    },[])
   
    return(
       <>
    
        <section className="py-5">
        <div className="container px-4 px-lg-5 my-5">
            <div className="row gx-4 gx-lg-5 align-items-center">
                <div className="col-md-6">
                    {/* <img className="card-img-top mb-5 mb-md-0" src={API_URL+product.id} alt="https://dummyimage.com/600x700/dee2e6/6c757d.jpg" /> */}
                <ProductImageSlider name={imageArray}/>
                {/* <SwiperImageSlider name={imageArray}/> */}
                </div>
                <div className="col-md-6">
                    <div className="small font-weight-light mb-1">SKU: {product.sku} </div>
                    <h5 className="font-weight-bolder medium mb-1 text-sm-left">{product.productName}</h5>
                    <div className="fs-5 mb-5">
                        {/* <span className="text-decoration-line-through"></span> */}
                        <span>₹  {product.price}</span>
                        <br/>
                        {product.stock < 10 && product.stock!=0 ? (
                             <span style={{color: "Blue",fontSize:"medium" }}>Hurry, Only {product.stock} items Left</span>
                        ):(null)}
                        

                    </div>
                    <p className="">{product.description}</p>

                    {product.stock ==0 ? (
                             <h4 style={{color: "Red" , }}>Product is Out of Stock</h4>
                        ):(
                    <div className="d-flex">
                        <input type="button" onClick={decrementValue} defaultValue="   -   " />
                        <input className="form-control text-center me-3"  type="num" name="quantity" defaultValue={quantity} maxLength="2" max="10" size="1" id="number" style={{'maxWidth' : '3rem'}} />
                        <input type="button" onClick={incrementValue} defaultValue="   +   " />
                        
                        <button className="btn btn-outline-dark flex-shrink-0" onClick={addToCart} type="button">
                            <i className="bi-cart-fill me-1"></i>
                            Add to cart
                        </button>
                    </div>
                    )}
                </div>
            </div>
        </div>
    </section>

        </>
    )


    
}

export default ProductDetails

//   const product={ 
//     id,
//   productName,
//   "description": "ARDUINO MICROCONTROLLER",
//   "categoryName": "MICROCONTROLLER",
//   "price": 550,
//   "stock": 120,
//   "sku": "ARDU01"
// }