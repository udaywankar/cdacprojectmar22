import React ,{useState,useEffect} from 'react'
import postService from '../services/post.service';
import { NavLink } from 'react-router-dom';
import { useNavigate } from "react-router-dom";
import Swal from 'sweetalert2';

function UserCart() {
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
    const navigate = useNavigate();
    const [userId,setUserId]= useState();
    const [userCart,setUserCart] = useState([]);
    const [total,setTotal]= useState();
    const [totalquantity,setTotalquantity]= useState();
    const [shippingAddr,setShippingAddr] = useState();
    const fetchData =()=>{
      let userid=postService.getLoggedUser();
      console.log(userid);
      setUserId(userid[1]);
      postService.getUserCart(userid[1]).then(
        (val)=>{
          console.log(val.data);
          let list=val.data.list;
          let totalqty=0;
          let totalvalue=0;
          setUserCart(list);
          list.map((data)=>{
            totalvalue+=data.quantity*data.product.price;
            totalqty+=data.quantity;
          });
          setTotal(totalvalue);
          setTotalquantity(totalqty);
        },
      
                (error) => {
                  console.log(error);
                }
      )
      postService.getUserAddress(userid[1]).then((resp)=>{
        console.log(resp.data);
        let adrArry=resp.data;
        var art=adrArry.filter((p)=> p.type==="BOTH" || p.type=="SHIP");
        console.log(art);
        setShippingAddr(art[0]);
        })  
        


  }
  
    useEffect(()=>{
        fetchData();
        console.log(shippingAddr);
    },[])


   const updateqty=(prodId)=>{

      console.log("In Update Qty", prodId);
      var quantity = parseInt(document.getElementById(prodId).value);
      console.log("In ", quantity);
      postService.updateUserCartProduct(userId,prodId,quantity).then(
        (val)=>{
          console.log(val);
          window.location.reload();
        },
      
                (error) => {
                  console.log(error);
                }
      )

   } 

   const deleteproduct=(prodId)=>{

    console.log("In deleteproduct ", prodId);
    
    postService.deleteProductFromcart(userId,prodId).then(
      (val)=>{
        console.log(val);
        window.location.reload();
        
    },
    
              (error) => {
                console.log(error);
              }
    )

 } 

 const checkOut=(prodId)=>{

    console.log("In checkOut ", prodId);
    console.log("In checkOut shippingAddr ", shippingAddr);
    // if(shippingAddr==undefined){ 
    //   alert("Address Unavalable");
    //   navigate("/userprofile");
    // }
    if(total===0){
      console.log("In checkOut ", prodId);
       Swal.fire({
        icon: 'error',
        title: 'Cart is empty'
           
      })
     // navigate("/usercart");
    }else{
    //navigate(`/paymentprocess/${total}`,{  id: userId ,cart: userCart ,total:total,ship:shippingAddr});
    }
 } 
    return (
      <>
      
      <section className="pt-5 pb-5">
  <div className="container">
    <div className="row w-100">
        <div className="col-lg-12 col-md-12 col-12">
            <h3 className="display-5 mb-2 text-center">Shopping Cart</h3>
            <p className="mb-5 text-center">
                <i className="text-info font-weight-bold">{totalquantity} &nbsp;</i> items in your cart</p>
            <table id="shoppingCart" className="table table-condensed table-responsive">
                <thead>
                    <tr>
                        <th style={{width:'60%'}}>Product</th>
                        <th style={{width:'12%'}}>Price</th>
                        <th style={{width:'10%'}}>Quantity</th>
                        <th style={{width:'16%'}}></th>
                    </tr>
                </thead>
                <tbody>

                  {userCart.map((data)=>(
                   
                    <tr key={data.product.id}>
                       
                        <td data-th="Product" >
                            <div className="row">
                                <div className="col-md-3 text-left">
                                    <img src={API_URL+data.product.image.split('#')[0]} alt="" className="img-fluid d-none d-md-block rounded mb-2 shadow "/>
                                </div>
                                <div className="col-md-9 text-left mt-sm-2">
                                    <h4>{data.product.productName}</h4>
                                    <p className="font-weight-light">{data.product.categoryName}</p>
                                </div>
                            </div>
                        </td>
                        <td data-th="Price">₹{data.product.price}</td>
                        <td data-th="Quantity">
                            <input type="number" className="form-control form-control-lg text-center" placeholder={data.quantity}  max="10"  id={data.product.id}/>
                        </td>
                        <td className="actions" data-th="">
                            <div className="text-right">
                                <button className="btn btn-white border-secondary bg-white btn-md mb-2" onClick={()=>updateqty(data.product.id)}>
                                    <i className="fas fa-sync"></i>
                                </button>
                                <button className="btn btn-white border-secondary bg-white btn-md mb-2" onClick={()=>deleteproduct(data.product.id)}>
                                    <i className="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
              ))}
                </tbody>
            </table>
            <div className="float-right text-right">
                <h4>Subtotal:</h4>
                <h1>₹{total}</h1>
            </div>
        </div>
    </div>
    <div className="row mt-4 d-flex align-items-center">
        <div className="col-sm-6 order-md-2 text-right">
          {total===0 ?(<p></p>):(
        <NavLink to={`/paymentprocess/${total}`} state={ { id: userId ,cart: userCart ,total:total, ship:shippingAddr} }>
        <button className="btn btn-outline-dark flex-shrink-0" onClick={()=>checkOut()} type="button">
                            CheckOut
                            
                        </button>
                        </NavLink>)}
        </div>
        <div className="col-sm-6 mb-3 mb-m-1 order-md-1 text-md-left">
        <NavLink to={`/home`}>
            
                <i className="fas fa-arrow-left mr-2"></i> Continue Shopping
                </NavLink>
        </div>
    </div>
</div>
</section>
      </>
    )
    
}

export default UserCart;

//   const product={ 
//     id,
//   productName,
//   "description": "ARDUINO MICROCONTROLLER",
//   "categoryName": "MICROCONTROLLER",
//   "price": 550,
//   "stock": 120,
//   "sku": "ARDU01"
// }