import {  Link } from "react-router-dom";
import { useState, useEffect } from "react";
import AuthService from "./../services/auth.service";
import PostService from "./../services/post.service";
import { useNavigate } from "react-router-dom";
import img1 from "./../images/logo.png";
import "./MainNavBar.css";
import SearchTwoToneIcon from '@mui/icons-material/SearchTwoTone';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import AdminService from "./../services/admin.service";
import InputGroup from 'react-bootstrap/InputGroup';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
function MainNavBar(){
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(undefined);
  const [currentUserInfo, setCurrentUserInfo] = useState({});
  const [isAdmin, setIsAdmin] = useState(false);
  const [userEmail, setUserEmail] = useState();
  const [islogged, setIsLogged] = useState(false);
  const [categories, setCategories] = useState([]);
  const [catButton,setCatButton] = useState("All Categories");
  const [searchBar,setSearchBar] = useState("All Categories");
  useEffect(() => {
    const user = AuthService.getCurrentUser();

    if (user) {
      setCurrentUser(user);
      let userdata=PostService.getLoggedUser();
        console.log(userdata);
        if(userdata[2]==="ADMIN")
        {setIsAdmin(true); }
        setUserEmail(userdata[3])
        const userloged = PostService.getLoggedUserInfo();
        console.log(userloged)
        
        if(!userloged){
          console.log("IN IFFFFFF   User i");
              PostService.getUserInfo(userdata[1]).then((resp)=>{
                console.log(resp.data);
                localStorage.setItem("loggedUser", JSON.stringify(resp.data));
                setCurrentUserInfo(resp.data)
              });
         
        }//if (user) End
        setCurrentUserInfo(userloged);

    }
       
        
       

    PostService.getAllCategories().then((resp)=>{
      //console.log(resp.data);
      let array=[];
      resp.data.map((val)=>{
        //console.log(val.categoryName);
        array.push(val.categoryName);
      });
      
      setCategories(array);
    },
    (error)=>{
      console.log(error);
    });


  }, []);

  const logOut = () => {
    AuthService.logout();
  };
  const catmenu = (e) => {
    console.log("in Cat menu");
    setCatButton(e)
    //console.log(e);
  };
 const searchproducts=()=>{

  console.log("in searchproducts menu");
  console.log(catButton);
  console.log(searchBar);
  if(searchBar!=""){
    console.log("In MainNav Bar Serch");
    //navigate(`/searchproduct/${catButton}/${searchBar}`);

    navigate(`/searchproduct/${catButton}/${searchBar}`, {state:{ search:searchBar}});
  }
 
 }
 
    return(
   
       
      <nav className="navbar navbar-light navbar-expand"  >
   
        <div className="navbar-nav mr-auto" style={{ width:'20%' }}>
          <li className="nav-item">
            
            <Link to={"/home"} className="nav-link navbar-brand">
            <img src={img1} style={{ width:'200px', height:'60px' }} />
            </Link>
          </li>

          {/* {currentUser && (
            <li className="nav-item py-3">
              <Link to={"/userprofile"} className="nav-link">
               <p className="profile"> Profile </p>
              </Link>
            </li>
          )} */}
        </div>
    
      
        <div className="navbar-nav ms-auto"  style={{ width:"60%" ,margin:'0%'}}>
          <li className="nav-item py-0">
          <InputGroup className="mb-3 searchbar" style={{ width:"110%" ,marginLeft:'4rem'}}>
        <DropdownButton
          variant="outline-secondary"
          title={catButton}
          id="input-group-dropdown-1"
          onChange={(e=>setCatButton(e.target.value))}
        >
          <Dropdown.Item href="#" onClick={()=>catmenu("All Categories")}>All Categories</Dropdown.Item>
          <Dropdown.Divider />
          {categories.map((data)=>{ return(
             <Dropdown.Item href="#" key={data} onClick={()=>catmenu(data)} value={data} >{data}</Dropdown.Item>
              )}
             )  }
         
          
        </DropdownButton>
        <Form.Control aria-label="Text input with dropdown button" onChange={(e)=>setSearchBar(e.target.value)} required/>
        <Button variant="outline-secondary" id="button-addon2" onClick={()=>searchproducts()}>
        <SearchTwoToneIcon />
        </Button>
        
      </InputGroup>
          </li >
            </div>

            

            
        {currentUser ? (
          <div className="navbar-nav ms-auto" style={{ width:'20%' }} >
            <li className="nav-item">
              <a href="/login" className="nav-link" onClick={logOut}>
              <p className="profile"> Logout</p>  
              </a>
            </li>
            { isAdmin ? (<li className="nav-item">
            <Link to={"/adminservices"} className="nav-link">
            <p className="profile"> Admin</p> 
              </Link>
            </li>):(<li className="nav-item">
            <Link to={"/usercart"} className="nav-link">
            <p className="profile">  <i className="bi-cart-fill me-1"></i>
                Cart</p> 
           
              </Link>
            </li>)
            }
           <Link to={"/userprofile"} className="nav-link">
            <p className="profile"><AccountCircleIcon/>{userEmail}
            {/* {currentUserInfo.userName ??   currentUserInfo.userName.split(' ')[0]}  */}
              </p> 
           
              </Link>
          </div>
        ) : (
          <div className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link to={"/login"} className="nav-link">
              <p className="profile"> Login</p>    
              </Link>
            </li>

            <li className="nav-item">
              <Link to={"/signup"} className="nav-link">
              <p className="profile">  Sign up</p>  
              </Link>
            </li>
          </div>
        )}
  
      </nav>
   
    )
}

export default MainNavBar;