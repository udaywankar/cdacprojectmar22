import React from 'react';
import { useState,useEffect } from 'react';
import { Zoom } from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'


function Slideshow({name}) {
  //const API_URL ="http://localhost:4000/image/";
  const API_URL =process.env.REACT_APP_IMAGE_URL;
  //const [imageArray,setImageArray]=useState(props.name)
 console.log(name);
 console.log(name.length);

  useEffect(()=>{
    //console.log(props.name);
    
},[])
    return (
      <div className="slide-container">
        <Zoom scale={0.4}>
          {
            name.map((each, index) => <img key={index} style={{width: "100%"}} src={API_URL +each} />)
          }
        </Zoom>
      </div>
 
             
          
       
    
    
 




    )
}

export default Slideshow