package com.app.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserOrderDTO {
	
	private Long id;
	
	private double totalPrice;
	
	@NotBlank(message = "SKU must be supplied")
	private String orderDate;
	
	private String status;
	
	private String razorId;
	
	private String paymentId;
	
	private String delivery_status;
	//private UserEntity user;
	
	
	

}
