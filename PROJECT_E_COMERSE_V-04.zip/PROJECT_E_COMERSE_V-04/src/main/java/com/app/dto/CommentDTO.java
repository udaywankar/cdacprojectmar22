package com.app.dto;

import javax.persistence.Column;

import com.app.entities.Product;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommentDTO {
	@Column(length=300)
	private String comment;
	//User 1 <----- * Comment: Uni Dir associan
	
	private UserDTO user;
	
	//product 1 <------> * Comments
	
	private Product product;

}
