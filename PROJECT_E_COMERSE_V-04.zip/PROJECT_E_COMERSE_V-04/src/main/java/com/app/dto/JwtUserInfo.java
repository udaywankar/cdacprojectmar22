package com.app.dto;

import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@Service
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class JwtUserInfo {
	
	private String useremail;
	private String userid;

}
