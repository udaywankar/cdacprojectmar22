package com.app.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.app.entities.UserRole;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class StaffDTO {
	private Long staffId;
	//@NotBlank(message = "userName must be supplied")
	private String staffName;
	@NotBlank(message = "email must be supplied")
	@Email(message="Invalid email format")
	private String email;
	@NotBlank(message = "password must be supplied")
	private String password;
	private String mobileNo;
	private String panNo;
	private String profileImage;
	private String department;
	
}
