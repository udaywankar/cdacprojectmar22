package com.app.dto;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AddressDTO  {
	
	private Long id;
	@NotBlank(message = "SKU must be supplied")
	private String fullName;
	@NotBlank(message = "SKU must be supplied")
	private String streetAddress;
	@NotBlank(message = "SKU must be supplied")
	private String city;
	@NotBlank(message = "SKU must be supplied")
	private String country;
	@NotBlank(message = "SKU must be supplied")
	private String state;
	private int pincode;
	@NotBlank(message = "Phone No must be supplied")
	private String phone;
	private String type;
	
}
