package com.app.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.app.entities.BaseEntity;
import com.app.entities.Comments;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@NoArgsConstructor
//prod id	SKU	Prod Name	Category	Prod Desc	Price	stock 	Comments	visits	items sold

public class ProductDTO {
	
	private Long id;
	
	private String sku;
	@NotBlank(message = "productName must be supplied")
	private String productName;
	@NotBlank(message = "description must be supplied")
	private String description;
	
	@NotBlank(message = "description must be supplied")
	private String categoryName;
	private String image;
	private Integer imageCount;
	private Double price;
	private Integer stock;
	private Long visits;
	
	
	
	
	
	
	//private List<Comments> comments = new ArrayList<>();

	
	

}
