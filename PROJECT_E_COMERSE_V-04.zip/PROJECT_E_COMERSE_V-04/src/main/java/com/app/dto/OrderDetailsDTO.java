package com.app.dto;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.app.entities.OrderedProducts;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OrderDetailsDTO {
	
	private UserOrderDTO userOrderDTO;
	@JsonProperty("name")
	private String userName;
	
	private AddressDTO address;
	
	private UserCartDTO orderedProducts;
	
	//private UserEntity user not added;
	
	
	

}
