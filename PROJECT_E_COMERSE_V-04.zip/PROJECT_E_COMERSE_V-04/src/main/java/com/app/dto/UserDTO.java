package com.app.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.app.entities.UserRole;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(exclude = "role")
public class UserDTO {
	private Long userId;
	//@NotBlank(message = "userName must be supplied")
	private String userName;
	@NotBlank(message = "email must be supplied")
	@Email(message="Invalid email format")
	private String email;
	
	private String password;
	private String mobileNo;
	private String panNo;
	private String profileImage;
	// many-to-many , User *--->* Role
	//@NotEmpty(message = "at least 1 role should be chosen")
//	private Set<UserRole> roles = new HashSet<>();
	private String role;
}
