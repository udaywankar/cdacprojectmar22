package com.app.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.entities.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
	@Query("select p from Product p where concat( p.productName,p.description,p.price) like %?1%")
	List<Product> searchProductsByName(String pname);
	
	
	@Query("select p from Product p where concat( p.productName,p.description,p.price) like %?1%")
	Page<Product> searchProductsByNamePage(String pname,Pageable pageable);
	
	
	@Query("select p from Product p where concat( p.productName,p.description,p.price) like %?1% and p.category.categoryName=?2")
	List<Product> searchProductsByNameAndCategory(String pname,String category);
	
	
	@Query("select p from Product p where concat( p.productName,p.description,p.price) like %?1% and p.category.categoryName=?2")
	Page<Product> searchProductsByNameAndCategoryPage(String pname,String category,Pageable pageable);
	
	//////**********Examples**********//////////
//	@Query("SELECT p FROM Product p WHERE CONCAT(p.name, p.brand, p.madein, p.price) LIKE %?1%")
//	public List<Product> search(String keyword);
}
