package com.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.entities.UserOrder;


public interface OrderRepository extends JpaRepository<UserOrder, Long> {
	
	//@Query("select u from UserEntity u join fetch u.userRoles where u.email=?1")
	//Optional<UserEntity> findByEmail(String email);
	UserOrder findByRazorId(String razorId);
	@Query("select u from UserOrder u  where u.user.id=:userid")
	List<UserOrder> findByUserid(Long userid);
}
