package com.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.app.entities.Product;
import com.app.entities.UserCart;
import com.app.entities.UserEntity;
@Repository
public interface CartRepository extends JpaRepository<UserCart, Long> {
	@Query("select distinct c from UserCart c where c.user.id=:userid")
	List<UserCart> findByUserId(Long userid);
	
	
	
	@Query("select c from UserCart c where c.user.id=:userid and c.product.id=:prodid")
	UserCart checkProductExistInUserCart(Long userid,Long prodid);
	
	@Modifying
	@Query("delete from UserCart c where c.user.id=:userid and c.product.id=:prodid")
	int deleteProductExistInUserCart(Long userid,Long prodid);
	
	//Long deleteByUserAndProduct(UserEntity user,Product product);
	

	List<UserCart> findAllByUser(UserEntity user);
	
}
