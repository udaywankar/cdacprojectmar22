


package com.app.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.dto.CategoryDTO;
import com.app.dto.OrderDetailsDTO;
import com.app.dto.ProductDTO;
import com.app.dto.StaffDTO;
import com.app.dto.UserOrderDTO;
import com.app.entities.UserOrder;
import com.app.service.ICategoryService;
import com.app.service.IOrderedProductService;
import com.app.service.IProductService;
import com.app.service.IStaffService;
import com.app.service.IUserOrderService;
import com.app.service.ImageHandlingService;



@RestController
@RequestMapping("/admin")
@CrossOrigin
public class AdminController {

	
	@Autowired
	private IProductService productService;
	
	@Autowired
	private IStaffService staffService;
	
	@Autowired
	private ICategoryService categoryService;
	
	@Autowired
	private IUserOrderService orderService;
	
	@Autowired
	private IOrderedProductService orderProductService;
	
	@Autowired
	private ImageHandlingService imageHandling;
	
	public AdminController() {
		System.out.println("In ctor of ProductController");
		
	}
	
	@PostMapping("/category")
	public ResponseEntity<?> addNewCategory(@RequestBody @Valid CategoryDTO category){
		
		System.out.println("In addNewCategory OF  TopicController");
		System.out.println(category);
		return ResponseEntity.status(HttpStatus.CREATED).body(categoryService.addCategory(category));
	}
	
	@GetMapping("/category")
	public ResponseEntity<?> listAllCategory() {

		System.out.println("In listAllCategory >>> AdminController");

		List<CategoryDTO> allCategories = categoryService.getallCategories();
		//System.out.println(allCategories);
		//System.out.println(allCategories.isEmpty());
		if (allCategories.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
		return new ResponseEntity<>(allCategories, HttpStatus.OK);
	}
	
	@GetMapping("/getallstaff")
	public ResponseEntity<?> getAllStaff() {

		System.out.println("In getAllStaff >>> AdminController");

		List<StaffDTO> allStaff = staffService.getAllStaff();
		
		if (allStaff.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
		return new ResponseEntity<>(allStaff, HttpStatus.OK);
	}
	
	@PostMapping("/addnewstaff")
	public ResponseEntity<?> addNewStaff(@RequestBody @Valid StaffDTO staff){
		
		System.out.println("In addNewStaff OF  AdminController");
		System.out.println(staff);
		return ResponseEntity.status(HttpStatus.CREATED).body(staffService.addNewStaff(staff));
	}


	
	
	@PostMapping("/product")
	public ResponseEntity<?> addNewProduct(@RequestBody @Valid ProductDTO product){
		
		System.out.println("In addNewProduct OF  AdminController");
		System.out.println(product);
		return ResponseEntity.status(HttpStatus.CREATED).body(productService.addProduct(product));
	}
	
	
	@PutMapping("/product/{prodid}")
	public ResponseEntity<?> updateProduct(@PathVariable Long prodid,  @RequestBody @Valid ProductDTO product){
		
		System.out.println("In updateProduct OF  AdminController==");
		System.out.println(product);
		return ResponseEntity.status(HttpStatus.CREATED).body(productService.updateProduct(prodid,product));
	}
	
	@DeleteMapping("/product/{prodid}")
	public ResponseEntity<?> deleteProduct(@PathVariable Long prodid){
		
		System.out.println("In deleteProduct OF  AdminController==");
		
		return ResponseEntity.status(HttpStatus.OK).body(productService.deleteProductsById(prodid));
	}
	@GetMapping("/product")
	public ResponseEntity<?> listAllProducts() {

		System.out.println("In listAllProducts >>> AdminController");

		List<ProductDTO> allEmpDetails = productService.getAllProductDetails();
		System.out.println(allEmpDetails);
		System.out.println(allEmpDetails.isEmpty());
		if (allEmpDetails.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
		return new ResponseEntity<>(allEmpDetails, HttpStatus.OK);
	}
	
	@GetMapping("/getallorders")
	public ResponseEntity<?> getallOrders() {

		System.out.println("In getALLOrders >>> AdminController");
		
		List<UserOrderDTO> allOrders = orderService.getAllOrder();
		//System.out.println(allOrders);
		//System.out.println(allOrders.isEmpty());
		if (allOrders.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
		
		
		return new ResponseEntity<>(allOrders, HttpStatus.OK);
	}
	
	
	@GetMapping("/getorderdetails/{orderid}")
	public ResponseEntity<?> getOrderdetailsById(@PathVariable Long orderid) {

		System.out.println("In getOrderdetailsById >>> AdminController");
		
		OrderDetailsDTO orderDetails = orderProductService.getOrderDetails(orderid);
		//System.out.println(allOrders);
		//System.out.println(allOrders.isEmpty());
		
		return new ResponseEntity<>(orderDetails, HttpStatus.OK);
	}
	
	@GetMapping("/setorderdeliverystatus/{orderid}/{status}")
	public ResponseEntity<?> setOrderDeliveryStatus(@PathVariable Long orderid,@PathVariable String status ) {

		System.out.println("In setOrderDeliveryStatus >>> AdminController");
		
		UserOrderDTO setOrderDeliveryStatus = orderService.setOrderDeliveryStatus(orderid, status);
		//System.out.println(allOrders);
		//System.out.println(allOrders.isEmpty());
		
		return new ResponseEntity<>(setOrderDeliveryStatus, HttpStatus.OK);
	}
	
	@PostMapping("/image/{prodid}")
	public ResponseEntity<?> uploadProductImage(@PathVariable Long prodid,@RequestParam("imageData") MultipartFile imageData) throws IOException {

		System.out.println("In uploadProductImage >>> AdminController" + prodid);
		//System.out.println("upload img file name" +imageData.getOriginalFilename()+"  type=="+imageData.getContentType()+" size=="+imageData.getSize());
		//
	//invoke service layer method to save uploaded file in server side folder--imagehandling Service	
		
		ProductDTO storeImage = imageHandling.storeImage(prodid,imageData);
		
		return ResponseEntity.status(HttpStatus.OK).body("Image Uploaded Successfully");
	}
	
	
	
}