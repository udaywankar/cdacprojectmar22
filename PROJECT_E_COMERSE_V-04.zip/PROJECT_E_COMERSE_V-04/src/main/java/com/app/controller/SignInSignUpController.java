package com.app.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AuthRequest;
import com.app.dto.AuthResp;
import com.app.dto.ServerResponce;
import com.app.dto.UserDTO;
import com.app.dto.UserRegResponse;
import com.app.entities.UserEntity;
import com.app.jwt_utils.JwtUtils;
import com.app.service.IUserService;
import com.app.service.emailsend.EmailSenderService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/auth")
@Slf4j
@CrossOrigin
public class SignInSignUpController {
//dep : JWT utils : for generating JWT
	@Autowired
	private JwtUtils utils;
	// dep : Auth mgr
	@Autowired
	private AuthenticationManager manager;
	//dep : user service for handling users
	@Autowired
	private IUserService userService;
	@Autowired
	private EmailSenderService sendEmail;
	
	private int number;
	
	// add a method to authenticate user . Incase of success --send back token , o.w
	// send back err mesg
	@PostMapping("/signin")
	public ResponseEntity<?> validateUserCreateToken(@RequestBody @Valid AuthRequest request,HttpSession session) {
		// store incoming user details(not yet validated) into Authentication object
		// Authentication i/f ---> imple by UserNamePasswordAuthToken
		UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(request.getEmail(),
				request.getPassword());
		log.info("auth token " + authToken);
		try {
			// authenticate the credentials
			Authentication authenticatedDetails = manager.authenticate(authToken);
			// => auth succcess
			
			System.out.println("*************************************");
			System.out.println();
			UserEntity user = userService.getAnthUser(request.getEmail());
			System.out.println("*************************************");
			System.out.println(user);
			session.setAttribute("userdetails", user);
			System.out.println(session.getAttribute("userdetails"));
			//sendEmail.sendSimpleEmail("udaywankar@gmail.com", "Login Successfull", "This is Body of Email");
			
			return ResponseEntity.ok(new AuthResp("Auth successful!", utils.generateJwtToken(authenticatedDetails)));
		} catch (BadCredentialsException e) { // lab work : replace this by a method in global exc handler
			// send back err resp code
			System.out.println("err "+e);
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
		}

	}
	//add request handling method for user registration
	@PostMapping("/signup")
	public ResponseEntity<?> userRegistration(@RequestBody @Valid UserDTO user)
	{
		System.out.println("In userRegistration  of  SignInSignUpController ");
		
		System.out.println("in reg user : user "+user+" roles ");//{....."roles" : [ROLE_USER,...]}
		//invoke service layer method , for saving : user info + associated roles info
		
		
		UserRegResponse registerUser = userService.registerUser(user);
		
		Map<String, Object> model = new HashMap<>();
		
		model.put("userName", user.getUserName());
		sendEmail.sendEmailWelcome(user.getEmail(), model);
		
		return ResponseEntity.status(HttpStatus.CREATED).body(registerUser);		
	}
	
	
	@GetMapping("/forgotpassword/{email}")
	public ResponseEntity<?> forgotPassword(@PathVariable String email)
	{
		System.out.println("In forgotpassword  of  SignInSignUpController ");
		UserEntity userEntity = userService.getAnthUser(email);
		if(userEntity==null) {
			return ResponseEntity.status(HttpStatus.OK).body(new ServerResponce("email not Exist"));
		}else {	
			Random rnd = new Random();
		    int num = rnd.nextInt(999999);
		    String otp=String.valueOf(num);
			System.out.println(otp);
			String body="Dear, \n "+email+"\n Reset Password Otp: "+number;
			
			
			Map<String, Object> model = new HashMap<>();
			model.put("otp", otp);
			model.put("userName", userEntity.getUserName());
			 sendEmail.sendEmailPasswordReset("udaywankar@gmail.com", model);
			
			
			
			
			//sendEmail.sendSimpleEmail("udaywankar@gmail.com", "Password Reset OTP", body);
			return ResponseEntity.status(HttpStatus.OK).body(new ServerResponce("email Found"));		
		}
		}
	
	@GetMapping("/changepassword/{email}/{pass}/{otp}")
	public ResponseEntity<?> changePassword(@PathVariable String email,@PathVariable String pass,@PathVariable String otp)
	{
		System.out.println("In changePassword  of  SignInSignUpController ");
		if(number!=Integer.parseInt(otp)){
			return ResponseEntity.status(HttpStatus.OK).body(new ServerResponce("Incorrect OTP"));
		}
		
		
		UserEntity userEntity = userService.changePassword(email, pass);
		
		
		return ResponseEntity.status(HttpStatus.OK).body(new ServerResponce("password changed"));
			
			//return ResponseEntity.status(HttpStatus.OK).body(new ServerResponce("email Found"));		
	}
	
	
	@GetMapping("/changeuserpassword/{userid}/{oldpass}/{newpass}")
	public ResponseEntity<?> changeUserPassword(@PathVariable Long userid,@PathVariable String oldpass,@PathVariable String newpass)
	{
		System.out.println("In changeUserPassword  of  SignInSignUpController ");
		
		String password = userService.changeUserPassword(userid, oldpass, newpass);
		
		//UserEntity userEntity = userService.changePassword(email, pass);
		
		System.out.println("Password Status ====="+password);
		return ResponseEntity.status(HttpStatus.OK).body(new ServerResponce(password));
			
			//return ResponseEntity.status(HttpStatus.OK).body(new ServerResponce("email Found"));		
	}
}
