package com.app.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.entities.Address;
import com.app.entities.Product;
import com.app.entities.UserCart;
import com.app.entities.UserEntity;
import com.app.entities.UserOrder;
import com.app.dto.*;
import com.app.service.IAddressService;
import com.app.service.ICartService;
import com.app.service.ICategoryService;
import com.app.service.IOrderedProductService;
import com.app.service.IProductService;
import com.app.service.IUserOrderService;
import com.app.service.IUserService;
import com.app.service.emailsend.EmailSenderService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

import netscape.javascript.JSException;
import netscape.javascript.JSObject;
@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserController {
	
	@Value("${RAZOR_PAY_KEY}")
	private String razorpay_Key;

	@Value("${RAZOR_PAY_SECRET_KEY}")
	private String razorpay_Secret_key;
	
	
	@Autowired
	private IProductService productService;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IAddressService addrService;
	@Autowired
	private ICategoryService categoryService;
	
	@Autowired
	private IUserOrderService orderService;
	
	@Autowired
	private IOrderedProductService orderProdService;
	
	@Autowired
	private ICartService cartService; 
	
	@Autowired
	private EmailSenderService sendEmail;
	
	@Autowired
	private ModelMapper mapper;
	
	private UserEntity user;
	
	public UserController() {
		System.out.println("In Constor Of UserController");
	}
	
	@GetMapping("/products")
	public ResponseEntity<?> listAllProducts() {

		System.out.println("In listAllProducts >>> UserController");

		List<ProductDTO> allProductDetails = productService.getAllProductDetails();
		//System.out.println(allEmpDetails);
		//System.out.println(allEmpDetails.isEmpty());
		if (allProductDetails.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
		//ProductlistDTO prod=new ProductlistDTO(allProductDetails);
		return new ResponseEntity<>(allProductDetails, HttpStatus.OK);
	}

	@GetMapping("/products/{category}/{pname}")
	public ResponseEntity<?> searchProductsByNameandCategory(@PathVariable String pname,@PathVariable String category) {

		System.out.println("In searchProductsByNameandCategory >>> UserController="+category +pname);
		
		if(category.equalsIgnoreCase("All Categories")) {
			System.out.println("IN IFFFFFFFF");
			List<ProductDTO> allEmpDetails = productService.searchProductsByName(pname);
			
			if (allEmpDetails.isEmpty())
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			
			return new ResponseEntity<>(allEmpDetails, HttpStatus.OK);
		}else{
		
		List<ProductDTO> allEmpDetails = productService.searchProductsByNameAndCategory(category,pname);
		
		if (allEmpDetails.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
		return new ResponseEntity<>(allEmpDetails, HttpStatus.OK);
		
		}
	}
	
	
	@GetMapping("/product/{pid}")
	public ResponseEntity<?> getProductsByid(@PathVariable Long pid) {

		System.out.println("In getProductsByid >>> UserController="+pid);

		ProductDTO allEmpDetails = productService.getProductsById(pid);
		System.out.println(allEmpDetails);
		
		
		
		return new ResponseEntity<>(allEmpDetails, HttpStatus.OK);
	}
	
	
	
	@GetMapping("/cart/{userid}/{prodid}/{qty}")
	public ResponseEntity<?> addToCart(@PathVariable Long userid,@PathVariable Long prodid,@PathVariable int qty,HttpSession session ) {
		int updatedQty=0;
		System.out.println("In addToCart >>> UserController");

//		//List<ProductDTO> allEmpDetails = productService.getAllProductDetails();
//		UserEntity user = (UserEntity) session.getAttribute("userdetails");
//		System.out.println(user);
		UserCart userCart = cartService.checkProductExistInUserCart(userid, prodid);
		if(userCart==null) {
		
		cartService.addProductsInCart(userid, prodid, qty);
		}else {
			System.out.println("Product Already present in Cart");
			updatedQty=cartService.updateCart( userCart,qty);
		}
		return new ResponseEntity<>( HttpStatus.OK);
	}
	
	
	@GetMapping("/updatecart/{userid}/{prodid}/{qty}")
	public ResponseEntity<?> updateCart(@PathVariable Long userid,@PathVariable Long prodid,@PathVariable int qty,HttpSession session ) {
		int updatedQty=0;
		System.out.println("In updateCart >>> UserController");


		UserCart userCart = cartService.checkProductExistInUserCart(userid, prodid);
		if(userCart==null) {
		
		cartService.addProductsInCart(userid, prodid, qty);
		}else {
			
			updatedQty=cartService.updateCartQty( userCart,qty);
		}
		return new ResponseEntity<>( HttpStatus.OK);
	}
	
	@GetMapping("/cart/{userid}")
	public ResponseEntity<?> getCartProducts(@PathVariable Long userid,HttpSession session ) {

		System.out.println("In getCartProducts >>> UserController");

		UserCartDTO userCart=cartService.getCartProduct(userid);
		
//		
		return new ResponseEntity<>(userCart, HttpStatus.OK);
	}
	@GetMapping("/deleteproductcart/{userid}/{prodid}")
	public ResponseEntity<?> deleteCartProducts(@PathVariable Long userid,@PathVariable Long prodid,HttpSession session ) {

		System.out.println("In deleteCartProducts >>> UserController");

		int status=cartService.deleteProductFromCart(userid,prodid);
		
//		
		return new ResponseEntity<>(status, HttpStatus.OK);
	}
	
	@GetMapping("/category")
	public ResponseEntity<?> listAllCategory() {

		System.out.println("In listAllCategory >>> AdminController");

		List<CategoryDTO> allCategories = categoryService.getallCategories();
		System.out.println(allCategories);
		System.out.println(allCategories.isEmpty());
		if (allCategories.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
		return new ResponseEntity<>(allCategories, HttpStatus.OK);
	}


	
	
	
	@GetMapping("/createpaymentorder/{userid}/{total}")
	public ResponseEntity<?> createPaymentOrder(@PathVariable Long userid,@PathVariable double total,HttpSession session ) throws Exception {

		System.out.println("In createPaymentOrder >>> UserController");
			//int status=cartService.deleteProductFromCart(userid,prodid);
		RazorpayClient client=new RazorpayClient(razorpay_Key, razorpay_Secret_key);
//		
		
		JSONObject ob=new JSONObject();
		ob.put("amount",total*100);
		ob.put("currency","INR");
		ob.put("receipt","txn_12345");
		
		Order order=client.Orders.create(ob);
		System.out.println(order);
		
		//{"amount":5000,"amount_paid":0,"notes":[],"created_at":1662552957,"amount_due":5000,"currency":"INR","receipt":"txn_12345","id":"order_KF0UN8zrT3yMFV","entity":"order","offer_id":null,"status":"created","attempts":0}
		UserOrder neworder=new UserOrder();
		double totalamount=Double.parseDouble(order.get("amount").toString());
		neworder.setTotalPrice(totalamount/100);
		neworder.setRazorId(order.get("id"));
		neworder.setStatus(order.get("status"));
		neworder.setOrderDate(order.get("created_at").toString());
		UserOrder saveUserOrder = orderService.saveUserOrder(neworder,userid);
		
		
		//save cart products to permnent table
		int orderSaveStatus = orderProdService.orderCartProduct(userid,saveUserOrder.getId());
		System.out.println(orderSaveStatus);
		
		
		UserOrderDTO orderDTO=mapper.map(saveUserOrder, UserOrderDTO.class);
		
		return new ResponseEntity<>(orderDTO, HttpStatus.OK);
	}
	
	@GetMapping("/postorderprocess/{orderid}/{paymentid}")
	public ResponseEntity<?> postPaymentOrderProcess(@PathVariable String orderid,@PathVariable String paymentid,HttpSession session ) {
			//HERE String order id id RazorPay Order ID
		System.out.println("In postOrderProcess >>> UserController");
		System.out.println(orderid);
		System.out.println(paymentid);
		UserOrder saveUserOrder = orderService.orderPaymentConfirmation(orderid,paymentid);
		
		
		UserOrderDTO orderDTO=mapper.map(saveUserOrder, UserOrderDTO.class);
		
		
		
		return new ResponseEntity<>(orderDTO, HttpStatus.OK);
	}
	
	@GetMapping("/address/{userid}")
	public ResponseEntity<?> getUserAddress(@PathVariable Long userid,HttpSession session ) {

		System.out.println("In getUserAddress >>> UserController");
		List<AddressDTO> addrDTOList=new ArrayList<AddressDTO>();
		List<Address> userAddressess = userService.getUserAddressess(userid);
		userAddressess.stream().forEach((addr)->{
			AddressDTO addrDto=mapper.map(addr,AddressDTO.class );
			addrDTOList.add(addrDto);
		});
		System.out.println(userService.getUserAddressess(userid));
		
		return new ResponseEntity<>(addrDTOList, HttpStatus.OK);
	}
	
	@PostMapping("/address/{userid}")
	public ResponseEntity<?> AddUserAddress(@PathVariable Long userid ,@RequestBody @Valid AddressDTO address,HttpSession session ) {

		System.out.println("In getUserAddress >>> UserController");
		List<AddressDTO> addrDTOList=new ArrayList<AddressDTO>();
		List<Address> userAddressess = userService.addUserAddressess(address,userid);
		userAddressess.stream().forEach((addr)->{
			AddressDTO addrDto=mapper.map(addr,AddressDTO.class );
			addrDTOList.add(addrDto);
		});
		System.out.println(userService.getUserAddressess(userid));
		
		return new ResponseEntity<>(addrDTOList, HttpStatus.OK);
	}
	
	@GetMapping("/userinfo/{userid}")
	public ResponseEntity<?> getUserInfo(@PathVariable Long userid,HttpSession session ) {

		System.out.println("In getUserInfo >>> UserController");
		UserDTO user=userService.getUserInfo(userid);
		
		return new ResponseEntity<>(user, HttpStatus.OK);
	}
	
	@PutMapping("/updateuser/{userid}")
	public ResponseEntity<?> updateUserInfo(@PathVariable Long userid,@RequestBody @Valid UserDTO user){
		
		System.out.println("In updateUserInfo OF  UserController");

		UserDTO updateduser=userService.updateUserInfo(userid,user);
		return ResponseEntity.status(HttpStatus.CREATED).body(updateduser);
	}
	
	
	@PutMapping("/updateuseraddress/{addrid}")
	public ResponseEntity<?> updateUserAddress(@PathVariable Long addrid,@RequestBody AddressDTO addr){
		
		System.out.println("In updateUserAddress OF  UserController");

		AddressDTO updateUserAddress = addrService.updateUserAddress(addr, addrid);
		return ResponseEntity.status(HttpStatus.CREATED).body(updateUserAddress);
	}
	
	@GetMapping("/userprofileimage/{userid}/{image}")
	public ResponseEntity<?> setUserProfileImage(@PathVariable Long userid,@PathVariable String image,HttpSession session ) {

		System.out.println("In getUserInfo >>> UserController");
		UserDTO user=userService.getUserInfo(userid);
		
		return new ResponseEntity<>(userService.setUserProfileImage(userid, image), HttpStatus.OK);
	}
	
	@GetMapping("/getalluserorders/{userId}")
	public ResponseEntity<?> getallUserOrders(@PathVariable Long userId) {

		System.out.println("In getALLOrders >>> AdminController");
		
		List<UserOrderDTO> allOrders = orderService.getAllUserOrder(userId);
		//System.out.println(allOrders);
		//System.out.println(allOrders.isEmpty());
		if (allOrders.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
		
		
		return new ResponseEntity<>(allOrders, HttpStatus.OK);
	}
	
	
	@GetMapping("/getorderdetails/{orderid}")
	public ResponseEntity<?> getOrderdetailsById(@PathVariable Long orderid) {

		System.out.println("In getOrderdetailsById >>> AdminController");
		
		OrderDetailsDTO orderDetails = orderProdService.getOrderDetails(orderid);
		//System.out.println(allOrders);
		//System.out.println(allOrders.isEmpty());
//		Map<String, Object> model = new HashMap<>();
//		model.put("orderid", orderDetails.getUserOrderDTO().getId());
//		
//		//model.put("userName", userEntity.getUserName());
//		sendEmail.sendEmailOrder("udaywankar@gmail.com" , model);
		
		return new ResponseEntity<>(orderDetails, HttpStatus.OK);
	}
	
	@GetMapping("/canceluserorder/{orderid}")
	public ResponseEntity<?> cancelUserOrder(@PathVariable Long orderid) {

		System.out.println("In cancelUserOrder >>> AdminController");
		
		
		
		return new ResponseEntity<>(orderService.cancelOrder(orderid), HttpStatus.OK);
	}
	
	@GetMapping("/getproductPage/{category}/{pname}/{count}/{page}")
	public ResponseEntity<?> getProductsByPageConfig(@PathVariable String category,@PathVariable String pname,@PathVariable int count,@PathVariable int page) {

		System.out.println("In getProductsByPageConfig >>> AdminController");
		
		
		
			ProductPageDTO searchProductsByNameAndCategoryPage = productService.searchProductsByNameAndCategoryPage(category, pname, page, count);
			
//			if(searchProductsByNameAndCategoryPage.getList().isEmpty()) {
//				
//				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//			}
			
		
		
		return new ResponseEntity<>(searchProductsByNameAndCategoryPage, HttpStatus.OK);
	}
	
	
}
