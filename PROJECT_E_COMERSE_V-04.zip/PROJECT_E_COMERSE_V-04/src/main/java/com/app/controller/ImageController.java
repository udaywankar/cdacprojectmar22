package com.app.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.app.service.ImageHandlingService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@CrossOrigin
public class ImageController {
	public ImageController() {
		log.info("in ctor of "+getClass());
	}
	
	@Autowired
	private ImageHandlingService imageHandling;
	
	
	@GetMapping(value="/thumbimage/{prodid}", produces= {MediaType.IMAGE_GIF_VALUE,MediaType.IMAGE_PNG_VALUE,MediaType.IMAGE_JPEG_VALUE})
	public ResponseEntity<?> DownloadImage(@PathVariable Long prodid) throws IOException {

		System.out.println("In DownloadImage >>> ImageController="+prodid);

		byte[] imageContent=imageHandling.getImage(prodid);
		return ResponseEntity.ok(imageContent);
	}
	
	
	@GetMapping(value="/image/{prodid}", produces= {MediaType.IMAGE_GIF_VALUE,MediaType.IMAGE_PNG_VALUE,MediaType.IMAGE_JPEG_VALUE})
	public ResponseEntity<?> DownloadDisplayImage(@PathVariable Long prodid) throws IOException {

		System.out.println("In DownloadImage >>> ImageController="+prodid);

		byte[] imageContent=imageHandling.getImage(prodid);
		return ResponseEntity.ok(imageContent);
	}
}
