package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dto.AddressDTO;
import com.app.dto.OrderDetailsDTO;
import com.app.dto.ProductDTO;
import com.app.dto.UserCartDTO;
import com.app.dto.UserDisplayCartDTO;
import com.app.dto.UserOrderDTO;
import com.app.entities.Address;
import com.app.entities.OrderedProducts;
import com.app.entities.Product;
import com.app.entities.UserCart;
import com.app.entities.UserEntity;
import com.app.entities.UserOrder;
import com.app.repository.CartRepository;
import com.app.repository.OrderRepository;
import com.app.repository.OrderedProductRepository;
import com.app.repository.ProductRepository;
import com.app.repository.UserRepository;

@Service
@Transactional
public class OrderedProductServiceImpl implements IOrderedProductService {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private OrderRepository orderRepo;
	
	@Autowired
	private OrderedProductRepository orderProdRepo;
	
	
	@Autowired
	private ProductRepository productRepo;

	@Autowired
	private CartRepository cartRepo;
	
	// mapper
	@Autowired
	private ModelMapper mapper;

	
	@Override
	public int orderCartProduct(Long userid,Long orderid) {
		// TODO Auto-generated method stub
			System.out.println("IN orderCartProduct of OrderedProductServiceImpl line 49");
			UserEntity u=userRepo.findById(userid).get();
			System.out.println(u);			
			List<UserCart> cart=u.getCart();
			UserOrder order=orderRepo.getById(orderid);
			System.out.println(order);
			cart.stream().forEach((cartitem)->{
				System.out.println(" cart Foreach");
				OrderedProducts orderedProd=new OrderedProducts();
				orderedProd.setOrder(order);
				orderedProd.setProduct(cartitem.getProduct());
				orderedProd.setQuantity(cartitem.getQuantity());
				orderProdRepo.save(orderedProd);
				System.out.println(" cart Foreach Before delete 62");
				cartRepo.deleteProductExistInUserCart(userid,cartitem.getProduct().getId());
				System.out.println("Cart Deletion Complete!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			});
		

		return 1;
	}

	
	
	@Override
	public OrderDetailsDTO getOrderDetails(Long orderid) {
		// TODO Auto-generated method stub
			System.out.println("IN getOrderDetails of OrderedProductServiceImpl line 80");
			List<OrderedProducts> findByOrderId = orderProdRepo.findByOrderId(orderid);
			System.out.println(findByOrderId);
			UserCartDTO orderproducts=new UserCartDTO();
			

			findByOrderId.stream().forEach((op)->{
				UserDisplayCartDTO orderproductDTO=new UserDisplayCartDTO();
				orderproductDTO.setQuantity(op.getQuantity());
				
				ProductDTO pDTO=mapper.map(op.getProduct(),ProductDTO.class);
				pDTO.setCategoryName(op.getProduct().getCategory().getCategoryName());
				orderproductDTO.setProduct(pDTO);
				orderproducts.getList().add(orderproductDTO);
			});
			
			System.out.println(orderid);
			UserOrder order=orderRepo.getById(orderid);
			OrderDetailsDTO orderDTO=new OrderDetailsDTO();
			orderDTO.setUserName(order.getUser().getUserName());
			List<Address> addr=order.getUser().getAddressess();
			Address  orderAddress=new Address();
			for (Address address : addr) {
				if(address.getType().equals("SHIP") || address.getType().equals("BOTH")  ) {
					orderAddress=address;
					break;
				}
			}
				
			//Address orderAddress1=(Address) addr.stream().filter((a)-> a.getType().equals("SHIP") );
			//orderDTO.setAddress(mapper.map(order.getUser().getShippingAddr(), AddressDTO.class));
			orderDTO.setAddress(mapper.map(orderAddress, AddressDTO.class));
			orderDTO.setUserOrderDTO(mapper.map(order, UserOrderDTO.class));
			
			orderDTO.setOrderedProducts(orderproducts);
		return orderDTO;
	}



	@Override
	public int decreaseStockAfterSuccessFullOrder(Long orderid) {
		// TODO Auto-generated method stub
		List<OrderedProducts> op=orderProdRepo.findByOrderId(orderid);
		op.forEach((productordered)->{
			Product p=productordered.getProduct();
			
			if(p.getSold()==null) {
				p.setSold(0);
			}
			p.setSold(p.getSold()+productordered.getQuantity());
			p.setStock(p.getStock()-productordered.getQuantity());
		});
		return 0;
	}



	



	

}
