package com.app.service;

import java.util.List;

import com.app.dto.AddressDTO;
import com.app.dto.UserDTO;
import com.app.dto.UserRegResponse;
import com.app.entities.Address;
import com.app.entities.UserEntity;

public interface IUserService {

	UserRegResponse registerUser(UserDTO user);

	UserEntity getAnthUser(String email);
	UserEntity changePassword(String email,String pass);
	String changeUserPassword(Long userid,String oldpass,String newpass);
	List<Address> getUserAddressess(Long userId);
	List<Address> addUserAddressess(AddressDTO addr,Long userId);
	UserDTO getUserInfo(Long userId);
	UserDTO  updateUserInfo(Long userid ,UserDTO user);
	String setUserProfileImage(Long userId,String image);
}
