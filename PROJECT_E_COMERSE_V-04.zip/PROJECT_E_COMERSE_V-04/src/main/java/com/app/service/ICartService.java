package com.app.service;

import java.util.List;

import com.app.dto.UserCartDTO;
import com.app.dto.UserDTO;
import com.app.dto.UserDisplayCartDTO;
import com.app.dto.UserRegResponse;
import com.app.entities.Product;
import com.app.entities.UserCart;
import com.app.entities.UserEntity;

public interface ICartService {

//	UserRegResponse registerUser(UserDTO user);

	void addProductsInCart(Long userid,Long Prodid,int qty);

	UserCartDTO getCartProduct(Long userid);
	
	

	int deleteProductFromCart(Long userid,Long prodid);
	
	UserCart checkProductExistInUserCart(Long userid,Long prodid);

	int updateCart(UserCart userCart, int qty);

	int updateCartQty(UserCart userCart, int qty);

}
