package com.app.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.app.dto.ProductDTO;
import com.app.entities.Product;
import com.app.repository.ProductRepository;
@Service
@Transactional
public class ImageHandlingServiceImpl implements ImageHandlingService {

	
	@Value("${file.upload.location}")
	private String baseFolder;
	
	
	@Autowired
	private ProductRepository productRepo;
	
	
	@Autowired
	private ModelMapper  mapper;
	
	@Override
	public ProductDTO storeImage(Long empid, MultipartFile imageData) throws IOException {
		// TODO Auto-generated method stub
		Product product=productRepo.findById(empid).orElseThrow(()-> new RuntimeException("invalid emp id"));
		// emp persistance
		//get complete path
		//String completePath=baseFolder+File.separator+imageData.getOriginalFilename();
		String fileName=imageData.getOriginalFilename();
		System.out.println(fileName);
		String [] split = fileName.split("[.]",0);
		
		System.out.println(split[1]);
		String completePath=baseFolder+File.separator+"product_"+empid+"."+split[1];
		System.out.println(completePath);
		System.out.println("Coppied no of Bytes=="+
		
				Files.copy(imageData.getInputStream(), Paths.get(completePath), StandardCopyOption.REPLACE_EXISTING));
		product.setImage(completePath);// save complete path in DB
		
		//in case of savin file in database blob
		//imageData.getBytes() --> byte[]
		//emp.setImagePath(imageData.getBytes());
		
		
		return null;//mapper.map(emp, EmployeePayload.class);
	}
	
	@Override
	public ProductDTO storeDisplayImage(Long empid, MultipartFile imageData) throws IOException {
		// TODO Auto-generated method stub
		Product product=productRepo.findById(empid).orElseThrow(()-> new RuntimeException("invalid emp id"));
		// emp persistance
		//get complete path
		//String completePath=baseFolder+File.separator+imageData.getOriginalFilename();
		String fileName=imageData.getOriginalFilename();
		System.out.println(fileName);
		String [] split = fileName.split("[.]",0);
		
		
		String completePath=baseFolder+File.separator+"product_"+empid+"."+split[1];
		System.out.println(completePath);
		System.out.println("Coppied no of Bytes=="+
		
				Files.copy(imageData.getInputStream(), Paths.get(completePath), StandardCopyOption.REPLACE_EXISTING));
		product.setImage(completePath);// save complete path in DB
		
		//in case of savin file in database blob
		//imageData.getBytes() --> byte[]
		//emp.setImagePath(imageData.getBytes());
		
		
		return null;//mapper.map(emp, EmployeePayload.class);
	}


	@Override
	public byte[] getImage(Long empid) throws IOException {
		System.out.println("In restoreImage >>>> ImageHandlingServiceImpl");
		Product product=productRepo.findById(empid).orElseThrow(()-> new RuntimeException("invalid Product id"));
		// emp persistance
		// get completePath of Image
		String completePath=product.getImage();
		//extract image via path
		System.out.println(Paths.get(completePath));
		
		// in case of blob in db --simply call emp.getImage--byte[]--> retn to caller
		return Files.readAllBytes(Paths.get(completePath));
	}

	

}
