package com.app.service;

import java.util.List;

import javax.validation.Valid;

import com.app.dto.ProductDTO;
import com.app.dto.ProductPageDTO;
import com.app.dto.ServerResponce;
import com.app.entities.Product;

public interface IProductService {

	ServerResponce addProduct(@Valid ProductDTO product);

	List<ProductDTO> getAllProductDetails();

	List<ProductDTO> searchProductsByName(String pname);

	List<ProductDTO> searchProductsByNameAndCategory(String category,String pname);
	ProductPageDTO searchProductsByNameAndCategoryPage(String category,String pname,int page,int count);
	ProductDTO getProductsById(Long pid);
	ProductDTO updateProduct(Long prodid,@Valid ProductDTO product);
	String deleteProductsById(Long pid);
}
