package com.app.service;

import java.util.List;

import com.app.dto.AddressDTO;
import com.app.dto.StaffDTO;
import com.app.dto.UserDTO;
import com.app.dto.UserRegResponse;
import com.app.entities.Address;
import com.app.entities.UserEntity;

public interface IStaffService {

	UserRegResponse registerStaff(StaffDTO user);

	List<StaffDTO> getAllStaff();
	
	StaffDTO addNewStaff(StaffDTO staff);
//	UserEntity getAnthUser(String email);
//	UserEntity changePassword(String email,String pass);
//	List<Address> getUserAddressess(Long userId);
//	List<Address> addUserAddressess(AddressDTO addr,Long userId);
//	UserDTO getUserInfo(Long userId);
//	String setUserProfileImage(Long userId,String image);
}
