package com.app.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dto.ProductDTO;
import com.app.dto.ProductPageDTO;
import com.app.dto.ServerResponce;
import com.app.entities.Category;
import com.app.entities.Product;
import com.app.repository.CategoryRepository;
import com.app.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {

	@Autowired
	private ProductRepository productRepo;

	@Autowired
	private CategoryRepository categoryRepo;
	
	// mapper
	@Autowired
	private ModelMapper mapper;

	@Override
	public ServerResponce addProduct(@Valid ProductDTO product) {
		// TODO Auto-generated method stub
		Product prod=mapper.map(product, Product.class);
		System.out.println(prod);
		String categoryName = product.getCategoryName();
		Category persistentCategory=categoryRepo.findByCategoryName(categoryName).orElseThrow(()-> new RuntimeException("Invalid Category name"));
				//.orElse(categoryRepo.save(new Category(categoryName)));
				//.orElseThrow(()-> new RuntimeException("Invalid Category name"));
		System.out.println(persistentCategory);
		prod.setCategory(persistentCategory);
		System.out.println(prod);
		productRepo.save(prod);
		return new ServerResponce("Product Added Successfully"+persistentCategory.toString());
	}

	@Override
	public List<ProductDTO> getAllProductDetails() {
		// TODO Auto-generated method stub
		List<ProductDTO> prodDto=new ArrayList<ProductDTO>();
		ProductDTO temp;
		List<Product> list = productRepo.findAll();
		//System.out.println(list);
		System.out.println("/////////////////////////////////////////////////////////");
		for( Product p : list) {
			temp=mapper.map(p, ProductDTO.class);
			//System.out.println(p.getCategory());
			temp.setCategoryName(p.getCategory().getCategoryName());
			//System.out.println(temp);
			prodDto.add(temp);
			
		}
		//System.out.println(prodDto);
//		list.stream().map(p-> mapper.map(p, ProductDTO.class))
//		.forEach((Pdto) -> 
//			prodDto.add(Pdto));
		
		return prodDto;
	}

	@Override
	public List<ProductDTO> searchProductsByName(String pname) {
		// TODO Auto-generated method stub
		
		List<ProductDTO> prodDto=new ArrayList<ProductDTO>();
		List<Product> list = productRepo.searchProductsByName(pname);
		System.out.println(list);
		
		list.forEach((p)->{
			ProductDTO dto= mapper.map(p, ProductDTO.class);
			dto.setCategoryName(p.getCategory().getCategoryName());
			prodDto.add(dto);
		});
		return prodDto;
	}
	
	
	@Override
	public ProductDTO getProductsById(Long pid) {
		// TODO Auto-generated method stub
		System.out.println("IN getProductsById of ProductServiceImpl");
		Product prod=productRepo.findById(pid).orElseThrow(()-> new RuntimeException("Invalid Product Id"));
		System.out.println(prod);
		if(prod.getVisits()==null) {
			prod.setVisits(0l);
		}
		prod.setVisits(prod.getVisits()+1);
		Category category = prod.getCategory();
		ProductDTO productDTO=mapper.map(prod, ProductDTO.class);
		productDTO.setCategoryName(category.getCategoryName());
		return productDTO;
	}
	
	@Override
	public String deleteProductsById(Long pid) {
		// TODO Auto-generated method stub
		
			productRepo.deleteById(pid);
		
		
		
		return "Product Deleted";
	}

	@Override
	public ProductDTO updateProduct(Long prodid,ProductDTO product) {
		System.out.println("In updateProduct of ProductServiceImpl");
		Product prod=mapper.map(product, Product.class);
		
		prod.setId(prodid);
		System.out.println(prod);
		String categoryName = product.getCategoryName();
		Category persistentCategory=categoryRepo.findByCategoryName(categoryName).orElseThrow(()-> new RuntimeException("Invalid Category name"));
		prod.setCategory(persistentCategory);
		productRepo.save(prod);
		
		ProductDTO productDTO=mapper.map(prod, ProductDTO.class);
		productDTO.setCategoryName(categoryName);
		return productDTO;
	}

	@Override
	public List<ProductDTO> searchProductsByNameAndCategory(String category, String pname) {
		// TODO Auto-generated method stub
		List<ProductDTO> prodDto=new ArrayList<ProductDTO>();
		List<Product> list = productRepo.searchProductsByNameAndCategory(pname,category);
		System.out.println(list);
		
		list.forEach((p)->{
			ProductDTO dto= mapper.map(p, ProductDTO.class);
			dto.setCategoryName(p.getCategory().getCategoryName());
			prodDto.add(dto);
		});
		return prodDto;
	}

	
	@Override
	public ProductPageDTO searchProductsByNameAndCategoryPage(String category, String pname, int page, int count) {
		// TODO Auto-generated method stub
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!IN searchProductsByNameAndCategoryPage   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		List<ProductDTO> prodDto=new ArrayList<ProductDTO>();
		List<Product> prodList=new ArrayList<Product>();
		Page<Product> searchProductsByNamePage;
		Pageable pageable = PageRequest.of(page, count);
		
		
		if(category.equalsIgnoreCase("All Categories")) {
			System.out.println("IN IFFFFFFFF");
			searchProductsByNamePage = productRepo.searchProductsByNamePage(pname, pageable);
		
		}else{
		
			searchProductsByNamePage= productRepo.searchProductsByNameAndCategoryPage(pname, category, pageable);
			System.out.println(searchProductsByNamePage);
		}
		prodList=searchProductsByNamePage.getContent();
		int totalPages = searchProductsByNamePage.getTotalPages();
		
		prodList.forEach((p)->{
			ProductDTO dto= mapper.map(p, ProductDTO.class);
			dto.setCategoryName(p.getCategory().getCategoryName());
			prodDto.add(dto);
		});
		
		
		ProductPageDTO productPageDTO=new ProductPageDTO();
		productPageDTO.setList(prodDto);
		productPageDTO.setPage(page);
		productPageDTO.setTotalPages(totalPages);
		return productPageDTO;
		
		
	}

	

}
