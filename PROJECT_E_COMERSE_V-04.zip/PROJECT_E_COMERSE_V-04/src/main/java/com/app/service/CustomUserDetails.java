package com.app.service;

import java.util.Collection;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.app.entities.Role;
import com.app.entities.UserEntity;
import com.app.dto.*;
import lombok.ToString;
@ToString
public class CustomUserDetails implements UserDetails {
	private UserEntity user;
	private Set<Role> userRoles;
	private String isAdmin="USER";
	public CustomUserDetails(UserEntity user) {
		super();
		this.user = user;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// Meaning : This method should ret Collection(List) of granted authorities ,
		// for a specific user --which will be later stored in Auth obj
		//SimpleGrantedAuthority(String roleName)  imple  GrantedAuthority
		//UserEntity ---> Role	
		
		return user.getUserRoles() //Set<Role>
		 .stream() //Stream<Role>
		 .map(role -> new SimpleGrantedAuthority(role.getRoleName().name())) //Stream<SimpleGrantedAuthority>
		 .collect(Collectors.toList());		
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return user.getPassword();
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return user.getEmail();
	}

	public String getUserWithId() {
		// TODO Auto-generated method stub
		System.out.println(" #############  getUserWithId ###################");
		user.getUserRoles() //Set<Role>
		 .stream() //Stream<Role>
		 .forEach((role)->{
			 
			 System.out.println(role.getRoleName().name());
			 if(role.getRoleName().name()=="ROLE_ADMIN") {
				 isAdmin="ADMIN";
			}
		 }); 
		String rtn=user.getEmail()+"-"+user.getUserId().toString()+"-"+isAdmin+"-"+user.getUserName();
		
		return rtn;
	}
	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

}
