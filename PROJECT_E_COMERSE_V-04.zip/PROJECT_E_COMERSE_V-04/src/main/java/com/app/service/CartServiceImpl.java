package com.app.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dto.ProductDTO;
import com.app.dto.UserCartDTO;
import com.app.dto.UserDisplayCartDTO;
import com.app.entities.Product;
import com.app.entities.UserCart;
import com.app.entities.UserEntity;
import com.app.repository.CartRepository;
import com.app.repository.OrderRepository;
import com.app.repository.ProductRepository;
import com.app.repository.UserRepository;

@Service
@Transactional
public class CartServiceImpl implements ICartService {
	// dep : user repo n role repo
	@Autowired
	private UserRepository userRepo;

	@Autowired
	private OrderRepository orderRepo;
	
	@Autowired
	private ProductRepository productRepo;

	@Autowired
	private CartRepository cartRepo;
	
	// mapper
		@Autowired
		private ModelMapper mapper;

	
	@Override
	public void addProductsInCart(Long userid, Long Prodid, int qty) {
		// TODO Auto-generated method stub
		Product p=productRepo.getById(Prodid);
		UserEntity u=userRepo.getById(userid);
		System.out.println("%%%%%%%%%%%%%%%%  Add To Cart %%%%%%%%%%%%%%%%%%");
		System.out.println("%%%%%%%%%%%%%%%% Product %%%%%%%%%%%%%%%%%%");
		System.out.println(p);
		System.out.println("%%%%%%%%%%%%%%%%  User %%%%%%%%%%%%%%%%%%");
		System.out.println(u);
		Integer quantity=qty;
		UserCart cart=new UserCart(quantity, p, u);
		
		//UserCart cart=new UserCart();
//		cart.setProduct(p);
//		cart.setQuantity(quantity);
//		cart.setUser(u);
//		UserCart savedCart = cartRepo.save(cart);
//		System.out.println(savedCart);
		
		u.getCart().add(cart);
		//u.getCart().add(savedCart);
	}

	@Override
	public UserCartDTO getCartProduct(Long userid) {
		// TODO Auto-generated method stub
		//List<UserCart> userCart = cartRepo.findByUserId(userid);
		
		UserEntity u=userRepo.getById(userid);
		
		UserCartDTO cartDTO=new UserCartDTO();
		UserDisplayCartDTO cartDisplay=new UserDisplayCartDTO();
		List<UserCart> cart=u.getCart();
		System.out.println(cart);
		/*
		 *  
		 * System.out.println("%%%%%%%%%%%%%%%%cart from Table %%%%%%%%%%%%%%%%%%");
		 * System.out.println(cart);
		 * System.out.println("%%%%%%%%%%%%%%%%cart from Table %%%%%%%%%%%%%%%%%%");
		 */
		System.out.println("%%%%%%%%%%%%%%%%  Stream %%%%%%%%%%%%%%%%%%");
		 
		 cart.stream().forEach((c)->{
		  
		ProductDTO d=mapper.map(c.getProduct(),ProductDTO.class);
		d.setCategoryName(c.getProduct().getCategory().getCategoryName());
		System.out.println(d);
		
		cartDTO.getList().add(new UserDisplayCartDTO(c.getQuantity(), d));
		 
		});
		
		System.out.println("8888888888888888888888888888888888888888888888888888");
		System.out.println(cartDisplay);
		System.out.println("8888888888888888888888888888888888888888888888888888");
	
		/*
		 * UserEntity user=new UserEntity(); user.setUserId(userid); List<UserCart>
		 * userCart = cartRepo.findAllByUser(user); System.out.println(
		 * "ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc");
		 * System.out.println(userCart); System.out.println(
		 * "ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc");
		 * 
		 * UserCartDTO cartDTO=new UserCartDTO(); UserDisplayCartDTO cart=new
		 * UserDisplayCartDTO();
		 * 
		 * userCart.stream() .forEach((c)->{ProductDTO d=mapper.map(c.getProduct(),
		 * ProductDTO.class); cart.setProduct(d); cart.setQuantity(c.getQuantity());
		 * cartDTO.getList().add(cart); });
		 * 
		 * System.out.println(cartDTO);
		 */
		System.out.println(cartDTO);
		return cartDTO;
		
	}
	
	@Override
	public int deleteProductFromCart(Long userid,Long prodid) {
		// TODO Auto-generated method stub
		System.out.println("%%%%%%%%%%%%%%%%  Delete%%%%%%%%%%%%%%%%%%");
		Product p=productRepo.getById(prodid);
		UserEntity u=userRepo.getById(userid);
		int userCart = cartRepo.deleteProductExistInUserCart(userid, prodid);
		System.out.println(userCart);
		//cartRepo.delete(null);
		
		
		
		
		
		return 1;
	}

	@Override
	public UserCart checkProductExistInUserCart(Long userid, Long prodid) {
		// TODO Auto-generated method stub
		UserCart userCart = cartRepo.checkProductExistInUserCart(userid, prodid);
		System.out.println("^^^^^^^^^^^^^^^userCart^^^^^^^^^^^^^^^^^^^^^^^");
		System.out.println(userCart);
		return userCart ;
	}

	@Override
	public int updateCart(UserCart userCart, int qty) {
		// TODO Auto-generated method stub
		System.out.println("^^^^^^^^^^^^^^^UpdateCart^^^^^^^^^^^^^^^^^^^^^^^");
		System.out.println(userCart);
		System.out.println("Productid= "+userCart.getProduct().getId());
		System.out.println("Userid= "+userCart.getUser().getUserId());
		//UserCart userCartPersist = cartRepo.getById(userCart.getId());
		UserCart userCartPersist = cartRepo.checkProductExistInUserCart( userCart.getUser().getUserId(),userCart.getProduct().getId());
		System.out.println(userCartPersist);
		
		userCartPersist.setQuantity(userCartPersist.getQuantity()+qty);
		
		return userCartPersist.getQuantity();
	}

	@Override
	public int updateCartQty(UserCart userCart, int qty) {
		UserCart userCartPersist =  cartRepo.checkProductExistInUserCart( userCart.getUser().getUserId(),userCart.getProduct().getId());
		userCartPersist.setQuantity(qty);
		
		return userCartPersist.getQuantity();

		
	}

	
	
	
	

}
