package com.app.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dto.CategoryDTO;
import com.app.dto.ServerResponce;
import com.app.entities.Category;
import com.app.repository.CategoryRepository;


@Service
@Transactional
public class CategoryServiceImpl implements ICategoryService {

	@Autowired
	private CategoryRepository categoryRepo;

	// mapper
	@Autowired
	private ModelMapper mapper;

	@Override
	public ServerResponce addCategory(@Valid CategoryDTO category) {

		Category categoryEntity = mapper.map(category, Category.class);
		System.out.println(categoryEntity);
		Category SavedCategory = categoryRepo.save(categoryEntity);
		return new ServerResponce("Category saved Successfully with id =" + SavedCategory.getId());
	}

	@Override
	public List<CategoryDTO> getallCategories() {
		// TODO Auto-generated method stub
		List<CategoryDTO> catDto = new ArrayList<CategoryDTO>();
		List<Category> list = categoryRepo.findAll();
		list.stream().map(p -> mapper.map(p, CategoryDTO.class)).forEach(Pdto -> catDto.add(Pdto));
		return catDto;
	}

}
