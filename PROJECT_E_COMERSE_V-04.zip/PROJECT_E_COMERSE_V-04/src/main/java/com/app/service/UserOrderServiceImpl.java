package com.app.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.catalina.mapper.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dto.OrderDetailsDTO;
import com.app.dto.UserDisplayCartDTO;
import com.app.dto.UserOrderDTO;
import com.app.entities.Address;
import com.app.entities.UserEntity;
import com.app.entities.UserOrder;
import com.app.repository.OrderRepository;
import com.app.repository.UserRepository;
import com.app.service.emailsend.EmailSenderService;

@Service
@Transactional
public class UserOrderServiceImpl implements IUserOrderService {
	// dep : user repo n role repo
	
	@Autowired
	private OrderRepository orderRepo;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private IOrderedProductService orderProdService; 
	
	@Autowired
	private EmailSenderService sendEmail;
	
	@Autowired
	private ModelMapper mapper;
	
	@Override
	public UserOrder saveUserOrder(UserOrder order,Long userid) {
		// TODO Auto-generated method stub
		UserEntity findById = userRepo.findById(userid).orElseThrow(()-> new RuntimeException("Invalid USerID"));
		order.setUser(findById);
		
		
		return orderRepo.save(order);
	}

	@Override
	public List<UserOrderDTO> getAllOrder() {
		// TODO Auto-generated method stub
		List<UserOrderDTO> orderDTO=new ArrayList<UserOrderDTO>();
		List<UserOrder> allOrders = orderRepo.findAll();
		allOrders.stream().forEach((order)->{
			UserOrderDTO orderdto=mapper.map(order, UserOrderDTO.class);
			orderDTO.add(orderdto);
		});
		
		return orderDTO;
	}
	@Override
	public List<UserOrderDTO> getAllUserOrder(Long userId) {
		// TODO Auto-generated method stub
		List<UserOrderDTO> orderDTO=new ArrayList<UserOrderDTO>();
		List<UserOrder> allOrders = (List<UserOrder>) orderRepo.findByUserid(userId);
		
		allOrders.stream().forEach((order)->{
			UserOrderDTO orderdto=mapper.map(order, UserOrderDTO.class);
			orderDTO.add(orderdto);
		});
		
		return orderDTO;
	}
	
	@Override
	public List<UserOrderDTO> getOrderDetails(Long orderid) {
		// TODO Auto-generated method stub
		List<UserOrderDTO> orderDTO=new ArrayList<UserOrderDTO>();
		List<UserOrder> allOrders = orderRepo.findAll();
		allOrders.stream().forEach((order)->{
			UserOrderDTO orderdto=mapper.map(order, UserOrderDTO.class);
			orderDTO.add(orderdto);
		});
		
		return orderDTO;
	}


	@Override
	public UserOrder orderPaymentConfirmation(String razorId, String paymentId) {
		// TODO Auto-generated method stub
		
		UserOrder findByRazorId = orderRepo.findByRazorId(razorId);
		findByRazorId.setPaymentId(paymentId);
		findByRazorId.setStatus("Paid");
		findByRazorId.setDelivery_status("Processing");
		
		orderProdService.decreaseStockAfterSuccessFullOrder(findByRazorId.getId());
		Map<String, Object> model = new HashMap<>();
		model.put("orderid",findByRazorId.getId() );
		String userName = findByRazorId.getUser().getUserName();
		String email = findByRazorId.getUser().getEmail();
		OrderDetailsDTO orderDetails = orderProdService.getOrderDetails(findByRazorId.getId());
		List<UserDisplayCartDTO> list = orderDetails.getOrderedProducts().getList();
		double price = findByRazorId.getTotalPrice();
		
		double item=0;
		int shipcharge=0;
		for(UserDisplayCartDTO p : list) {
			item +=p.getQuantity();
		}
		double finalPrice=0;
		
		if(price<1050) {
			shipcharge=50;
		finalPrice=price-shipcharge;
		}else {finalPrice=price;}
		
		model.put("ship",shipcharge );
		model.put("items",item );
		model.put("price",finalPrice );
		model.put("total",price );
		model.put("name", userName);
		//model.put("userName", userEntity.getUserName());
		
		System.out.println("@@@@@@@@@@@@@@@  Sending Email  @@@@@@@@@@");
		System.out.println(finalPrice);
		System.out.println(price);
		sendEmail.sendEmailOrder(email , model);
		
		
		return findByRazorId;
	}


	@Override
	public UserOrderDTO setOrderDeliveryStatus(Long orderID, String status) {
		// TODO Auto-generated method stub
		
		UserOrder findById = orderRepo.getById(orderID);
		findById.setDelivery_status(status);
		
		
		return mapper.map(findById, UserOrderDTO.class);
	}

	@Override
	public String cancelOrder(Long orderid) {
		// TODO Auto-generated method stub
		UserOrder byId = orderRepo.getById(orderid);
		byId.setStatus("Cancelled");
		
		return "Cancelled";
	}

	

	
	
	

}
