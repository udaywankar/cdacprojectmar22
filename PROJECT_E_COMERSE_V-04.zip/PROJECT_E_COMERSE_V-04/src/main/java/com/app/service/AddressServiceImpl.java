package com.app.service;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dto.AddressDTO;
import com.app.entities.Address;
import com.app.repository.AddressRepository;

@Service
@Transactional
public class AddressServiceImpl implements IAddressService {

	@Autowired
	private AddressRepository addrRepo;
	
	@Autowired
	private ModelMapper mapper;
	
	
	@Override
	public AddressDTO getUserAddress(Long userid) {
		// TODO Auto-generated method stub
		Address byId = addrRepo.getById(userid);
		AddressDTO addressDTO = mapper.map(byId, AddressDTO.class);
		return addressDTO;
	}

	@Override
	public AddressDTO updateUserAddress(AddressDTO address, Long addressId) {
		// TODO Auto-generated method stub
		Address map = mapper.map(address, Address.class);
		map.setId(addressId);
		Address save = addrRepo.save(map);
		
		return mapper.map(save, AddressDTO.class);
	}

}
