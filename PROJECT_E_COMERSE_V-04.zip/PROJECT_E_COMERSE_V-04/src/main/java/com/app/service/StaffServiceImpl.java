package com.app.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dto.StaffDTO;
import com.app.dto.UserRegResponse;
import com.app.entities.Staff;
import com.app.repository.StaffRepository;

@Service
@Transactional
public class StaffServiceImpl implements IStaffService {

	@Autowired
	private StaffRepository staffRepo;
	
	@Autowired
	private ModelMapper mapper;
	
	@Override
	public UserRegResponse registerStaff(StaffDTO user) {
		// TODO Auto-generated method stub
	
		return null;
	}

	@Override
	public List<StaffDTO> getAllStaff() {
		// TODO Auto-generated method stub
		List<Staff> findAll = staffRepo.findAll();
		List<StaffDTO> stafflist=new ArrayList<StaffDTO>();
		findAll.stream().forEach((s)->{
			StaffDTO map = mapper.map(s,StaffDTO.class);
			stafflist.add(map);
			
		});
		return stafflist;
	}

	@Override
	public StaffDTO addNewStaff(StaffDTO staff) {
		// TODO Auto-generated method stub
		Staff staff2 = mapper.map(staff, Staff.class);
		Staff save = staffRepo.save(staff2);
		//add user
		
		StaffDTO saveDTO=mapper.map(save, StaffDTO.class);
		return saveDTO;
	}

}
