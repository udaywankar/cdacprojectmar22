package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.dto.AddressDTO;
import com.app.dto.UserDTO;
import com.app.dto.UserRegResponse;
import com.app.entities.Address;
import com.app.entities.Role;
import com.app.entities.UserEntity;
import com.app.entities.UserRole;
import com.app.exc_handler.EmailAlreadyExistException;
import com.app.repository.RoleRepository;
import com.app.repository.UserRepository;

@Service
@Transactional
public class UserServiceImpl implements IUserService {
	// dep : user repo n role repo
	@Autowired
	private UserRepository userRepo;

	@Autowired
	private AuthenticationManager manager;
	//dep : user service for handling users
	
	@Autowired
	private RoleRepository roleRepo;

	// mapper
	@Autowired
	private ModelMapper mapper;
	//	password enc
	@Autowired
	private PasswordEncoder encoder;

	@Override
	public UserRegResponse registerUser(UserDTO user) {
		// Objective : 1 rec inserted in users table n insert n recs in link table (users_roles)
		//1. Map dto --> entity
		System.out.println("//// registerUser  user /////");
		System.out.println(user);
		UserEntity userEntity=mapper.map(user,UserEntity.class);
		System.out.println("//// registerUser  userEntity /////");
		System.out.println(userEntity);
		Optional<UserEntity> alreadyExist = userRepo.findByEmail(user.getEmail());
		System.out.println(alreadyExist);
		if(!alreadyExist.isEmpty()) {
			System.out.println("IN IFFFFFFFFFFFFF");
			throw new EmailAlreadyExistException("Email Already Exist");
		}
		
		System.out.println("////  After email checking ");
		Role role = roleRepo.findByRoleName(UserRole.valueOf("ROLE_USER")).orElseThrow(() -> new RuntimeException("Invalid role!!!"));
		System.out.println(role);
		userEntity.getUserRoles().add(role);
		userEntity.setPassword(encoder.encode(user.getPassword()));
		System.out.println(userEntity);
		UserEntity persistentUser = userRepo.save(userEntity);
//		userEntity.getUserRoles().clear();//to be checked further !!!!!!!!!!!!!!!!!!!!!!
//		//2. Iterate over the  roles from user dto n map it to Role ---add them under user entity
//		user.getRoles().stream() //Stream<UserRole>
//		.map(roleEnum -> roleRepo.findByRoleName(roleEnum).orElseThrow(() -> new RuntimeException("Invalid role!!!"))) //Stream<Role>
//		.forEach(role -> userEntity.getUserRoles().add(role));//establishes uni dir relation ship between User n Role
//		//3. encode pwd
//		System.out.println(userEntity);
//		
//		//4 : should I save roles first before saving user dtls? NO : alrdy existing in db		
//		UserEntity persistentUser = userRepo.save(userEntity);
		return new UserRegResponse("User registered successfully with ID "+persistentUser.getUserId());
		
	}
	@Override
	public UserEntity getAnthUser(String email) {
		
		Optional<UserEntity> userEntity = userRepo.findByEmail(email);
		if(userEntity.isEmpty())
			return null;
		else 
			return userEntity.get();
		
	}
	@Override
	public UserEntity changePassword(String email, String pass) {
		// TODO Auto-generated method stub
		
		
		
		Optional<UserEntity> persistentUser = userRepo.findByEmail(email);
		
		UserEntity per=persistentUser.get();
		
		per.setPassword(encoder.encode(pass));
		UserEntity save = userRepo.save(per);
		return save;
	}
	@Override
	public List<Address> getUserAddressess(Long userId) {
		// TODO Auto-generated method stub
		
		List<Address> addrList=new ArrayList<Address>();
		UserEntity findById = userRepo.findById(userId).orElseThrow(() -> new RuntimeException("Invalid role!!!"));
		System.out.println(findById);
		List<Address> addre=findById.getAddressess();
				//addrList.add(findById.getBillingAddr());
		//addrList.add(findById.getShippingAddr());
		
		return addre;
	}
	
	@Override
	public List<Address> addUserAddressess(AddressDTO addr,Long userId) {
		// TODO Auto-generated method stub
		
		List<Address> addrList=new ArrayList<Address>();
		UserEntity findById = userRepo.findById(userId).orElseThrow(() -> new RuntimeException("Invalid role!!!"));
		System.out.println(findById);
		Address map = mapper.map(addr,Address.class);
		findById.getAddressess().add(map);
		List<Address> addre=findById.getAddressess();
				//addrList.add(findById.getBillingAddr());
		//addrList.add(findById.getShippingAddr());
		
		return addre;
	}
	@Override
	public UserDTO getUserInfo(Long userId) {
		// TODO Auto-generated method stub
		UserEntity byId = userRepo.getById(userId);
		UserDTO userDTO = mapper.map(byId, UserDTO.class);
		userDTO.setPassword("");
		return userDTO;
	}
	@Override
	public String setUserProfileImage(Long userId, String image) {
		// TODO Auto-generated method stub
		UserEntity byId = userRepo.getById(userId);
		byId.setProfileImage(image);
		return "Image Uploaded Successfully";
	}
	@Override
	public UserDTO updateUserInfo(Long userid, UserDTO user) {
		// TODO Auto-generated method stub
		UserEntity u=userRepo.getById(userid);
		u.setMobileNo(user.getMobileNo());
		u.setPanNo(user.getPanNo());
		u.setUserName(user.getUserName());
		UserDTO save = mapper.map(u, UserDTO.class);
		save.setPassword("");
		return mapper.map(save, UserDTO.class);
	}
	@Override
	public String changeUserPassword(Long userid, String oldpass, String newpass) {
		// TODO Auto-generated method stub
		UserEntity persistentUser = userRepo.getById(userid);
		
		String pass=encoder.encode(oldpass);
		
		
		UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(persistentUser.getEmail(),
				oldpass);
		//System.out.println(authToken);
		try {
			// authenticate the credentials
			Authentication authenticatedDetails = manager.authenticate(authToken);
			// => auth succcess
		} catch (BadCredentialsException e) { // lab work : replace this by a method in global exc handler
			// send back err resp code
			
			System.out.println("err "+e);
			return "Failed";
		}	
		persistentUser.setPassword(encoder.encode(newpass));
		
		return "Success";
		
		
		
//		if(pass.equals(persistentUser.getPassword())) {
//			return "matched";
//		}
//		
		
		
		
	}


}
