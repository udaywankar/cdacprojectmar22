package com.app.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.app.dto.ProductDTO;

public interface ImageHandlingService {

	ProductDTO storeImage(Long empid, MultipartFile imageData) throws IOException;

	byte[] getImage(Long empid) throws IOException;

	ProductDTO storeDisplayImage(Long empid, MultipartFile imageData) throws IOException;
	
}
