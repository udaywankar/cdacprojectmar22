package com.app.service;

import java.util.List;

import com.app.dto.AddressDTO;
import com.app.dto.UserCartDTO;
import com.app.dto.UserDTO;
import com.app.dto.UserDisplayCartDTO;
import com.app.dto.UserRegResponse;
import com.app.entities.Product;
import com.app.entities.UserCart;
import com.app.entities.UserEntity;

public interface IAddressService {

//	UserRegResponse registerUser(UserDTO user);

	
	AddressDTO getUserAddress(Long userid);
	
	AddressDTO updateUserAddress(AddressDTO address, Long  addressId);

	

}
