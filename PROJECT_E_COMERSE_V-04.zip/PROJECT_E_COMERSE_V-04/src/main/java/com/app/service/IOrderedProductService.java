package com.app.service;

import com.app.dto.OrderDetailsDTO;

public interface IOrderedProductService {

	int orderCartProduct(Long userid,Long orderid);
	OrderDetailsDTO getOrderDetails(Long orderid);
	
	int decreaseStockAfterSuccessFullOrder(Long orderid);
//	UserRegResponse registerUser(UserDTO user);

//	UserOrder saveUserOrder(UserOrder order);
//	UserOrder orderPaymentConfirmation(String razorId,String patmentId);
	
}
