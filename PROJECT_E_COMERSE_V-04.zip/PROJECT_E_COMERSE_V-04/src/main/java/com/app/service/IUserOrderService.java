package com.app.service;

import java.util.List;

import com.app.dto.UserCartDTO;
import com.app.dto.UserDTO;
import com.app.dto.UserDisplayCartDTO;
import com.app.dto.UserOrderDTO;
import com.app.dto.UserRegResponse;
import com.app.entities.Product;
import com.app.entities.UserCart;
import com.app.entities.UserEntity;
import com.app.entities.UserOrder;

public interface IUserOrderService {

//	UserRegResponse registerUser(UserDTO user);

	UserOrder saveUserOrder(UserOrder order,Long userid);
	UserOrder orderPaymentConfirmation(String razorId,String patmentId);
	 List<UserOrderDTO> getAllOrder();
	 List<UserOrderDTO> getOrderDetails(Long orderid);
	 List<UserOrderDTO> getAllUserOrder(Long userId);
	 String cancelOrder(Long orderid);
	 UserOrderDTO setOrderDeliveryStatus(Long orderID, String status);
}
