package com.app.service.emailsend;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
@Service
public class EmailSenderService {
	   @Autowired
	    private JavaMailSender mailSender;

	   @Autowired
	   private Configuration config;
	   
	  
	    public void sendSimpleEmail(String toEmail,
	                                String subject,
	                                String body )
	     {
	        SimpleMailMessage message = new SimpleMailMessage();
	        message.setFrom("AmigoTech.in@gmail.com");
	        message.setTo(toEmail);
	        message.setText(body);
	        message.setSubject(subject);
	        mailSender.send(message);
	        System.out.println("Mail Send...");
	    }
	    

	    public void sendEmailPasswordReset(String email , Map<String, Object> model) {
	
	    		MimeMessage message = mailSender.createMimeMessage();
	    		try {
	    			// set mediaType
	    			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
	    					StandardCharsets.UTF_8.name());
	    			// add attachment
	    				//helper.addAttachment("logo.png", new ClassPathResource("logo.png"));

	    			Template t = config.getTemplate("emailOTP-template.ftl");
	    			String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);
	    			
	    			helper.setTo(email);
	    			helper.setText(html, true);
	    			helper.setSubject("AmigoTech.in Password Reset OTP");
	    			helper.setFrom("AMIGOTECH.IN");
	    			mailSender.send(message);

		

	    			} catch (MessagingException | IOException | TemplateException e) {
	    					System.out.println("Mail Sending failure : "+((Throwable) e).getMessage());
		
	    			}

	    }
	    public void sendEmailWelcome(String userEmail , Map<String, Object> model) {
	    	
	    	MimeMessage message = mailSender.createMimeMessage();
	    	try {
	    		// set mediaType
	    		MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
	    				StandardCharsets.UTF_8.name());
	    		// add attachment
	    		//helper.addAttachment("logo.png", new ClassPathResource("logo.png"));

	    		Template t = config.getTemplate("WelcomeEmail-template.ftl");
	    		String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);

	    		helper.setTo(userEmail);
	    		helper.setText(html, true);
	    		helper.setSubject("Welcome To AmigoTech.in");
	    		helper.setFrom("info@amigotech.in");
	    		mailSender.send(message);

	    		

	    	} catch (MessagingException | IOException | TemplateException e) {
	    		System.out.println("Mail Sending failure : "+((Throwable) e).getMessage());
	    		
	    	}

	    }
	    
	    
	    
	    	public void sendEmailOrder(String userEmail , Map<String, Object> model) {
	    	
	    	MimeMessage message = mailSender.createMimeMessage();
	    	try {
	    		// set mediaType
	    		MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
	    				StandardCharsets.UTF_8.name());
	    		// add attachment
	    		//helper.addAttachment("logo.png", new ClassPathResource("logo.png"));

	    		Template t = config.getTemplate("OrderEmail-template.ftl");
	    		String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);

	    		helper.setTo(userEmail);
	    		helper.setText(html, true);
	    		helper.setSubject("Your Order Received AmigoTech.in");
	    		helper.setFrom("info@amigotech.in");
	    		mailSender.send(message);

	    		

	    	} catch (MessagingException | IOException | TemplateException e) {
	    		System.out.println("Mail Sending failure : "+((Throwable) e).getMessage());
	    		
	    	}

	    }
}
