package com.app.service;

import java.util.List;

import javax.validation.Valid;

import com.app.dto.CategoryDTO;
import com.app.dto.ServerResponce;

public interface ICategoryService {

	ServerResponce addCategory(@Valid CategoryDTO category);

	List<CategoryDTO> getallCategories();

}
