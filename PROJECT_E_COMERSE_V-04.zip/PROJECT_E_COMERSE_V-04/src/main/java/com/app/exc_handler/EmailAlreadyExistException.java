package com.app.exc_handler;

public class EmailAlreadyExistException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public EmailAlreadyExistException(String mseg) {
		// TODO Auto-generated constructor stub
		super(mseg);
		System.out.println("IN Constructor EmailAlreadyExistException ");
		
	}
	

}
