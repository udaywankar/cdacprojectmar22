package com.app.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="comments", uniqueConstraints = @UniqueConstraint(columnNames = {"user_id","product_id"}))
@Getter
@Setter
public class Comments extends BaseEntity{
	@Column(length=300)
	private String comment;
	
	private Date commentDate;
	
	//User 1 <----- * Comment: Uni Dir associan
	@ManyToOne(fetch =FetchType.LAZY)
	@JoinColumn(name="user_id")
	private UserEntity user;
	
	//Tutorial 1 <------> * Comments
	@ManyToOne(fetch =FetchType.LAZY)
	@JoinColumn(name="product_id")
	private Product product;

}
