package com.app.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "orderedproducts")
@Getter
@Setter


@NoArgsConstructor
//prod id	SKU	Prod Name	Category	Prod Desc	Price	stock 	Comments	visits	items sold

public class OrderedProducts extends BaseEntity{

	
	

	private Integer quantity;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "product_id")
	private Product product;
	
	
	@ManyToOne(cascade = CascadeType.ALL, optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "order_id")
	private UserOrder order;

	public OrderedProducts(Integer quantity, Product product, UserOrder order) {
		super();
		this.quantity = quantity;
		this.product = product;
		this.order = order;
	}
	
	
	@Override
	public String toString() {
		return "OrderedProducts [id=" + super.getId() + ", quantity=" + quantity + ", product=" + product + "]";
	}

	

}
