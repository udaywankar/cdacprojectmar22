package com.app.entities;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude ="roles")
public class UserEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userId;
	@Column(length = 30)
	private String userName;
	@Column(length = 40, unique = true)
	private String email;
	@Column(length = 350)
	private String password;
	@Column(length = 350)
	private String profileImage;
	@Column(length = 10)
	private String mobileNo;
	@Column(length = 14)
	private String panNo;
	// many-to-many , User *--->* Role
	@ManyToMany
	@JoinTable(name = "users_roles", 
	joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<Role> userRoles = new HashSet<>();

	@OneToMany(cascade=CascadeType.ALL, mappedBy="user", fetch=FetchType.LAZY)
	private List<UserCart> cart=new ArrayList<UserCart>();
	
	
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.LAZY)
//	@JoinColumn(name="billingAddress")
	private List<Address> addressess=new ArrayList<Address>();
	
	
	
}
