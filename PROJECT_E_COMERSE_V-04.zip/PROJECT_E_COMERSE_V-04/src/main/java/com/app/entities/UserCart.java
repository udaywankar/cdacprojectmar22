package com.app.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "TempCart")
@Getter
@Setter

@AllArgsConstructor
@NoArgsConstructor
//prod id	SKU	Prod Name	Category	Prod Desc	Price	stock 	Comments	visits	items sold
@IdClass(CartItem.class)
public class UserCart {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private Integer quantity;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "product_id")
	private Product product;
	@ManyToOne(cascade = CascadeType.ALL, optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "user_id")
	private UserEntity user;

	public UserCart(Integer quantity, Product product, UserEntity user) {
		super();
		this.quantity = quantity;
		this.product = product;
		this.user = user;
	}
	
	
	@Override
	public String toString() {
		return "UserCart [id=" + id + ", quantity=" + quantity + ", product=" + product + "]";
	}

	

}
