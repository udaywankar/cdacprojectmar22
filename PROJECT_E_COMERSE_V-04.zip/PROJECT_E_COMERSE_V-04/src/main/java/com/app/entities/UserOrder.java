package com.app.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Entity
@Table(name = "userOrder")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserOrder extends BaseEntity {
	
	
	
	private double totalPrice;
	@Column(length = 30)
	private String orderDate;
	@Column(length = 20)
	private String status;
	@Column(length = 50)
	private String razorId;
	
	@Column(length = 50)
	private String paymentId;
	@Column(length = 50)
	private String delivery_status;
	
	@ManyToOne(cascade = CascadeType.ALL, optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "user_id")
	private UserEntity user;
	//private UserEntity user;
	
	
	

}
