package com.app.entities;

import java.io.Serializable;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CartItem implements Serializable {
	
	//User 1 <----- * Comment: Uni Dir associan
//	@ManyToOne(fetch =FetchType.EAGER)
//	@JoinColumn(name="user_id")
	private UserEntity user;
	
	//
//	@ManyToOne(fetch =FetchType.EAGER)
//	@JoinColumn(name="product_id")
	private Product product;
	

}
