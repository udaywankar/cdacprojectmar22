package com.app.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "category")
@Getter
@Setter
@ToString
@NoArgsConstructor
//prod id	SKU	Prod Name	Category	Prod Desc	Price	stock 	Comments	visits	items sold

public class Category extends BaseEntity{
	
	@Column(length = 30,unique=true)
	private String categoryName;

	public Category(String categoryName) {
		super();
		this.categoryName = categoryName;
	}
	 
	
	
	
	
	
	

}
