package com.app.entities;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "staff")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Staff {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long staffId;
	@Column(length = 30)
	private String staffName;
	@Column(length = 30, unique = true)
	private String email;
	@Column(length = 350)
	private String password;
	@Column(length = 350)
	private String profileImage;
	@Column(length = 10)
	private String mobileNo;
	@Column(length = 14)
	private String panNo;
	@Column(length = 20)
	private String department;
	
	
	
	

	
	
}
