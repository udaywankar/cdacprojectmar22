package com.app.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "product")
@Getter
@Setter
@ToString
@NoArgsConstructor
//prod id	SKU	Prod Name	Category	Prod Desc	Price	stock 	Comments	visits	items sold

public class Product extends BaseEntity{
	
	@Column(length = 20,unique=true)
	private String SKU;
	@Column(length = 100)
	private String productName;
	@Column(length = 500)
	private String description;
	@Column(length = 800)
	private String image;
	private Integer imageCount;
	private Double price;
	private Integer stock;
	private Long visits;
	private Integer sold;
	
	@ManyToOne
	@JoinColumn
	private Category category; 
	
	
	
//	@OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true, fetch=FetchType.EAGER)
//	private List<Comments> comments = new ArrayList<>();
//
//	// add helper Methods
//
//	//add helper methods to add child n remove child
//		public void addComment(Comments c)
//		{
//			//establish bi dir
//			comments.add(c);//tut --> comment
//			c.setProduct(this);//comment ---> Tut
//		}
//		public void removeComment(Comments c)
//		{
//			//de-link bi dir
//			comments.remove(c);//tut ----X----> comment
//			c.setProduct(null);//comment -------------X---------> Tut
//		}

	

}
